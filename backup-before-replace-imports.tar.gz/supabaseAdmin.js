// supabaseAdmin.js (Local Postgres Adapter)
// هدف: تقلید حداقلی از API supabase برای اینکه کدهای قبلی سریع کار کنند.
// توصیه: در مرحله بعد route ها را کم کم به SQL واقعی تبدیل کنید.

const { Pool } = require("pg");

if (!process.env.DATABASE_URL) {
    throw new Error("❌ DATABASE_URL is not set");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const SQL = {
    ident(name) {
        // حداقلی: جلوگیری از SQL injection در نام جدول/ستون
        if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name)) {
            throw new Error(`Invalid identifier: ${name}`);
        }
        return `"${name}"`;
    },
};

function buildWhere(andClauses, orGroups, params) {
    const parts = [];

    if (andClauses.length) parts.push(andClauses.join(" AND "));
    if (orGroups.length) parts.push(orGroups.map(g => `(${g})`).join(" AND "));

    return parts.length ? `WHERE ${parts.join(" AND ")}` : "";
}

function parseOrString(orStr, params) {
    // نمونه ورودی‌هایی که در پروژه شما دیده شده:
    // "mobile.eq.0912...,mobile.eq.+98912..."
    // "a.eq.1,b.eq.2"
    // فقط از eq پشتیبانی می‌کنیم (فعلاً)
    const items = String(orStr).split(",").map(s => s.trim()).filter(Boolean);
    const parts = [];

    for (const it of items) {
        // فرم: col.eq.value
        const m = it.match(/^([a-zA-Z_][a-zA-Z0-9_]*)\.eq\.(.+)$/);
        if (!m) throw new Error(`Unsupported .or() filter: ${it}`);
        const col = m[1];
        const rawVal = m[2];

        // supabase گاهی + را داخل رشته می‌آورد
        const val = rawVal;

        params.push(val);
        parts.push(`${SQL.ident(col)} = $${params.length}`);
    }

    return parts.length ? parts.join(" OR ") : "";
}

class QueryBuilder {
    constructor(table) {
        this.table = table;

        this._select = "*";
        this._selectHead = false;
        this._count = null; // "exact" | null
        this._op = "select"; // select | insert | update | delete

        this._insertRows = null;
        this._updateSet = null;

        this._and = [];
        this._or = [];

        this._orderBy = null;
        this._limit = null;

        this._single = false;
        this._maybeSingle = false;
    }

    select(cols = "*", opts = {}) {
        this._op = "select";
        this._select = cols || "*";
        this._count = opts?.count || null;
        this._selectHead = Boolean(opts?.head);
        return this;
    }

    eq(col, value) {
        const paramsIdx = this._params ? this._params.length + 1 : null;
        // params در execute ساخته میشه؛ اینجا placeholder می‌سازیم با مارکر
        this._and.push({ type: "eq", col, value });
        return this;
    }

    or(orStr) {
        this._or.push(orStr);
        return this;
    }

    order(col, { ascending = true } = {}) {
        this._orderBy = { col, ascending };
        return this;
    }

    limit(n) {
        this._limit = Number(n);
        return this;
    }

    insert(rows) {
        this._op = "insert";
        this._insertRows = Array.isArray(rows) ? rows : [rows];
        return this;
    }

    update(setObj) {
        this._op = "update";
        this._updateSet = setObj;
        return this;
    }

    delete() {
        this._op = "delete";
        return this;
    }

    single() {
        this._single = true;
        return this._exec();
    }

    maybeSingle() {
        this._maybeSingle = true;
        return this._exec();
    }

    async _exec() {
        try {
            const params = [];
            const andClauses = [];

            // AND eq clauses
            for (const c of this._and) {
                if (c.type === "eq") {
                    params.push(c.value);
                    andClauses.push(`${SQL.ident(c.col)} = $${params.length}`);
                } else {
                    throw new Error(`Unsupported filter type: ${c.type}`);
                }
            }

            // OR groups
            const orGroups = [];
            for (const orStr of this._or) {
                orGroups.push(parseOrString(orStr, params));
            }

            const where = buildWhere(andClauses, orGroups, params);

            const table = SQL.ident(this.table);

            // COUNT support (select head)
            if (this._op === "select" && this._count === "exact") {
                const countSql = `SELECT COUNT(*)::bigint AS count FROM ${table} ${where}`;
                const countRes = await pool.query(countSql, params);
                const count = Number(countRes.rows?.[0]?.count || 0);

                if (this._selectHead) {
                    return { data: null, error: null, count };
                }
                // ادامه‌ی select عادی
            }

            if (this._op === "select") {
                const cols =
                    this._select === "*" ? "*" :
                        Array.isArray(this._select) ? this._select.map(SQL.ident).join(", ") :
                            String(this._select).split(",").map(s => s.trim()).map(SQL.ident).join(", ");

                let sql = `SELECT ${cols} FROM ${table} ${where}`;

                if (this._orderBy) {
                    sql += ` ORDER BY ${SQL.ident(this._orderBy.col)} ${this._orderBy.ascending ? "ASC" : "DESC"}`;
                }
                if (this._limit != null) {
                    sql += ` LIMIT ${this._limit}`;
                }

                const res = await pool.query(sql, params);
                let data = res.rows;

                if (this._single || this._maybeSingle) {
                    const row = data[0] || null;
                    if (!row && this._single) return { data: null, error: { message: "No rows" } };
                    return { data: row, error: null };
                }

                return { data, error: null };
            }

            if (this._op === "insert") {
                const rows = this._insertRows || [];
                if (!rows.length) return { data: null, error: { message: "No rows to insert" } };

                // ستون‌ها از کلیدهای ردیف اول
                const cols = Object.keys(rows[0]);
                const colSql = cols.map(SQL.ident).join(", ");

                const valuesSql = rows.map((r) => {
                    const ph = cols.map((k) => {
                        params.push(r[k]);
                        return `$${params.length}`;
                    });
                    return `(${ph.join(", ")})`;
                }).join(", ");

                const sql = `INSERT INTO ${table} (${colSql}) VALUES ${valuesSql} RETURNING *`;
                const res = await pool.query(sql, params);
                return { data: res.rows, error: null };
            }

            if (this._op === "update") {
                const setObj = this._updateSet || {};
                const setKeys = Object.keys(setObj);
                if (!setKeys.length) return { data: null, error: { message: "No fields to update" } };

                const setSql = setKeys.map((k) => {
                    params.push(setObj[k]);
                    return `${SQL.ident(k)} = $${params.length}`;
                }).join(", ");

                const sql = `UPDATE ${table} SET ${setSql} ${where} RETURNING *`;
                const res = await pool.query(sql, params);
                return { data: res.rows, error: null };
            }

            if (this._op === "delete") {
                const sql = `DELETE FROM ${table} ${where} RETURNING *`;
                const res = await pool.query(sql, params);
                return { data: res.rows, error: null };
            }

            return { data: null, error: { message: `Unsupported op: ${this._op}` } };
        } catch (e) {
            return { data: null, error: { message: e?.message || String(e) } };
        }
    }
}

const supabaseAdmin = {
    from(table) {
        return new QueryBuilder(table);
    },

    // ⚠️ rpc در پروژه شما زیاد استفاده شده. این Adapter rpc را پیاده نکرده.
    // پیشنهاد استاندارد: هر rpc را جداگانه به SQL تبدیل کنید.
    rpc() {
        return Promise.resolve({ data: null, error: { message: "rpc is not supported in local adapter. Convert to SQL." } });
    },

    storage: {
        // اگر جایی استفاده شده باشد، باید جداگانه برای storage تصمیم بگیرید (local disk / S3 / ...).
    },
};

module.exports = { supabaseAdmin, pool };
