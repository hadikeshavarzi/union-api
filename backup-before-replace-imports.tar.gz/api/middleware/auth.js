// api/middleware/auth.js
const jwt = require("jsonwebtoken");
const { pool } = require("../../supabaseAdmin"); // چون شما pool را از همین فایل export کردید

// اگر دوست داری وابستگی به نام فایل "supabaseAdmin" هم حذف بشه، بگو تا ساختار را تمیز کنیم.

function getBearerToken(req) {
    const h = req.headers.authorization || req.headers.Authorization || "";
    if (!h || !h.startsWith("Bearer ")) return null;
    return h.slice(7).trim();
}

async function authMiddleware(req, res, next) {
    try {
        const token = getBearerToken(req);
        if (!token) {
            return res.status(401).json({ success: false, error: "توکن ارسال نشده است" });
        }

        if (!process.env.JWT_SECRET) {
            console.error("❌ JWT_SECRET is not set");
            return res.status(500).json({ success: false, error: "پیکربندی سرور ناقص است" });
        }

        let decoded;
        try {
            decoded = jwt.verify(token, process.env.JWT_SECRET);
        } catch (e) {
            console.error("❌ JWT verify failed:", e.message);
            return res.status(401).json({ success: false, error: "نشست کاربری نامعتبر یا منقضی شده است" });
        }

        // استاندارد: id یا sub
        const memberId = decoded.id ?? decoded.sub;
        if (!memberId) {
            console.error("❌ Token has no id/sub:", decoded);
            return res.status(401).json({ success: false, error: "توکن ناقص است" });
        }

        // memberId باید عدد باشد (چون id شما bigint/serial است)
        const memberIdNum = Number(memberId);
        if (!Number.isFinite(memberIdNum)) {
            console.error("❌ Invalid member id in token:", memberId);
            return res.status(401).json({ success: false, error: "توکن ناقص است" });
        }

        const { rows } = await pool.query(
            `
      SELECT 
        id, role, email, member_code, full_name, father_name, national_id,
        mobile, phone, address, birth_date, business_name, category,
        member_status, license_number, license_issue_date, license_expire_date,
        license_image, national_card_image, id_card_image, company_license_image,
        member_image, company_name, registration_number,
        auth_user_id, owner_id, permissions, created_at, updated_at
      FROM public.members
      WHERE id = $1
      LIMIT 1
      `,
            [memberIdNum]
        );

        const member = rows[0];
        if (!member) {
            return res.status(403).json({ success: false, error: "اطلاعات کاربری شما در سیستم یافت نشد." });
        }

        if (member.member_status !== "active") {
            return res.status(403).json({ success: false, error: "حساب کاربری شما غیرفعال است" });
        }

        // ✅ تزریق user
        // توجه: otp_code و otp_expires را عمداً برنمی‌داریم (در SELECT هم نیست)
        req.user = {
            ...member,
            // payload کمک‌کننده (اختیاری)
            token_role: decoded.role,
            token_owner_id: decoded.owner_id,
            token_iat: decoded.iat,
            token_exp: decoded.exp,
        };

        return next();
    } catch (err) {
        console.error("💥 Auth Error:", err?.stack || err);
        return res.status(401).json({ success: false, error: "نشست کاربری نامعتبر یا منقضی شده است" });
    }
}

module.exports = authMiddleware;
