--
-- PostgreSQL database dump
--

\restrict waqntksljm8fl2si84Fn31LAmT2ad29ASjcrxeIfMyfYhUFezZK02eZDMgdkyFF

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO postgres;

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA extensions;


ALTER SCHEMA extensions OWNER TO postgres;

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA graphql;


ALTER SCHEMA graphql OWNER TO postgres;

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA graphql_public;


ALTER SCHEMA graphql_public OWNER TO postgres;

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA pgbouncer;


ALTER SCHEMA pgbouncer OWNER TO postgres;

--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA realtime;


ALTER SCHEMA realtime OWNER TO postgres;

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA storage;


ALTER SCHEMA storage OWNER TO postgres;

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA vault;


ALTER SCHEMA vault OWNER TO postgres;

--
-- Name: moddatetime; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS moddatetime WITH SCHEMA public;


--
-- Name: EXTENSION moddatetime; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION moddatetime IS 'functions for tracking last modification time';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: postgres
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE auth.aal_level OWNER TO postgres;

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: postgres
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


ALTER TYPE auth.code_challenge_method OWNER TO postgres;

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: postgres
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE auth.factor_status OWNER TO postgres;

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: postgres
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE auth.factor_type OWNER TO postgres;

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: postgres
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE auth.oauth_authorization_status OWNER TO postgres;

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: postgres
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE auth.oauth_client_type OWNER TO postgres;

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: postgres
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE auth.oauth_registration_type OWNER TO postgres;

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: postgres
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


ALTER TYPE auth.oauth_response_type OWNER TO postgres;

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: postgres
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE auth.one_time_token_type OWNER TO postgres;

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: postgres
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE realtime.action OWNER TO postgres;

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: postgres
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE realtime.equality_op OWNER TO postgres;

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: postgres
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


ALTER TYPE realtime.user_defined_filter OWNER TO postgres;

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: postgres
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


ALTER TYPE realtime.wal_column OWNER TO postgres;

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: postgres
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


ALTER TYPE realtime.wal_rls OWNER TO postgres;

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: postgres
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE storage.buckettype OWNER TO postgres;

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: postgres
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION auth.email() OWNER TO postgres;

--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: postgres
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION auth.jwt() OWNER TO postgres;

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: postgres
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION auth.role() OWNER TO postgres;

--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: postgres
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  -- آیدی یوزر خودت را اینجا می‌گذاریم
  SELECT 'dc66ad9a-8bc5-4556-9860-aeab96211fa3'::uuid; 
$$;


ALTER FUNCTION auth.uid() OWNER TO postgres;

--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_cron_access() OWNER TO postgres;

--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION extensions.grant_pg_graphql_access() OWNER TO postgres;

--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION extensions.grant_pg_net_access() OWNER TO postgres;

--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_ddl_watch() OWNER TO postgres;

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION extensions.pgrst_drop_watch() OWNER TO postgres;

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: postgres
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION extensions.set_graphql_placeholder() OWNER TO postgres;

--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: postgres
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: postgres
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION pgbouncer.get_auth(p_usename text) OWNER TO postgres;

--
-- Name: _inv_apply_delta(bigint, bigint, bigint, numeric, text, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public._inv_apply_delta(p_receipt_id bigint, p_owner_id bigint, p_product_id bigint, p_delta_qty numeric, p_ref_type text, p_ref_receipt_id bigint, p_member_id bigint) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  v_before numeric;
  v_after  numeric;
  v_type   text;
BEGIN
  IF p_delta_qty = 0 THEN
    RETURN;
  END IF;

  v_type := CASE WHEN p_delta_qty > 0 THEN 'in' ELSE 'out' END;

  SELECT public.get_stock(p_product_id, p_owner_id)
    INTO v_before;

  v_after := CASE
    WHEN v_type = 'in'  THEN v_before + abs(p_delta_qty)
    ELSE v_before - abs(p_delta_qty)
  END;

  INSERT INTO public.inventory_transactions (
    type,
    ref_receipt_id,
    product_id,
    owner_id,
    member_id,
    qty,
    snapshot_qty_before,
    snapshot_qty_after
  )
  VALUES (
    v_type,
    p_ref_receipt_id,
    p_product_id,
    p_owner_id,
    p_member_id,
    abs(p_delta_qty),
    v_before,
    v_after
  );
END;
$$;


ALTER FUNCTION public._inv_apply_delta(p_receipt_id bigint, p_owner_id bigint, p_product_id bigint, p_delta_qty numeric, p_ref_type text, p_ref_receipt_id bigint, p_member_id bigint) OWNER TO postgres;

--
-- Name: cancel_receipt(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cancel_receipt(p_receipt_id bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_status text;
  v_owner_id bigint;
  r record;
begin
  select status, owner_id
    into v_status, v_owner_id
  from public.receipts
  where id = p_receipt_id
  for update;

  if not found then
    raise exception 'receipt not found';
  end if;

  if v_status = 'cancelled' then
    return jsonb_build_object('success', true, 'receipt_id', p_receipt_id, 'message', 'already cancelled');
  end if;

  -- reverse inventory only if was final
  if v_status = 'final' then
    for r in
      select product_id, sum(coalesce(count,0)) as qty
      from public.receipt_items
      where receipt_id = p_receipt_id
      group by product_id
    loop
      perform public._inv_apply_delta(
        p_receipt_id,
        v_owner_id,
        r.product_id,
        -coalesce(r.qty,0),        -- negative => out
        'receipt_cancel',
        p_receipt_id
      );
    end loop;
  end if;

  update public.receipts
    set status = 'cancelled'
  where id = p_receipt_id;

  return jsonb_build_object('success', true, 'receipt_id', p_receipt_id);
end;
$$;


ALTER FUNCTION public.cancel_receipt(p_receipt_id bigint) OWNER TO postgres;

--
-- Name: cancel_receipt(bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cancel_receipt(p_receipt_id bigint, p_member_id bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  r record;
  v_before numeric;
begin
  -- lock receipt
  select * into r
  from public.receipts
  where id = p_receipt_id
  for update;

  if not found then
    raise exception 'receipt not found';
  end if;

  if r.status <> 'final' then
    raise exception 'only final receipts can be cancelled';
  end if;

  -- reverse inventory
  for r in
    select * from public.receipt_items where receipt_id = p_receipt_id
  loop
    select public.get_stock(r.product_id, r.owner_id)
      into v_before;

    insert into public.inventory_transactions (
      receipt_id,
      product_id,
      owner_id,
      member_id,
      qty,
      type,
      snapshot_qty_before,
      snapshot_qty_after,
      ref_type,
      ref_id
    )
    values (
      p_receipt_id,
      r.product_id,
      r.owner_id,
      p_member_id,
      r.count,
      'out',
      v_before,
      v_before - r.count,
      'receipt_cancel',
      p_receipt_id
    );
  end loop;

  -- update receipt status
  update public.receipts
  set status = 'cancelled'
  where id = p_receipt_id;

  return jsonb_build_object(
    'success', true,
    'receipt_id', p_receipt_id,
    'status', 'cancelled'
  );
end;
$$;


ALTER FUNCTION public.cancel_receipt(p_receipt_id bigint, p_member_id bigint) OWNER TO postgres;

--
-- Name: check_clearance_locked(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_clearance_locked(p_clearance_id bigint) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_is_locked boolean;
BEGIN
  -- بررسی می‌کنیم آیا هیچکدام از اقلام این سند، والدِ تراکنش دیگری شده‌اند؟
  -- (یعنی آیا بچ تولید شده در این سند، در جای دیگری مصرف شده است؟)
  SELECT EXISTS (
    SELECT 1 
    FROM clearance_items ci
    JOIN inventory_transactions it ON it.parent_batch_no = ci.batch_no
    WHERE ci.clearance_id = p_clearance_id
      -- شرط مهم: تراکنشی که پیدا کردیم نباید تراکنشِ خودِ همین سند باشد
      AND it.ref_clearance_id != p_clearance_id 
  ) INTO v_is_locked;

  RETURN v_is_locked;
END;
$$;


ALTER FUNCTION public.check_clearance_locked(p_clearance_id bigint) OWNER TO postgres;

--
-- Name: create_clearance_with_items(json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_clearance_with_items(p_payload json) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_clearance_id bigint;
  v_clearance_no bigint;
  v_item json;
  
  v_source_qty numeric;    
  v_source_weight numeric;
  v_used_qty numeric;      
  v_used_weight numeric;
  v_current_qty numeric;   
  v_current_weight numeric;
  
  v_plate_text text;
  v_parent_batch text; -- متغیر برای نگهداری نام ردیف والد
  
BEGIN
  -- 1. تولید شماره سند جدید
  SELECT COALESCE(MAX(clearance_no), 1000) + 1 INTO v_clearance_no FROM clearances;

  v_plate_text := p_payload->>'plate_number';

  -- 2. ایجاد هدر سند خروج
  INSERT INTO clearances (
    clearance_no,
    doc_type_id,
    member_id, 
    customer_id, 
    clearance_date, 
    status, 
    receiver_person_name, 
    receiver_person_national_id, 
    driver_name, 
    description,
    vehicle_plate_left2,
    vehicle_plate_mid3,
    vehicle_plate_letter,
    vehicle_plate_iran_right
  )
  VALUES (
    v_clearance_no,
    5,
    (p_payload->>'member_id')::bigint,
    (p_payload->>'customer_id')::bigint,
    (p_payload->>'clearance_date')::timestamp,
    p_payload->>'status',
    p_payload->>'receiver_person_name',
    p_payload->>'receiver_person_national_id',
    p_payload->>'driver_name',
    p_payload->>'description',
    split_part(v_plate_text, '-', 1),
    split_part(v_plate_text, '-', 2),
    split_part(v_plate_text, '-', 3),
    split_part(v_plate_text, '-', 4)
  )
  RETURNING id INTO v_clearance_id;

  -- 3. حلقه روی آیتم‌ها
  FOR v_item IN SELECT * FROM json_array_elements(p_payload->'items')
  LOOP
    
    -- دریافت نام ردیف مادر (ممکن است 'بدون ردیف' باشد)
    v_parent_batch := v_item->>'parent_batch_no';

    -- جستجو در رسیدها
    -- اگر 'بدون ردیف' بود، دنبال NULL یا رشته خالی بگرد
    IF v_parent_batch = 'بدون ردیف' THEN
       SELECT count, weights_net INTO v_source_qty, v_source_weight
       FROM receipt_items 
       WHERE row_code IS NULL OR row_code = '';
    ELSE
       SELECT count, weights_net INTO v_source_qty, v_source_weight
       FROM receipt_items 
       WHERE row_code = v_parent_batch;
    END IF;

    -- اگر در رسیدها نبود، در تراکنش‌ها بگرد
    IF v_source_qty IS NULL THEN
        IF v_parent_batch = 'بدون ردیف' THEN
             SELECT qty, weight INTO v_source_qty, v_source_weight
             FROM inventory_transactions
             WHERE batch_no IS NULL OR batch_no = ''
             LIMIT 1;
        ELSE
             SELECT qty, weight INTO v_source_qty, v_source_weight
             FROM inventory_transactions
             WHERE batch_no = v_parent_batch
             LIMIT 1;
        END IF;
    END IF;

    IF v_source_qty IS NULL THEN
        RAISE EXCEPTION 'ردیف مادر یافت نشد: %', v_parent_batch USING ERRCODE = 'P0001';
    END IF;

    -- محاسبه مصرف شده‌ها
    IF v_parent_batch = 'بدون ردیف' THEN
        SELECT COALESCE(SUM(qty), 0), COALESCE(SUM(weight), 0)
        INTO v_used_qty, v_used_weight
        FROM inventory_transactions
        WHERE parent_batch_no IS NULL OR parent_batch_no = '' OR parent_batch_no = 'بدون ردیف';
    ELSE
        SELECT COALESCE(SUM(qty), 0), COALESCE(SUM(weight), 0)
        INTO v_used_qty, v_used_weight
        FROM inventory_transactions
        WHERE parent_batch_no = v_parent_batch;
    END IF;

    v_current_qty := v_source_qty - v_used_qty;
    
    IF (v_item->>'qty')::numeric > v_current_qty THEN
        RAISE EXCEPTION 'موجودی کافی نیست! درخواستی: %, موجودی: %', (v_item->>'qty'), v_current_qty USING ERRCODE = 'P0001';
    END IF;

    -- ثبت آیتم
    INSERT INTO clearance_items (
      clearance_id, 
      owner_id,
      product_id, 
      parent_batch_no, 
      new_batch_no,    
      batch_no,        
      qty, 
      weight, 
      manual_ref_id, 
      description, 
      attachment_url,
      status
    )
    VALUES (
      v_clearance_id,
      (p_payload->>'customer_id')::bigint,
      (v_item->>'product_id')::bigint,
      NULLIF(v_item->>'parent_batch_no', 'بدون ردیف'), -- اگر بدون ردیف بود، نال ذخیره کن
      NULLIF(v_item->>'new_batch_no', 'بدون ردیف'),
      NULLIF(v_item->>'new_batch_no', 'بدون ردیف'),
      (v_item->>'qty')::numeric,
      (v_item->>'weight')::numeric,
      v_item->>'manual_ref_id',
      v_item->>'description',
      v_item->>'attachment_url',
      'issued'
    );

    -- ثبت تراکنش خروج
    INSERT INTO inventory_transactions (
      type,                
      transaction_type,    
      owner_id, 
      product_id, 
      parent_batch_no, 
      batch_no, 
      qty, weight, 
      transaction_date, 
      reference_id,        
      ref_clearance_id,    
      receiver_name 
    )
    VALUES (
      'clearance',         
      'exit',              
      (p_payload->>'customer_id')::bigint,
      (v_item->>'product_id')::bigint,
      NULLIF(v_item->>'parent_batch_no', 'بدون ردیف'),
      NULLIF(v_item->>'new_batch_no', 'بدون ردیف'), 
      (v_item->>'qty')::numeric,
      (v_item->>'weight')::numeric,
      (p_payload->>'clearance_date')::timestamp,
      v_clearance_id,      
      v_clearance_id,      
      p_payload->>'receiver_person_name'
    );

  END LOOP;

  RETURN json_build_object(
    'clearance_id', v_clearance_id,
    'clearance_no', v_clearance_no,
    'status', 'success'
  );
END;
$$;


ALTER FUNCTION public.create_clearance_with_items(p_payload json) OWNER TO postgres;

--
-- Name: create_exit_permit(jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_exit_permit(p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_exit_id BIGINT;
    v_exit_no BIGINT;
    v_owner_id BIGINT;
    v_input_owner_id TEXT;
    v_loading_id BIGINT;
BEGIN
    -- 1. استخراج ورودی‌ها
    v_input_owner_id := p_payload->>'owner_id';
    v_loading_id := (p_payload->>'loading_order_id')::BIGINT;

    -- 2. تعیین صاحب کالا
    IF v_input_owner_id IS NOT NULL AND v_input_owner_id <> 'undefined' AND v_input_owner_id <> 'null' THEN
        v_owner_id := v_input_owner_id::BIGINT;
    ELSE
        SELECT c.customer_id INTO v_owner_id
        FROM loading_orders lo
        JOIN clearances c ON lo.clearance_id = c.id
        WHERE lo.id = v_loading_id;
    END IF;

    -- 3. ثبت هدر خروج
    INSERT INTO warehouse_exits (
        loading_order_id,
        owner_id,
        driver_name,
        plate_number,
        exit_date,
        status,
        description,
        reference_no,
        total_loading_fee,
        weighbridge_fee,
        total_fee,
        extra_fee,
        extra_description,
        vat_fee,
        driver_national_code,
        payment_method,
        is_sent_to_tax
    ) VALUES (
        v_loading_id,
        v_owner_id,
        p_payload->>'driver_name',
        p_payload->>'plate_number',
        (p_payload->>'exit_date')::TIMESTAMP,
        p_payload->>'status',
        p_payload->>'description',
        p_payload->>'reference_no',
        COALESCE(NULLIF(p_payload->>'total_loading_fee', 'NaN')::NUMERIC, 0),
        COALESCE(NULLIF(p_payload->>'weighbridge_fee', 'NaN')::NUMERIC, 0),
        COALESCE(NULLIF(p_payload->>'total_fee', 'NaN')::NUMERIC, 0),
        COALESCE(NULLIF(p_payload->>'extra_fee', 'NaN')::NUMERIC, 0),
        p_payload->>'extra_description',
        COALESCE(NULLIF(p_payload->>'vat_fee', 'NaN')::NUMERIC, 0),
        p_payload->>'driver_national_code',
        p_payload->>'payment_method',
        false
    )
    RETURNING id, exit_no INTO v_exit_id, v_exit_no;

    -- 4. ثبت اقلام (همراه با QTY)
    IF p_payload ? 'items' AND jsonb_array_length(p_payload->'items') > 0 THEN
        INSERT INTO warehouse_exit_items (
            warehouse_exit_id,
            loading_item_id,
            weight_full,
            weight_empty,
            weight_net,
            qty,                -- ✅ ستون qty اضافه شد
            fee_type,
            fee_price,
            final_fee,
            loading_fee
        )
        SELECT
            v_exit_id,
            (item->>'loading_item_id')::BIGINT,
            COALESCE(NULLIF(item->>'weight_full', 'NaN')::NUMERIC, 0),
            COALESCE(NULLIF(item->>'weight_empty', 'NaN')::NUMERIC, 0),
            COALESCE(NULLIF(item->>'weight_net', 'NaN')::NUMERIC, 0),
            
            -- ✅ دریافت مقدار qty و ذخیره در دیتابیس
            COALESCE(NULLIF(item->>'qty', 'NaN')::NUMERIC, 0),
            
            item->>'fee_type',
            COALESCE(NULLIF(item->>'fee_price', 'NaN')::NUMERIC, 0),
            COALESCE(NULLIF(item->>'final_fee', 'NaN')::NUMERIC, 0),
            COALESCE(NULLIF(item->>'loading_fee', 'NaN')::NUMERIC, 0)
        FROM jsonb_array_elements(p_payload->'items') AS item;
    END IF;

    RETURN jsonb_build_object('id', v_exit_id, 'exit_no', v_exit_no, 'status', 'success');
EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object('status', 'error', 'message', SQLERRM);
END;
$$;


ALTER FUNCTION public.create_exit_permit(p_payload jsonb) OWNER TO postgres;

--
-- Name: create_full_receipt(jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_full_receipt(payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- متغیرهای رسید
    v_receipt_id UUID;
    v_receipt_no BIGINT;
    v_item JSONB;
    v_owner_id UUID;
    v_member_id UUID;
    v_doc_date DATE;
    v_status TEXT;
    v_desc TEXT;
    
    -- متغیرهای مالی
    v_load_cost NUMERIC := COALESCE((payload->>'load_cost')::NUMERIC, 0);
    v_unload_cost NUMERIC := COALESCE((payload->>'unload_cost')::NUMERIC, 0);
    v_warehouse_cost NUMERIC := COALESCE((payload->>'warehouse_cost')::NUMERIC, 0);
    v_tax NUMERIC := COALESCE((payload->>'tax')::NUMERIC, 0);
    v_misc_cost NUMERIC := COALESCE((payload->>'misc_cost')::NUMERIC, 0);
    v_other_costs NUMERIC := COALESCE((payload->>'loading_fee')::NUMERIC, 0) + COALESCE((payload->>'return_freight')::NUMERIC, 0);
    
    v_total_amount NUMERIC;
    v_payment_by TEXT;
    v_source_id UUID;
    v_source_type TEXT; -- 'cash' یا 'bank'
    v_fin_doc_id UUID;
BEGIN
    -- 1. محاسبه جمع کل و استخراج داده‌ها
    v_total_amount := v_load_cost + v_unload_cost + v_warehouse_cost + v_tax + v_misc_cost + v_other_costs;
    
    v_owner_id := (payload->>'owner_id')::UUID;
    v_member_id := (payload->>'member_id')::UUID; 
    v_doc_date := COALESCE((payload->>'doc_date')::DATE, CURRENT_DATE);
    v_status := payload->>'status';
    v_desc := payload->>'description';
    v_payment_by := payload->>'payment_by';
    
    -- استخراج اطلاعات منبع پرداخت (اگر انبار پرداخت کند)
    v_source_id := NULLIF((payload->>'payment_source_id'), '')::UUID;
    v_source_type := payload->>'payment_source_type'; 

    -- 2. ثبت هدر رسید (Receipt Header)
    INSERT INTO receipts (
        receipt_no, doc_date, owner_id, member_id, status, description,
        driver_name, driver_national_id, driver_phone,
        plate_iran_right, plate_mid3, plate_letter, plate_left2,
        ref_type, ref_barnameh_number, ref_barnameh_date, ref_barnameh_tracking,
        ref_petteh_number, ref_havale_number, ref_production_number,
        load_cost, unload_cost, warehouse_cost, tax, misc_cost, loading_fee, return_freight,
        payment_by, payment_amount, payment_source_id, payment_source_type,
        created_at, updated_at
    ) VALUES (
        (payload->>'receipt_no'),
        v_doc_date,
        v_owner_id,
        v_member_id,
        v_status,
        v_desc,
        (payload->>'driver_name'),
        (payload->>'driver_national_id'),
        (payload->>'driver_phone'),
        (payload->'plate'->>'iran'),
        (payload->'plate'->>'mid3'),
        (payload->'plate'->>'letter'),
        (payload->'plate'->>'left2'),
        (payload->>'ref_type'),
        (payload->>'barnameh_number'),
        (payload->>'barnameh_date')::DATE,
        (payload->>'barnameh_tracking'),
        (payload->>'petteh_number'),
        (payload->>'havale_number'),
        (payload->>'production_number'),
        v_load_cost, v_unload_cost, v_warehouse_cost, v_tax, v_misc_cost, 
        COALESCE((payload->>'loading_fee')::NUMERIC, 0), 
        COALESCE((payload->>'return_freight')::NUMERIC, 0),
        v_payment_by,
        v_total_amount,
        v_source_id,
        v_source_type,
        NOW(), NOW()
    ) RETURNING id, receipt_no INTO v_receipt_id, v_receipt_no;

    -- 3. ثبت آیتم‌های رسید (Receipt Items)
    FOR v_item IN SELECT * FROM jsonb_array_elements(payload->'items')
    LOOP
        INSERT INTO receipt_items (
            receipt_id, owner_id, member_id, product_id, count, 
            weights_full, weights_empty, weights_net, 
            description_notes, created_at
        ) VALUES (
            v_receipt_id,
            v_owner_id,
            v_member_id,
            (v_item->>'product_id')::UUID,
            (v_item->>'count')::NUMERIC,
            (v_item->>'weights_full')::NUMERIC,
            (v_item->>'weights_empty')::NUMERIC,
            (v_item->>'weights_net')::NUMERIC,
            (v_item->>'description_notes'),
            NOW()
        );
    END LOOP;

    -- ====================================================
    -- 4. ثبت سند حسابداری (Accounting)
    -- ====================================================
    IF v_status = 'final' AND v_total_amount > 0 THEN
        
        -- حالت اول: پرداخت توسط انبار (پول از جیب انبار رفته است)
        -- نتیجه: مشتری بدهکار می‌شود / صندوق یا بانک بستانکار می‌شود
        IF v_payment_by = 'warehouse' THEN
            
            -- بررسی الزامی بودن منبع
            IF v_source_id IS NULL OR v_source_type IS NULL THEN
                RAISE EXCEPTION 'جهت ثبت پرداخت توسط انبار، انتخاب صندوق یا بانک الزامی است.';
            END IF;

            -- الف) ایجاد هدر سند مالی
            INSERT INTO financial_docs (
                member_id, ref_type, ref_id, doc_date, doc_no, description, total_amount, status, created_at
            ) VALUES (
                v_member_id,
                'receipt',       -- نوع رفرنس
                v_receipt_id,    -- آی‌دی رسید
                v_doc_date,
                v_receipt_no,    -- شماره رسید به عنوان شماره سند
                'سند پرداخت بابت رسید انبار شماره ' || v_receipt_no || COALESCE(' - ' || v_desc, ''),
                v_total_amount,
                'confirmed',
                NOW()
            ) RETURNING id INTO v_fin_doc_id;

            -- ب) ثبت طرف بدهکار (مشتری)
            INSERT INTO financial_items (
                doc_id, account_type, account_id, debtor, creditor, description
            ) VALUES (
                v_fin_doc_id, 
                'customer',      -- نوع حساب: مشتری
                v_owner_id,      -- آی‌دی مشتری
                v_total_amount,  -- مبلغ بدهکار (چون ما برایش هزینه کردیم)
                0, 
                'بابت هزینه‌های رسید شماره ' || v_receipt_no
            );

            -- ج) ثبت طرف بستانکار (بانک یا صندوق)
            INSERT INTO financial_items (
                doc_id, account_type, account_id, debtor, creditor, description
            ) VALUES (
                v_fin_doc_id, 
                v_source_type,   -- 'bank' یا 'cash'
                v_source_id,     -- آی‌دی دقیق بانک/صندوق
                0, 
                v_total_amount,  -- مبلغ بستانکار (چون پول کم شده)
                'پرداخت وجه بابت رسید شماره ' || v_receipt_no
            );

        -- حالت دوم: پرداخت به عهده مشتری (نسیه)
        -- نتیجه: مشتری بدهکار می‌شود / درآمد انبار بستانکار می‌شود
        ELSIF v_payment_by = 'customer' THEN
             
             INSERT INTO financial_docs (
                member_id, ref_type, ref_id, doc_date, doc_no, description, total_amount, status, created_at
            ) VALUES (
                v_member_id, 'receipt', v_receipt_id, v_doc_date, v_receipt_no,
                'شناسایی درآمد رسید ' || v_receipt_no, v_total_amount, 'confirmed', NOW()
            ) RETURNING id INTO v_fin_doc_id;

            -- بدهکار: مشتری
            INSERT INTO financial_items (doc_id, account_type, account_id, debtor, creditor, description)
            VALUES (v_fin_doc_id, 'customer', v_owner_id, v_total_amount, 0, 'خدمات انبارداری رسید ' || v_receipt_no);

            -- بستانکار: درآمد
            INSERT INTO financial_items (doc_id, account_type, account_id, debtor, creditor, description)
            VALUES (v_fin_doc_id, 'income', NULL, 0, v_total_amount, 'درآمد خدمات انبارداری');
        END IF;

    END IF;

    -- خروجی نهایی
    RETURN jsonb_build_object(
        'success', true,
        'data', jsonb_build_object(
            'id', v_receipt_id,
            'receipt_no', v_receipt_no,
            'total_amount', v_total_amount
        ),
        'message', 'رسید و سند مالی با موفقیت ثبت شد'
    );

EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object('success', false, 'error', SQLERRM, 'detail', SQLSTATE);
END;
$$;


ALTER FUNCTION public.create_full_receipt(payload jsonb) OWNER TO postgres;

--
-- Name: create_loading_order(json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_loading_order(p_payload json) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_order_id bigint;
  v_order_no bigint;
  v_item json;
BEGIN
  -- 1. تولید شماره سریال (مثلا از 5000 شروع بشه)
  SELECT COALESCE(MAX(order_no), 5000) + 1 INTO v_order_no FROM loading_orders;

  -- 2. ثبت هدر دستور بارگیری
  INSERT INTO loading_orders (
    order_no, clearance_id, loading_date, 
    driver_name, plate_number, warehouse_keeper_id, description
  )
  VALUES (
    v_order_no,
    (p_payload->>'clearance_id')::bigint,
    (p_payload->>'loading_date')::timestamp,
    p_payload->>'driver_name',
    p_payload->>'plate_number',
    (p_payload->>'user_id')::bigint,
    p_payload->>'description'
  )
  RETURNING id INTO v_order_id;

  -- 3. ثبت اقلام
  FOR v_item IN SELECT * FROM json_array_elements(p_payload->'items')
  LOOP
    INSERT INTO loading_order_items (
      loading_order_id, clearance_item_id, product_id, batch_no, qty, weight
    )
    VALUES (
      v_order_id,
      (v_item->>'clearance_item_id')::bigint,
      (v_item->>'product_id')::bigint,
      v_item->>'batch_no',
      (v_item->>'qty')::numeric,
      (v_item->>'weight')::numeric
    );
  END LOOP;

  RETURN json_build_object('id', v_order_id, 'order_no', v_order_no, 'status', 'success');
END;
$$;


ALTER FUNCTION public.create_loading_order(p_payload json) OWNER TO postgres;

--
-- Name: create_receipt_with_items(jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_receipt_with_items(p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
DECLARE
  v_receipt_id BIGINT;
  v_receipt_no BIGINT;
  v_real_member_id BIGINT;
  v_input_val TEXT;
  v_count INTEGER;
  v_item JSONB;
BEGIN
  -- ۱. دریافت مقدار عضو از پلود (هر چه که باشد: متن یا عدد)
  v_input_val := p_payload->>'member_id';

  -- ۲. منطق تبدیل اضطراری (اگر UUID فرستاده شده بود، اینجا اصلاح می‌شود)
  IF v_input_val ~ '^[0-9a-fA-F-]{36}$' THEN
      -- اگر ورودی UUID بود (همان 1706...) برو و آیدی عددی را پیدا کن
      SELECT id INTO v_real_member_id FROM members WHERE auth_user_id::text = v_input_val;
  ELSE
      -- اگر ورودی عدد بود، همان را استفاده کن
      v_real_member_id := v_input_val::BIGINT;
  END IF;

  -- ۳. اگر باز هم پیدا نشد، از شناسه کاربر فعلی لاگین شده در Supabase استفاده کن
  IF v_real_member_id IS NULL THEN
      SELECT id INTO v_real_member_id FROM members WHERE auth_user_id = auth.uid();
  END IF;

  -- ۴. محاسبه شماره رسید (فرمول ۲۱۰۱)
  SELECT COUNT(*) INTO v_count FROM receipts WHERE member_id = v_real_member_id;
  v_receipt_no := (v_real_member_id * 1000) + 100 + (v_count + 1);

  -- ۵. ثبت هدر رسید
  INSERT INTO receipts (
    member_id,
    receipt_no,
    doc_type_id,
    status,
    doc_date,
    owner_id,
    driver_name,
    plate_iran_right,
    plate_mid3,
    plate_letter,
    plate_left2
  ) VALUES (
    v_real_member_id,
    v_receipt_no,
    (p_payload->>'doc_type_id')::BIGINT,
    COALESCE(p_payload->>'status', 'draft'),
    (p_payload->>'doc_date')::DATE,
    (p_payload->>'owner_id')::BIGINT,
    p_payload->>'driver_name',
    p_payload->>'plate_iran_right',
    p_payload->>'plate_mid3',
    p_payload->>'plate_letter',
    p_payload->>'plate_left2'
  )
  RETURNING id INTO v_receipt_id;

  -- ۶. ثبت آیتم‌ها با تبدیل ایمن
  FOR v_item IN SELECT * FROM jsonb_array_elements(p_payload->'items')
  LOOP
    INSERT INTO receipt_items (
      receipt_id, product_id, owner_id, count, weights_net
    ) VALUES (
      v_receipt_id,
      (v_item->>'product_id')::BIGINT,
      (p_payload->>'owner_id')::BIGINT,
      COALESCE((v_item->>'count')::NUMERIC, 0),
      COALESCE((v_item->>'weights_net')::NUMERIC, 0)
    );
  END LOOP;

  -- بازگرداندن نتیجه نهایی
  RETURN jsonb_build_object(
    'receipt_id', v_receipt_id,
    'receipt_no', v_receipt_no,
    'member_id', v_real_member_id
  );

EXCEPTION WHEN OTHERS THEN
  -- گزارش خطای دقیق برای دیباگ
  RAISE EXCEPTION 'Database Error: %, Value: %', SQLERRM, v_input_val;
END;
$_$;


ALTER FUNCTION public.create_receipt_with_items(p_payload jsonb) OWNER TO postgres;

--
-- Name: create_tafsili_for_customer(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_tafsili_for_customer() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO accounting_tafsili (title, tafsili_type, ref_id, code)
    VALUES (
        NEW.name, 
        'customer', 
        NEW.id, 
        (SELECT lpad((count(*)+1)::text, 4, '0') FROM accounting_tafsili WHERE tafsili_type='customer')
    );
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.create_tafsili_for_customer() OWNER TO postgres;

--
-- Name: delete_clearance(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.delete_clearance(p_clearance_id bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  is_locked boolean;
BEGIN
  -- 1. بررسی قفل بودن
  is_locked := check_clearance_locked(p_clearance_id);
  
  IF is_locked THEN
    RAISE EXCEPTION 'این سند دارای دستور بارگیری یا عملیات بعدی است و قابل حذف نیست.' USING ERRCODE = 'P0001';
  END IF;

  -- 2. عملیات حذف (اگر قفل نبود)
  DELETE FROM inventory_transactions 
  WHERE ref_clearance_id = p_clearance_id AND transaction_type = 'exit';

  DELETE FROM clearance_items 
  WHERE clearance_id = p_clearance_id;

  DELETE FROM clearances 
  WHERE id = p_clearance_id;

  RETURN json_build_object('status', 'success');
END;
$$;


ALTER FUNCTION public.delete_clearance(p_clearance_id bigint) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    sku text NOT NULL,
    category_id uuid NOT NULL,
    unit_id uuid NOT NULL,
    min_stock numeric DEFAULT 0,
    max_stock numeric,
    location text,
    price numeric,
    cost_price numeric,
    description text,
    specifications text,
    barcode text,
    batch_number text,
    expire_date date,
    member_id uuid,
    is_active boolean DEFAULT true,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    national_id text,
    national_title text,
    owner_id uuid,
    image_url text,
    quantity numeric DEFAULT 0,
    nwms_good_id text,
    nwms_measurement_unit text,
    nwms_production_type text DEFAULT '1'::text
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: effective_loading_cost(public.products); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.effective_loading_cost(product_row public.products) RETURNS numeric
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
  my_cost numeric;
  parent_cost numeric;
  pid bigint;
BEGIN
  SELECT loading_cost, parent_id INTO my_cost, pid
  FROM public.product_categories
  WHERE id = product_row.category_id;

  IF my_cost > 0 THEN
    RETURN my_cost;
  END IF;

  IF pid IS NULL THEN
    RETURN 0;
  END IF;

  SELECT loading_cost INTO parent_cost
  FROM public.product_categories
  WHERE id = pid;

  RETURN COALESCE(parent_cost, 0);
END;
$$;


ALTER FUNCTION public.effective_loading_cost(product_row public.products) OWNER TO postgres;

--
-- Name: effective_storage_cost(public.products); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.effective_storage_cost(product_row public.products) RETURNS numeric
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
  my_cost numeric;
  parent_cost numeric;
  pid bigint;
BEGIN
  -- دریافت قیمت و آیدی پدرِ دسته بندیِ این محصول
  SELECT storage_cost, parent_id INTO my_cost, pid
  FROM public.product_categories
  WHERE id = product_row.category_id;

  -- اگر خود دسته قیمت داشت، همان را برگردان
  IF my_cost > 0 THEN
    RETURN my_cost;
  END IF;

  -- اگر پدر نداشت، صفر برگردان
  IF pid IS NULL THEN
    RETURN 0;
  END IF;

  -- اگر پدر داشت، قیمت پدر را بخوان
  SELECT storage_cost INTO parent_cost
  FROM public.product_categories
  WHERE id = pid;

  RETURN COALESCE(parent_cost, 0);
END;
$$;


ALTER FUNCTION public.effective_storage_cost(product_row public.products) OWNER TO postgres;

--
-- Name: clearance_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clearance_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clearance_id uuid NOT NULL,
    product_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    qty numeric DEFAULT 0,
    weight numeric DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    parent_batch_no text,
    new_batch_no text,
    manual_ref_id text,
    attachment_url text,
    status text DEFAULT 'issued'::text,
    description text,
    batch_no text
);


ALTER TABLE public.clearance_items OWNER TO postgres;

--
-- Name: entry_date(public.clearance_items); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.entry_date(clearance_item public.clearance_items) RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
  RETURN (
    SELECT r.receipt_date::text
    FROM public.receipt_items ri
    JOIN public.receipts r ON r.id = ri.receipt_id
    -- اتصال بر اساس شماره ردیف (اگر نام ستون در ترخیص چیز دیگری است، اینجا تغییر دهید)
    WHERE ri.batch_no = clearance_item.parent_batch_no 
       OR ri.batch_no = clearance_item.batch_no
    LIMIT 1
  );
END;
$$;


ALTER FUNCTION public.entry_date(clearance_item public.clearance_items) OWNER TO postgres;

--
-- Name: find_exit_or_loading_data(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.find_exit_or_loading_data(p_search_term text) RETURNS jsonb
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_result JSONB;
    v_exit_record RECORD;
    v_loading_record RECORD;
BEGIN
    -- 1. جستجو در خروجی‌های ثبت شده (ویرایش/مشاهده)
    IF p_search_term ~ '^[0-9]+$' THEN
        SELECT * INTO v_exit_record FROM warehouse_exits 
        WHERE id = p_search_term::BIGINT OR exit_no = p_search_term::BIGINT 
        LIMIT 1;
        
        IF FOUND THEN
            SELECT jsonb_build_object(
                'is_processed', true,
                'exit_id', v_exit_record.id,
                'exit_no', v_exit_record.exit_no,
                'status', v_exit_record.status,
                'driver_name', v_exit_record.driver_name,
                'plate_number', v_exit_record.plate_number,
                'exit_date', v_exit_record.exit_date,
                'loading_id', v_exit_record.loading_order_id,
                -- دریافت نام مشتری
                'customer_name', (SELECT name FROM customers WHERE id = v_exit_record.owner_id),
                'customer_id', v_exit_record.owner_id,
                'items', (
                    SELECT jsonb_agg(jsonb_build_object(
                        'id', wei.loading_item_id,
                        'product_name', p.name, -- نام کالا از پروداکت
                        'qty', wei.qty,
                        'weight_full', wei.weight_full,
                        'weight_empty', wei.weight_empty,
                        'weight_net', wei.weight_net,
                        'base_storage_rate', wei.fee_price,
                        'row_storage_fee', wei.final_fee,
                        'row_loading_fee', wei.loading_fee
                    ))
                    FROM warehouse_exit_items wei
                    LEFT JOIN loading_order_items loi ON wei.loading_item_id = loi.id
                    LEFT JOIN products p ON loi.product_id = p.id
                    WHERE wei.warehouse_exit_id = v_exit_record.id
                )
            ) INTO v_result;
            RETURN v_result;
        END IF;
    END IF;

    -- 2. جستجو در سفارش‌های بارگیری (ثبت جدید)
    IF p_search_term ~ '^[0-9]+$' THEN
        SELECT 
            lo.id, 
            lo.order_no, 
            lo.driver_name, 
            lo.plate_number,
            cust.id as owner_id,
            cust.name as owner_name
        INTO v_loading_record
        FROM loading_orders lo
        -- ✅ اتصال صحیح طبق دیتابیس شما:
        -- loading_orders -> clearances -> customers
        INNER JOIN clearances c ON lo.clearance_id = c.id
        INNER JOIN customers cust ON c.customer_id = cust.id
        WHERE lo.order_no = p_search_term::BIGINT
        LIMIT 1;

        IF FOUND THEN
            SELECT jsonb_build_object(
                'is_processed', false,
                'loading_id', v_loading_record.id,
                'order_no', v_loading_record.order_no,
                'driver_name', v_loading_record.driver_name,
                'plate_number', v_loading_record.plate_number,
                'customer_name', v_loading_record.owner_name,
                'customer_id', v_loading_record.owner_id,
                
                -- دریافت اقلام بارگیری
                'items', (
                    SELECT jsonb_agg(jsonb_build_object(
                        'id', loi.id,
                        'product_name', p.name,
                        'qty', loi.qty,
                        'weight_full', 0,
                        'weight_empty', 0,
                        'weight_net', loi.weight, -- وزن پیش فرض از بارگیری
                        'base_storage_rate', 0,
                        'base_loading_rate', 0
                    ))
                    FROM loading_order_items loi
                    LEFT JOIN products p ON loi.product_id = p.id
                    WHERE loi.loading_order_id = v_loading_record.id
                )
            ) INTO v_result;
            
            RETURN v_result;
        END IF;
    END IF;

    RETURN NULL;
END;
$_$;


ALTER FUNCTION public.find_exit_or_loading_data(p_search_term text) OWNER TO postgres;

--
-- Name: fn_auto_exit_inventory(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_auto_exit_inventory() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE
        v_product_id uuid;
        v_owner_id uuid;
        v_batch_no text;
        v_qty numeric;
    BEGIN
        SELECT 
            loi.product_id,
            c.customer_id,
            loi.batch_no,
            loi.qty
        INTO 
            v_product_id,
            v_owner_id,
            v_batch_no,
            v_qty
        FROM public.loading_order_items loi
        JOIN public.loading_orders lo ON lo.id = loi.loading_order_id
        JOIN public.clearances c ON c.id = lo.clearance_id
        WHERE loi.id = NEW.loading_item_id;

        INSERT INTO public.inventory_transactions (
            type, product_id, owner_id, qty, weight, batch_no, ref_exit_id, created_at, description
        ) VALUES (
            'exit', v_product_id, v_owner_id, v_qty, NEW.weight_net, v_batch_no,
            NEW.warehouse_exit_id, NOW(), 'خروج خودکار سیستمی (باسکول)'
        );

        RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.fn_auto_exit_inventory() OWNER TO postgres;

--
-- Name: fn_trigger_sync_clearance(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_trigger_sync_clearance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- فقط برای INSERT یا UPDATE با status = final
  IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') AND NEW.status IN ('final', 'issued') THEN
    PERFORM sync_clearance_inventory(NEW.id);
  END IF;
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_trigger_sync_clearance() OWNER TO postgres;

--
-- Name: get_all_loading_orders(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_all_loading_orders() RETURNS TABLE(id bigint, order_no bigint, loading_date timestamp without time zone, driver_name text, plate_number text, customer_name text, items_count bigint, total_weight numeric, is_exited boolean, exit_permit_no bigint)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    lo.id,
    lo.order_no,
    lo.loading_date,
    lo.driver_name,
    lo.plate_number,
    cus.name as customer_name,
    
    -- تعداد اقلام
    (SELECT COUNT(*) FROM loading_order_items loi WHERE loi.loading_order_id = lo.id) as items_count,
    
    -- جمع وزن
    (SELECT COALESCE(SUM(weight), 0) FROM loading_order_items loi WHERE loi.loading_order_id = lo.id) as total_weight,
    
    -- ✅ بررسی وضعیت خروج: آیا این دستور در جدول خروج هست؟
    EXISTS(SELECT 1 FROM warehouse_exits we WHERE we.loading_order_id = lo.id) as is_exited,
    
    -- شماره برگه خروج (جهت نمایش)
    (SELECT we.exit_no FROM warehouse_exits we WHERE we.loading_order_id = lo.id LIMIT 1) as exit_permit_no
    
  FROM loading_orders lo
  JOIN clearances cl ON lo.clearance_id = cl.id
  JOIN customers cus ON cl.customer_id = cus.id
  ORDER BY lo.loading_date DESC;
END;
$$;


ALTER FUNCTION public.get_all_loading_orders() OWNER TO postgres;

--
-- Name: get_available_batches_by_owner(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_available_batches_by_owner(p_owner_id bigint) RETURNS TABLE(batch_no text, product_id bigint, product_title text, qty_initial numeric, qty_cleared numeric, qty_available numeric, weight_available numeric, next_index integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    -- اگر row_code نال بود، موقتا ID را نشان بده تا خطا ندهد، وگرنه خود row_code را برگردان
    COALESCE(ri.row_code, ri.id::text) as batch_no,
    
    ri.product_id,
    p.name as product_title, -- نام کالا
    ri.count::numeric as qty_initial, -- تعداد اولیه
    
    -- محاسبه تعداد خارج شده (بر اساس row_code)
    COALESCE((SELECT SUM(ci.qty) 
              FROM clearance_items ci 
              WHERE ci.parent_batch_no = COALESCE(ri.row_code, ri.id::text)), 0) as qty_cleared,
    
    -- موجودی واقعی (تعداد)
    (ri.count::numeric - COALESCE((SELECT SUM(ci.qty) 
                                   FROM clearance_items ci 
                                   WHERE ci.parent_batch_no = COALESCE(ri.row_code, ri.id::text)), 0)) as qty_available,
    
    -- موجودی واقعی (وزن خالص)
    (ri.weights_net::numeric - COALESCE((SELECT SUM(ci.weight) 
                                         FROM clearance_items ci 
                                         WHERE ci.parent_batch_no = COALESCE(ri.row_code, ri.id::text)), 0)) as weight_available,

    -- محاسبه ایندکس بعدی (برای تولید شماره‌هایی مثل 770/1)
    COALESCE((SELECT MAX(CAST(SPLIT_PART(ci.new_batch_no, '/', 2) AS INTEGER)) 
              FROM clearance_items ci 
              WHERE ci.parent_batch_no = COALESCE(ri.row_code, ri.id::text)), 0) + 1 as next_index

  FROM receipt_items ri
  JOIN receipts r ON ri.receipt_id = r.id
  JOIN products p ON ri.product_id = p.id
  WHERE r.owner_id = p_owner_id
  
  -- شرط: فقط ردیف‌هایی که موجودی مثبت دارند
  AND (ri.count::numeric - COALESCE((SELECT SUM(ci.qty) 
                                     FROM clearance_items ci 
                                     WHERE ci.parent_batch_no = COALESCE(ri.row_code, ri.id::text)), 0)) > 0;
END;
$$;


ALTER FUNCTION public.get_available_batches_by_owner(p_owner_id bigint) OWNER TO postgres;

--
-- Name: get_batches_by_product(bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_batches_by_product(p_owner_id bigint, p_product_id bigint) RETURNS TABLE(batch_no text, qty_available numeric, weight_available numeric, next_index integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  WITH grouped_batches AS (
    SELECT 
      -- استفاده از row_code یا id به عنوان کلید
      COALESCE(ri.row_code, ri.id::text) as batch_key,
      SUM(ri.count::numeric) as total_initial_qty,
      SUM(ri.weights_net::numeric) as total_initial_weight
    FROM receipt_items ri
    JOIN receipts r ON ri.receipt_id = r.id
    WHERE r.owner_id = p_owner_id 
    AND ri.product_id = p_product_id
    GROUP BY COALESCE(ri.row_code, ri.id::text)
  )
  SELECT 
    gb.batch_key as batch_no,
    
    -- محاسبه موجودی تعدادی
    (gb.total_initial_qty - COALESCE((SELECT SUM(ci.qty) 
                                      FROM clearance_items ci 
                                      WHERE ci.parent_batch_no = gb.batch_key), 0)) as qty_available,
    
    -- محاسبه موجودی وزنی
    (gb.total_initial_weight - COALESCE((SELECT SUM(ci.weight) 
                                         FROM clearance_items ci 
                                         WHERE ci.parent_batch_no = gb.batch_key), 0)) as weight_available,

    -- *** تغییر کلیدی برای پشتیبانی از عمق نامحدود ***
    -- منطق: طول رشته مادر را بگیر، ۲ تا اضافه کن (یکی برای اسلش، یکی برای رفتن به کاراکتر بعدی) و بقیه را بخوان
    COALESCE((
      SELECT MAX(
        CAST(
          SUBSTRING(ci.new_batch_no FROM LENGTH(gb.batch_key) + 2) 
        AS INTEGER)
      ) 
      FROM clearance_items ci 
      WHERE ci.parent_batch_no = gb.batch_key
      -- شرط اطمینان: فقط مواردی که واقعا با اسلش شروع می‌شوند را بشمار
      AND ci.new_batch_no LIKE gb.batch_key || '/%'
    ), 0) + 1 as next_index

  FROM grouped_batches gb
  
  -- شرط نمایش: موجودی مثبت باشد
  WHERE (gb.total_initial_qty - COALESCE((SELECT SUM(ci.qty) 
                                           FROM clearance_items ci 
                                           WHERE ci.parent_batch_no = gb.batch_key), 0)) > 0;
END;
$$;


ALTER FUNCTION public.get_batches_by_product(p_owner_id bigint, p_product_id bigint) OWNER TO postgres;

--
-- Name: get_batches_with_history(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_batches_with_history(p_owner_id text, p_product_id text) RETURNS json
    LANGUAGE plpgsql
    AS $_$
DECLARE
  result json;
BEGIN
  SELECT json_agg(t) INTO result
  FROM (
    SELECT 
      COALESCE(ri.row_code, 'بدون ردیف') as batch_no,
      ri.product_id,
      
      -- ==========================================================
      -- اصلاح مهم: محاسبه موجودی واقعی (ورودی - خروجی)
      -- ==========================================================
      (SUM(ri.count) - COALESCE((
          SELECT SUM(qty) 
          FROM inventory_transactions it
          WHERE it.product_id = ri.product_id 
            AND it.owner_id = p_owner_id::bigint
            -- جمع زدن تمام خروجی‌هایی که از این ردیف مادر (parent) کم شده‌اند
            AND it.parent_batch_no IS NOT DISTINCT FROM ri.row_code
      ), 0)) as qty_available,

      (SUM(ri.weights_net) - COALESCE((
          SELECT SUM(weight) 
          FROM inventory_transactions it
          WHERE it.product_id = ri.product_id 
            AND it.owner_id = p_owner_id::bigint
            AND it.parent_batch_no IS NOT DISTINCT FROM ri.row_code
      ), 0)) as weight_available,
      -- ==========================================================

      -- تاریخچه فرزندان
      COALESCE((
        SELECT json_agg(it)
        FROM inventory_transactions it
        WHERE it.product_id = ri.product_id 
          AND it.owner_id = p_owner_id::bigint
          AND it.batch_no LIKE (COALESCE(ri.row_code, 'بدون ردیف') || '/%') 
      ), '[]'::json) as history,
      
      -- ایندکس بعدی
      (SELECT COALESCE(MAX(CAST(SUBSTRING(batch_no FROM '/([0-9]+)$') AS INTEGER)), 0) + 1
       FROM inventory_transactions 
       WHERE batch_no LIKE (COALESCE(ri.row_code, 'بدون ردیف') || '/%')
      ) as next_index

    FROM receipt_items ri
    JOIN receipts r ON ri.receipt_id = r.id
    WHERE r.owner_id = p_owner_id::bigint
      AND ri.product_id = p_product_id::bigint
    GROUP BY ri.row_code, ri.product_id
  ) t;

  RETURN COALESCE(result, '[]'::json);
END;
$_$;


ALTER FUNCTION public.get_batches_with_history(p_owner_id text, p_product_id text) OWNER TO postgres;

--
-- Name: get_current_member_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_current_member_id() RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN (
        SELECT id 
        FROM public.members 
        WHERE auth_user_id = auth.uid() 
        OR id::text = auth.uid()::text
        LIMIT 1
    );
END;
$$;


ALTER FUNCTION public.get_current_member_id() OWNER TO postgres;

--
-- Name: get_customer_pending_items(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_customer_pending_items(p_customer_id bigint) RETURNS TABLE(item_id bigint, clearance_id bigint, clearance_no bigint, product_id bigint, product_name text, batch_no text, qty numeric, weight numeric, arrival_date date, deliverer_name text, national_code text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ci.id as item_id,
    cl.id as clearance_id,
    cl.clearance_no,
    p.id as product_id,
    p.name as product_name,
    COALESCE(ci.new_batch_no, ci.batch_no, '') as batch_no,
    ci.qty,
    ci.weight,
    cl.clearance_date,
    
    -- ✅ اصلاح نام ستون‌ها طبق JSON شما:
    -- اگر شخص بود نام شخص، اگر شرکت بود نام شرکت را برگردان
    COALESCE(cl.receiver_person_name, cl.receiver_company_name) as deliverer_name,
    
    -- اصلاح کد ملی
    COALESCE(cl.receiver_person_national_id, cl.receiver_company_registration_no) as national_code

  FROM clearance_items ci
  JOIN clearances cl ON ci.clearance_id = cl.id
  JOIN products p ON ci.product_id = p.id
  WHERE 
    cl.customer_id = p_customer_id
    AND
    NOT EXISTS (
      SELECT 1 FROM loading_order_items loi 
      WHERE loi.clearance_item_id = ci.id
    )
  ORDER BY cl.clearance_date ASC;
END;
$$;


ALTER FUNCTION public.get_customer_pending_items(p_customer_id bigint) OWNER TO postgres;

--
-- Name: get_customers_with_stock(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_customers_with_stock() RETURNS TABLE(id bigint, name text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT cus.id, cus.name
  FROM clearance_items ci
  JOIN clearances cl ON ci.clearance_id = cl.id
  JOIN customers cus ON cl.customer_id = cus.id
  WHERE 
    -- شرط: آیتمی که در جدول بارگیری نباشد
    NOT EXISTS (
      SELECT 1 FROM loading_order_items loi 
      WHERE loi.clearance_item_id = ci.id
    )
  ORDER BY cus.name;
END;
$$;


ALTER FUNCTION public.get_customers_with_stock() OWNER TO postgres;

--
-- Name: get_loading_order_details(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_loading_order_details(p_order_id bigint) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_header json;
  v_items json;
BEGIN
  -- هدر
  SELECT json_build_object(
    'order_no', lo.order_no,
    'loading_date', lo.loading_date,
    'driver_name', lo.driver_name,
    'plate_number', lo.plate_number,
    'customer_name', cus.name,
    'clearance_no', c.clearance_no,
    'description', c.description
  ) INTO v_header
  FROM loading_orders lo
  JOIN clearances c ON lo.clearance_id = c.id
  JOIN customers cus ON c.customer_id = cus.id
  WHERE lo.id = p_order_id;

  -- آیتم‌ها
  SELECT json_agg(json_build_object(
    'product_name', p.name,
    'batch_no', loi.batch_no,
    'qty', loi.qty,
    'weight', loi.weight
  )) INTO v_items
  FROM loading_order_items loi
  JOIN products p ON loi.product_id = p.id
  WHERE loi.loading_order_id = p_order_id;

  RETURN json_build_object('header', v_header, 'items', v_items);
END;
$$;


ALTER FUNCTION public.get_loading_order_details(p_order_id bigint) OWNER TO postgres;

--
-- Name: get_loading_order_for_exit(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_loading_order_for_exit(p_order_no bigint) RETURNS TABLE(loading_id bigint, order_no bigint, loading_date timestamp without time zone, driver_name text, plate_number text, customer_name text, receiver_name text, is_exited boolean, exit_id bigint, item_id bigint, product_name text, national_id text, national_title text, category_name text, qty numeric, initial_weight numeric, fee_type text, storage_rate numeric, loading_rate numeric)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    lo.id,
    lo.order_no,
    lo.loading_date,
    lo.driver_name,
    lo.plate_number,
    cus.name as customer_name,
    COALESCE(cl.receiver_person_name, cl.receiver_company_name, '') as receiver_name,
    
    -- بررسی اینکه آیا این سفارش قبلاً در جدول خروج ثبت شده؟
    EXISTS(SELECT 1 FROM warehouse_exits we WHERE we.loading_order_id = lo.id) as is_exited,
    (SELECT id FROM warehouse_exits we WHERE we.loading_order_id = lo.id LIMIT 1) as exit_id,
    
    loi.id as item_id,
    p.name as product_name,
    -- خواندن شناسه و عنوان ملی از جدول Products
    COALESCE(p.national_id, '') as national_id,
    COALESCE(p.national_title, '') as national_title,
    
    cat.name as category_name,
    loi.qty,
    loi.weight,
    
    COALESCE(cat.fee_type, 'weight') as fee_type,
    COALESCE(cat.storage_cost, 0) as storage_rate,
    COALESCE(cat.loading_cost, 0) as loading_rate
    
  FROM loading_orders lo
  JOIN loading_order_items loi ON lo.id = loi.loading_order_id
  JOIN clearances cl ON lo.clearance_id = cl.id
  JOIN customers cus ON cl.customer_id = cus.id
  JOIN products p ON loi.product_id = p.id
  LEFT JOIN product_categories cat ON p.category_id = cat.id
  
  WHERE lo.order_no = p_order_no;
END;
$$;


ALTER FUNCTION public.get_loading_order_for_exit(p_order_no bigint) OWNER TO postgres;

--
-- Name: get_loading_orders_list(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_loading_orders_list() RETURNS TABLE(id bigint, order_no bigint, loading_date timestamp without time zone, customer_name text, driver_name text, plate_number text, items_count bigint, total_qty numeric, total_weight numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    lo.id,
    lo.order_no,
    lo.loading_date,
    cus.name as customer_name, -- نام مشتری از جدول customers
    lo.driver_name,
    lo.plate_number,
    COUNT(loi.id) as items_count,
    COALESCE(SUM(loi.qty::numeric), 0) as total_qty,
    COALESCE(SUM(loi.weight::numeric), 0) as total_weight
  FROM loading_orders lo
  -- 1. اول وصل می‌شویم به جدول clearances
  LEFT JOIN clearances cl ON lo.clearance_id = cl.id
  -- 2. بعد از طریق clearance وصل می‌شویم به customers
  LEFT JOIN customers cus ON cl.customer_id = cus.id
  -- 3. وصل می‌شویم به آیتم‌ها برای محاسبه تعداد و وزن
  LEFT JOIN loading_order_items loi ON lo.id = loi.loading_order_id
  GROUP BY lo.id, lo.order_no, lo.loading_date, cus.name, lo.driver_name, lo.plate_number
  ORDER BY lo.loading_date DESC;
END;
$$;


ALTER FUNCTION public.get_loading_orders_list() OWNER TO postgres;

--
-- Name: get_my_tafsili_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_my_tafsili_id() RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  -- فرض بر این است که tafsili_id در جدول customers هم UUID است
  RETURN (SELECT tafsili_id FROM public.customers WHERE auth_user_id = auth.uid() LIMIT 1);
END;
$$;


ALTER FUNCTION public.get_my_tafsili_id() OWNER TO postgres;

--
-- Name: get_next_child_batch(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_next_child_batch(p_parent_batch text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_last_suffix int;
  v_next_batch text;
BEGIN
  -- 1. پیدا کردن بالاترین عددی که بعد از اسلش (/) برای این مادر آمده است
  -- این کوئری در جدول اقلام ترخیص می‌گردد
  SELECT COALESCE(MAX(CAST(SPLIT_PART(new_batch_no, '/', -1) AS INTEGER)), 0)
  INTO v_last_suffix
  FROM clearance_items
  WHERE parent_batch_no = p_parent_batch;

  -- 2. تولید کد جدید (مادر + اسلش + عدد بعدی)
  v_next_batch := p_parent_batch || '/' || (v_last_suffix + 1);
  
  RETURN v_next_batch;
END;
$$;


ALTER FUNCTION public.get_next_child_batch(p_parent_batch text) OWNER TO postgres;

--
-- Name: get_owner_products_summary(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_owner_products_summary(p_owner_id bigint) RETURNS TABLE(product_id bigint, product_title text, total_qty_available numeric, total_weight_available numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  SELECT
    p.id,
    
    -- *** اصلاح شده: استفاده از p.name ***
    p.name as product_title, 
    
    -- محاسبه تعداد مانده (ورودی - خروجی)
    (
      COALESCE((SELECT SUM(ri.count) FROM receipt_items ri JOIN receipts r ON ri.receipt_id = r.id WHERE ri.product_id = p.id AND r.owner_id = p_owner_id), 0)
      -
      COALESCE((SELECT SUM(it.qty) FROM inventory_transactions it WHERE it.product_id = p.id AND it.owner_id = p_owner_id AND it.transaction_type = 'exit'), 0)
    ) as total_qty_available,
    
    -- محاسبه وزن مانده (ورودی - خروجی)
    (
      COALESCE((SELECT SUM(ri.weights_net) FROM receipt_items ri JOIN receipts r ON ri.receipt_id = r.id WHERE ri.product_id = p.id AND r.owner_id = p_owner_id), 0)
      -
      COALESCE((SELECT SUM(it.weight) FROM inventory_transactions it WHERE it.product_id = p.id AND it.owner_id = p_owner_id AND it.transaction_type = 'exit'), 0)
    ) as total_weight_available

  FROM products p
  WHERE p.id IN (
      SELECT DISTINCT ri.product_id 
      FROM receipt_items ri 
      JOIN receipts r ON ri.receipt_id = r.id 
      WHERE r.owner_id = p_owner_id
  );
END;
$$;


ALTER FUNCTION public.get_owner_products_summary(p_owner_id bigint) OWNER TO postgres;

--
-- Name: get_owners_with_receipts(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_owners_with_receipts() RETURNS TABLE(id bigint, full_name text, mobile text)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  SELECT DISTINCT
    c.id,
    c.name as full_name, -- فرض بر این است که نام مشتری در ستون name است
    c.mobile             -- فرض بر این است که موبایل در ستون mobile است
  FROM customers c
  JOIN receipts r ON c.id = r.owner_id
  ORDER BY c.name;
END;
$$;


ALTER FUNCTION public.get_owners_with_receipts() OWNER TO postgres;

--
-- Name: get_pending_clearances(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_pending_clearances() RETURNS TABLE(id bigint, clearance_no bigint, clearance_date date, customer_name text, driver_name text, plate_number text, items_json json)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    c.id, 
    c.clearance_no, 
    c.clearance_date, -- حالا نوع این ستون با نوع تعریف شده در بالا (date) یکی است
    cus.name AS customer_name, 
    c.driver_name, 
    CONCAT_WS('-', c.vehicle_plate_left2, c.vehicle_plate_mid3, c.vehicle_plate_letter, c.vehicle_plate_iran_right) as plate_number,
    COALESCE(
      (
         SELECT json_agg(json_build_object(
            'item_id', ci.id,
            'product_id', ci.product_id,
            'product_name', p.name,
            'batch_no', ci.new_batch_no,
            'qty', ci.qty,
            'weight', ci.weight
         ))
         FROM clearance_items ci
         LEFT JOIN products p ON ci.product_id = p.id
         WHERE ci.clearance_id = c.id
      ), 
      '[]'::json
    ) as items_json
  FROM clearances c
  JOIN customers cus ON c.customer_id = cus.id
  WHERE 
    -- فقط اسنادی که در جدول loading_orders نیستند
    NOT EXISTS (
       SELECT 1 FROM loading_orders lo WHERE lo.clearance_id = c.id
    )
  ORDER BY c.clearance_date DESC;
END;
$$;


ALTER FUNCTION public.get_pending_clearances() OWNER TO postgres;

--
-- Name: get_receipt_details(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_receipt_details(p_receipt_id uuid) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
    result JSON;
BEGIN
    SELECT json_build_object(
        'header', r.*,
        'items', (
            SELECT json_agg(ri.*)
            FROM receipt_items ri
            WHERE ri.receipt_id = r.id
        )
    ) INTO result
    FROM receipts r
    WHERE r.id = p_receipt_id;
    
    RETURN result;
END;
$$;


ALTER FUNCTION public.get_receipt_details(p_receipt_id uuid) OWNER TO postgres;

--
-- Name: get_stock(bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_stock(p_product_id bigint, p_owner_id bigint) RETURNS numeric
    LANGUAGE sql STABLE
    AS $$
  select coalesce(sum(
    case
      when type = 'in' then qty
      when type = 'out' then -qty
      else 0
    end
  ), 0)
  from public.inventory_transactions
  where product_id = p_product_id
    and owner_id = p_owner_id;
$$;


ALTER FUNCTION public.get_stock(p_product_id bigint, p_owner_id bigint) OWNER TO postgres;

--
-- Name: get_stock(bigint, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_stock(p_product_id bigint, p_owner_id bigint, p_member_id bigint DEFAULT NULL::bigint) RETURNS numeric
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_stock NUMERIC := 0;
BEGIN
    SELECT COALESCE(SUM(
        CASE 
            WHEN type IN ('entry', 'in') THEN qty
            WHEN type IN ('exit', 'out') THEN -qty
            ELSE 0
        END
    ), 0)
    INTO v_stock
    FROM inventory_transactions
    WHERE product_id = p_product_id
      AND owner_id = p_owner_id
      AND (p_member_id IS NULL OR member_id = p_member_id);
    
    RETURN v_stock;
END;
$$;


ALTER FUNCTION public.get_stock(p_product_id bigint, p_owner_id bigint, p_member_id bigint) OWNER TO postgres;

--
-- Name: get_user_sidebar_forms(uuid, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_sidebar_forms(p_member_id uuid, p_user_id uuid) RETURNS TABLE(form_code text, title text, route text, module text, icon text, menu_order integer, parent_id uuid)
    LANGUAGE sql STABLE
    AS $$
  with user_perm as (
    select distinct p.code
    from public.user_roles ur
    join public.roles r on r.id = ur.role_id and r.is_active = true
    join public.role_permissions rp on rp.role_id = r.id
    join public.permissions p on p.id = rp.permission_id
    where ur.member_id = p_member_id
      and ur.user_id = p_user_id
      and ur.is_active = true
      and ur.valid_from <= now()
      and (ur.valid_to is null or ur.valid_to > now())
  )
  select uf.form_code, uf.title, uf.route, uf.module, uf.icon, uf.menu_order, uf.parent_id
  from public.ui_forms uf
  join public.ui_form_permissions ufp
    on ufp.form_id = uf.id and ufp.required_for = 'view'
  join public.permissions p on p.id = ufp.permission_id
  where uf.member_id = p_member_id
    and uf.is_active = true
    and uf.is_menu_item = true
    and p.code in (select code from user_perm)
  order by uf.menu_order, uf.title;
$$;


ALTER FUNCTION public.get_user_sidebar_forms(p_member_id uuid, p_user_id uuid) OWNER TO postgres;

--
-- Name: has_permission(uuid, uuid, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.has_permission(p_member_id uuid, p_user_id uuid, p_permission_code text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  select exists (
    select 1
    from public.user_roles ur
    join public.roles r on r.id = ur.role_id and r.is_active = true
    join public.role_permissions rp on rp.role_id = r.id
    join public.permissions p on p.id = rp.permission_id
    where ur.member_id = p_member_id
      and ur.user_id = p_user_id
      and ur.is_active = true
      and ur.valid_from <= now()
      and (ur.valid_to is null or ur.valid_to > now())
      and p.code = p_permission_code
  );
$$;


ALTER FUNCTION public.has_permission(p_member_id uuid, p_user_id uuid, p_permission_code text) OWNER TO postgres;

--
-- Name: is_admin(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.is_admin() RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM public.members 
    WHERE auth_user_id = auth.uid() 
    AND role = 'admin'
  );
END;
$$;


ALTER FUNCTION public.is_admin() OWNER TO postgres;

--
-- Name: link_user_to_customer(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.link_user_to_customer() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
  clean_phone text;
BEGIN
  -- تبدیل فرمت شماره (مثلاً +98912 به 0912) برای مقایسه
  -- فرض می‌کنیم در جدول customers شماره‌ها با 09 شروع می‌شوند
  clean_phone := REPLACE(NEW.phone, '+98', '0');
  
  -- آپدیت کردن جدول مشتریان
  UPDATE public.customers 
  SET auth_user_id = NEW.id 
  WHERE mobile = clean_phone;
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.link_user_to_customer() OWNER TO postgres;

--
-- Name: receipt_atomic(jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.receipt_atomic(p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_action text;
  v_receipt_id bigint;
  v_member_id bigint;
  v_owner_id bigint;
  v_status text;
  v_item jsonb;
  v_before numeric;
begin
  v_action := p_payload->>'action';
  v_member_id := (p_payload->>'member_id')::bigint;
  v_owner_id := (p_payload->>'owner_id')::bigint;
  v_status := coalesce(p_payload->>'status', 'draft');

  if v_member_id is null then
    raise exception 'member_id is required';
  end if;

  /* =====================================================
     CREATE
  ===================================================== */
  if v_action = 'create' then

    insert into receipts (
      doc_type_id,
      receipt_no,
      member_id,
      status,
      doc_date,
      owner_id,
      payment_by
    )
    values (
      (p_payload->>'doc_type_id')::bigint,
      nextval('receipt_no_seq'),
      v_member_id,
      v_status,
      (p_payload->>'doc_date')::date,
      v_owner_id,
      coalesce(p_payload->>'payment_by', 'customer')
    )
    returning id into v_receipt_id;

    for v_item in
      select * from jsonb_array_elements(p_payload->'items')
    loop
      insert into receipt_items (
        receipt_id,
        product_id,
        owner_id,
        count
      )
      values (
        v_receipt_id,
        (v_item->>'product_id')::bigint,
        v_owner_id,
        (v_item->>'count')::numeric
      );

      if v_status = 'final' then
        select get_stock(
          (v_item->>'product_id')::bigint,
          v_owner_id
        ) into v_before;

        insert into inventory_transactions (
          ref_receipt_id,
          product_id,
          owner_id,
          member_id,
          qty,
          snapshot_qty_before,
          snapshot_qty_after,
          type
        )
        values (
          v_receipt_id,
          (v_item->>'product_id')::bigint,
          v_owner_id,
          v_member_id,
          (v_item->>'count')::numeric,
          v_before,
          v_before + (v_item->>'count')::numeric,
          'in'
        );
      end if;
    end loop;

    return jsonb_build_object(
      'success', true,
      'receipt_id', v_receipt_id
    );
  end if;

  /* =====================================================
     CANCEL
  ===================================================== */
  if v_action = 'cancel' then
    v_receipt_id := (p_payload->>'receipt_id')::bigint;

    for v_item in
      select * from receipt_items where receipt_id = v_receipt_id
    loop
      select get_stock(v_item.product_id, v_owner_id) into v_before;

      insert into inventory_transactions (
        ref_receipt_id,
        product_id,
        owner_id,
        member_id,
        qty,
        snapshot_qty_before,
        snapshot_qty_after,
        type
      )
      values (
        v_receipt_id,
        v_item.product_id,
        v_owner_id,
        v_member_id,
        v_item.count,
        v_before,
        v_before - v_item.count,
        'out'
      );
    end loop;

    update receipts set status = 'cancelled'
    where id = v_receipt_id;

    return jsonb_build_object(
      'success', true,
      'receipt_id', v_receipt_id,
      'status', 'cancelled'
    );
  end if;

  raise exception 'invalid action';

end;
$$;


ALTER FUNCTION public.receipt_atomic(p_payload jsonb) OWNER TO postgres;

--
-- Name: register_exit_financial_doc(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.register_exit_financial_doc(p_exit_id bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    r_exit RECORD;
    v_doc_id BIGINT;
    v_doc_no BIGINT;
    v_total_amount NUMERIC;
    
    -- کدهای معین (طبق دیتای شما)
    v_moin_cash_id BIGINT := 1;           -- صندوق (10101)
    v_moin_pos_id BIGINT := 4;            -- پوز (10104)
    v_moin_customer_ar_id BIGINT := 5;    -- مشتری (10301)
    
    v_target_moein_id BIGINT;
    v_target_tafsili_id BIGINT;
    v_payment_method TEXT;
BEGIN
    -- 1. دریافت اطلاعات
    SELECT * INTO r_exit FROM warehouse_exits WHERE id = p_exit_id;
    IF r_exit IS NULL THEN RETURN jsonb_build_object('status', 'error', 'message', 'سند یافت نشد'); END IF;

    -- 2. تمیز کردن روش پرداخت (حذف فاصله و کوچک کردن حروف)
    v_payment_method := LOWER(TRIM(COALESCE(r_exit.payment_method, 'credit')));

    -- 3. منطق انتخاب حساب
    IF v_payment_method = 'pos' THEN
        v_target_moein_id := v_moin_pos_id; -- معین 4
        v_target_tafsili_id := r_exit.financial_account_id;
        
    ELSIF v_payment_method = 'cash' THEN
        v_target_moein_id := v_moin_cash_id; -- معین 1
        v_target_tafsili_id := r_exit.financial_account_id;
        
    ELSE -- credit یا هر چیز دیگر
        v_target_moein_id := v_moin_customer_ar_id; -- معین 5
        SELECT id INTO v_target_tafsili_id FROM accounting_tafsili WHERE ref_id = r_exit.owner_id AND tafsili_type = 'customer' LIMIT 1;
    END IF;

    -- 4. جلوگیری از خطای دیتابیس (تفصیلی خالی)
    IF v_target_tafsili_id IS NULL THEN
        RETURN jsonb_build_object('status', 'error', 'message', 'خطا: تفصیلی طرف حساب (بانک/صندوق) انتخاب نشده است.');
    END IF;

    -- 5. محاسبات و ثبت سند
    v_total_amount := COALESCE(r_exit.total_fee, 0) + COALESCE(r_exit.total_loading_fee, 0) + COALESCE(r_exit.weighbridge_fee, 0) + COALESCE(r_exit.extra_fee, 0) + COALESCE(r_exit.vat_fee, 0);

    SELECT COALESCE(MAX(doc_no), 1000) + 1 INTO v_doc_no FROM financial_documents;
    
    INSERT INTO financial_documents (doc_no, doc_date, description, status, doc_type, related_exit_id)
    VALUES (v_doc_no, r_exit.exit_date::date, 'سند خروج ' || r_exit.id, 'final', 'system', p_exit_id)
    RETURNING id INTO v_doc_id;

    -- ثبت بدهکار
    INSERT INTO financial_entries (doc_id, moein_id, tafsili_id, bed, bes, description)
    VALUES (v_doc_id, v_target_moein_id, v_target_tafsili_id, v_total_amount, 0, 'بابت تسویه فاکتور');

    -- ثبت بستانکارها
    IF r_exit.total_fee > 0 THEN INSERT INTO financial_entries (doc_id, moein_id, bes, description) VALUES (v_doc_id, 10, r_exit.total_fee, 'انبارداری'); END IF;
    IF r_exit.total_loading_fee > 0 THEN INSERT INTO financial_entries (doc_id, moein_id, bes, description) VALUES (v_doc_id, 11, r_exit.total_loading_fee, 'بارگیری'); END IF;
    IF r_exit.weighbridge_fee > 0 THEN INSERT INTO financial_entries (doc_id, moein_id, bes, description) VALUES (v_doc_id, 12, r_exit.weighbridge_fee, 'باسکول'); END IF;
    IF r_exit.extra_fee > 0 THEN INSERT INTO financial_entries (doc_id, moein_id, bes, description) VALUES (v_doc_id, 13, r_exit.extra_fee, 'سایر'); END IF;
    IF r_exit.vat_fee > 0 THEN INSERT INTO financial_entries (doc_id, moein_id, bes, description) VALUES (v_doc_id, 8, r_exit.vat_fee, 'ارزش افزوده'); END IF;

    RETURN jsonb_build_object('status', 'success', 'doc_no', v_doc_no);
END;
$$;


ALTER FUNCTION public.register_exit_financial_doc(p_exit_id bigint) OWNER TO postgres;

--
-- Name: register_exit_financial_doc(jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.register_exit_financial_doc(p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_exit_id INTEGER;
    v_exit_record RECORD;
    v_doc_id INTEGER;
    v_doc_no INTEGER;
    v_customer_tafsili_id INTEGER;
    v_debit_moein_id INTEGER;
    v_debit_tafsili_id INTEGER;
    v_debit_description TEXT;
    v_total_storage NUMERIC;
    v_total_loading NUMERIC;
    v_weighbridge_fee NUMERIC;
    v_extra_fee NUMERIC;
    v_vat_fee NUMERIC;
    v_sub_total NUMERIC;
    v_grand_total NUMERIC;
    
    -- کدهای معین ثابت
    MOEIN_CASH CONSTANT INTEGER := 1;
    MOEIN_POS CONSTANT INTEGER := 4;
    MOEIN_CUSTOMER CONSTANT INTEGER := 5;
    MOEIN_VAT CONSTANT INTEGER := 8;
    MOEIN_INCOME_STORAGE CONSTANT INTEGER := 10;
    MOEIN_INCOME_LOADING CONSTANT INTEGER := 11;
    MOEIN_INCOME_WEIGHBRIDGE CONSTANT INTEGER := 12;
    MOEIN_INCOME_OTHER CONSTANT INTEGER := 13;
BEGIN
    -- 1. استخراج exit_id از payload
    v_exit_id := (p_payload->>'exit_id')::INTEGER;
    
    IF v_exit_id IS NULL THEN
        RETURN jsonb_build_object('status', 'error', 'message', 'شناسه خروج ارسال نشده است');
    END IF;
    
    -- 2. چک کردن اینکه قبلاً سند ثبت نشده باشد
    SELECT accounting_doc_id INTO v_doc_id FROM warehouse_exits WHERE id = v_exit_id;
    IF v_doc_id IS NOT NULL THEN
        RETURN jsonb_build_object('status', 'error', 'message', 'سند حسابداری قبلاً ثبت شده', 'doc_no', v_doc_id);
    END IF;
    
    -- 3. دریافت اطلاعات خروج
    SELECT we.*
    INTO v_exit_record
    FROM warehouse_exits we
    WHERE we.id = v_exit_id;
    
    IF v_exit_record IS NULL THEN
        RETURN jsonb_build_object('status', 'error', 'message', 'خروج یافت نشد');
    END IF;
    
    -- 4. پیدا کردن تفصیلی مشتری
    SELECT id INTO v_customer_tafsili_id
    FROM accounting_tafsili
    WHERE tafsili_type = 'customer' 
      AND ref_id = v_exit_record.owner_id
    LIMIT 1;
    
    -- 5. محاسبه مبالغ
    v_total_storage := COALESCE(v_exit_record.total_fee, 0);
    v_total_loading := COALESCE(v_exit_record.total_loading_fee, 0);
    v_weighbridge_fee := COALESCE(v_exit_record.weighbridge_fee, 0);
    v_extra_fee := COALESCE(v_exit_record.extra_fee, 0);
    v_vat_fee := COALESCE(v_exit_record.vat_fee, 0);
    
    v_sub_total := v_total_storage + v_total_loading + v_weighbridge_fee + v_extra_fee;
    v_grand_total := v_sub_total + v_vat_fee;
    
    IF v_grand_total <= 0 THEN
        RETURN jsonb_build_object('status', 'error', 'message', 'مبلغ فاکتور صفر است');
    END IF;
    
    -- 6. تعیین معین و تفصیلی بر اساس روش پرداخت
    CASE v_exit_record.payment_method
        WHEN 'pos' THEN
            v_debit_moein_id := MOEIN_POS;
            v_debit_tafsili_id := v_exit_record.financial_account_id;
            v_debit_description := 'دریافت از کارتخوان - خروج ' || v_exit_id;
            
        WHEN 'cash' THEN
            v_debit_moein_id := MOEIN_CASH;
            v_debit_tafsili_id := v_exit_record.financial_account_id;
            v_debit_description := 'دریافت نقدی - خروج ' || v_exit_id;
            
        ELSE
            v_debit_moein_id := MOEIN_CUSTOMER;
            v_debit_tafsili_id := v_customer_tafsili_id;
            v_debit_description := 'خدمات خروج شماره ' || v_exit_id;
    END CASE;
    
    -- 7. تولید شماره سند (INTEGER) - از max موجود + 1
    SELECT COALESCE(MAX(doc_no), 0) + 1 INTO v_doc_no FROM financial_documents;
    
    -- 8. ایجاد سند حسابداری
    INSERT INTO financial_documents (
        doc_no,
        doc_date, 
        doc_type, 
        status, 
        description,
        reference_id,
        reference_type
    ) VALUES (
        v_doc_no,
        COALESCE(v_exit_record.exit_date, CURRENT_DATE),
        'system',
        'confirmed',
        'سند خروج شماره ' || v_exit_id,
        v_exit_id,
        'warehouse_exit'
    ) RETURNING id INTO v_doc_id;
    
    -- 9. ایجاد آرتیکل‌ها
    
    -- بدهکار
    INSERT INTO financial_entries (doc_id, moein_id, tafsili_id, bed, bes, description)
    VALUES (v_doc_id, v_debit_moein_id, v_debit_tafsili_id, v_grand_total, 0, v_debit_description);
    
    -- بستانکار: درآمد انبارداری
    IF v_total_storage > 0 THEN
        INSERT INTO financial_entries (doc_id, moein_id, tafsili_id, bed, bes, description)
        VALUES (v_doc_id, MOEIN_INCOME_STORAGE, NULL, 0, v_total_storage, 'درآمد انبارداری');
    END IF;
    
    -- بستانکار: درآمد بارگیری
    IF v_total_loading > 0 THEN
        INSERT INTO financial_entries (doc_id, moein_id, tafsili_id, bed, bes, description)
        VALUES (v_doc_id, MOEIN_INCOME_LOADING, NULL, 0, v_total_loading, 'درآمد بارگیری');
    END IF;
    
    -- بستانکار: درآمد باسکول
    IF v_weighbridge_fee > 0 THEN
        INSERT INTO financial_entries (doc_id, moein_id, tafsili_id, bed, bes, description)
        VALUES (v_doc_id, MOEIN_INCOME_WEIGHBRIDGE, NULL, 0, v_weighbridge_fee, 'درآمد باسکول');
    END IF;
    
    -- بستانکار: سایر درآمدها
    IF v_extra_fee > 0 THEN
        INSERT INTO financial_entries (doc_id, moein_id, tafsili_id, bed, bes, description)
        VALUES (v_doc_id, MOEIN_INCOME_OTHER, NULL, 0, v_extra_fee, 'سایر درآمدها');
    END IF;
    
    -- بستانکار: مالیات
    IF v_vat_fee > 0 THEN
        INSERT INTO financial_entries (doc_id, moein_id, tafsili_id, bed, bes, description)
        VALUES (v_doc_id, MOEIN_VAT, NULL, 0, v_vat_fee, 'مالیات');
    END IF;
    
    -- 10. آپدیت خروج
    UPDATE warehouse_exits 
    SET accounting_doc_id = v_doc_id 
    WHERE id = v_exit_id;
    
    -- 11. برگرداندن نتیجه
    RETURN jsonb_build_object(
        'status', 'success',
        'doc_no', v_doc_no,
        'doc_id', v_doc_id,
        'message', 'سند حسابداری ثبت شد',
        'payment_method', v_exit_record.payment_method,
        'grand_total', v_grand_total
    );
    
EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object(
        'status', 'error',
        'message', SQLERRM,
        'detail', SQLSTATE
    );
END;
$$;


ALTER FUNCTION public.register_exit_financial_doc(p_payload jsonb) OWNER TO postgres;

--
-- Name: seed_default_roles_for_member(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.seed_default_roles_for_member(p_member_id uuid) RETURNS TABLE(role_id uuid, role_code text, role_title text)
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_super_admin_id UUID;
  v_warehouse_manager_id UUID;
  v_accountant_id UUID;
  v_operator_id UUID;
  v_client_id UUID;
BEGIN
  INSERT INTO roles (member_id, code, title, description, is_system, is_active)
  VALUES (p_member_id, 'super-admin', 'مدیر کل سیستم', 'دسترسی کامل به تمام بخش‌ها', true, true)
  ON CONFLICT (member_id, code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_super_admin_id;

  INSERT INTO roles (member_id, code, title, description, is_system, is_active)
  VALUES (p_member_id, 'warehouse-manager', 'مدیر انبار', 'مدیریت عملیات انبارداری', true, true)
  ON CONFLICT (member_id, code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_warehouse_manager_id;

  INSERT INTO roles (member_id, code, title, description, is_system, is_active)
  VALUES (p_member_id, 'accountant', 'حسابدار', 'دسترسی به بخش حسابداری و گزارشات مالی', true, true)
  ON CONFLICT (member_id, code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_accountant_id;

  INSERT INTO roles (member_id, code, title, description, is_system, is_active)
  VALUES (p_member_id, 'operator', 'اپراتور', 'ثبت رسید و بارگیری', false, true)
  ON CONFLICT (member_id, code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_operator_id;

  INSERT INTO roles (member_id, code, title, description, is_system, is_active)
  VALUES (p_member_id, 'client', 'مشتری', 'دسترسی به پرتال مشتری', true, true)
  ON CONFLICT (member_id, code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_client_id;

  DELETE FROM role_permissions rp WHERE rp.role_id = v_super_admin_id;
  INSERT INTO role_permissions (role_id, permission_id)
  SELECT v_super_admin_id, p.id FROM permissions p;

  DELETE FROM role_permissions rp WHERE rp.role_id = v_warehouse_manager_id;
  INSERT INTO role_permissions (role_id, permission_id)
  SELECT v_warehouse_manager_id, p.id 
  FROM permissions p 
  WHERE p.module IN ('inventory', 'receipt', 'loading', 'exit', 'clearance', 'customer');

  DELETE FROM role_permissions rp WHERE rp.role_id = v_accountant_id;
  INSERT INTO role_permissions (role_id, permission_id)
  SELECT v_accountant_id, p.id 
  FROM permissions p 
  WHERE p.module = 'accounting' OR p.code LIKE 'rent%';

  DELETE FROM role_permissions rp WHERE rp.role_id = v_operator_id;
  INSERT INTO role_permissions (role_id, permission_id)
  SELECT v_operator_id, p.id 
  FROM permissions p 
  WHERE p.module IN ('receipt', 'loading', 'exit', 'inventory', 'customer')
    AND p.action IN ('view', 'create');

  DELETE FROM role_permissions rp WHERE rp.role_id = v_client_id;
  INSERT INTO role_permissions (role_id, permission_id)
  SELECT v_client_id, p.id 
  FROM permissions p 
  WHERE p.module = 'client';

  RETURN QUERY
  SELECT r.id, r.code, r.title FROM roles r WHERE r.member_id = p_member_id;
END;
$$;


ALTER FUNCTION public.seed_default_roles_for_member(p_member_id uuid) OWNER TO postgres;

--
-- Name: seed_ui_forms_for_member(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.seed_ui_forms_for_member(p_member_id uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_count INTEGER := 0;
  v_member_management_id UUID;
  v_customers_id UUID;
  v_inventory_id UUID;
  v_receipts_id UUID;
  v_loading_exit_id UUID;
  v_clearance_id UUID;
  v_accounting_id UUID;
  v_reports_id UUID;
  v_treasury_id UUID;
  v_rent_id UUID;
BEGIN
  INSERT INTO ui_forms (member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active)
  VALUES (p_member_id, 'member-management', 'مدیریت اعضا', '#', 'member', 'bx bx-user-plus', NULL, 2, true, true)
  ON CONFLICT (member_id, form_code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_member_management_id;

  INSERT INTO ui_forms (member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active)
  VALUES (p_member_id, 'customers', 'مشتریان', '#', 'customer', 'bx bx-group', NULL, 3, true, true)
  ON CONFLICT (member_id, form_code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_customers_id;

  INSERT INTO ui_forms (member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active)
  VALUES (p_member_id, 'inventory', 'مدیریت کالا', '#', 'inventory', 'bx bx-cube', NULL, 4, true, true)
  ON CONFLICT (member_id, form_code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_inventory_id;

  INSERT INTO ui_forms (member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active)
  VALUES (p_member_id, 'receipts', 'رسید کالا', '#', 'receipt', 'bx bx-log-in-circle', NULL, 5, true, true)
  ON CONFLICT (member_id, form_code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_receipts_id;

  INSERT INTO ui_forms (member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active)
  VALUES (p_member_id, 'loading-exit', 'بارگیری و خروج', '#', 'loading', 'bx bx-truck', NULL, 6, true, true)
  ON CONFLICT (member_id, form_code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_loading_exit_id;

  INSERT INTO ui_forms (member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active)
  VALUES (p_member_id, 'clearance', 'ترخیص کالا', '#', 'clearance', 'bx bx-check-shield', NULL, 7, true, true)
  ON CONFLICT (member_id, form_code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_clearance_id;

  INSERT INTO ui_forms (member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active)
  VALUES (p_member_id, 'accounting', 'حسابداری', '#', 'accounting', 'bx bx-money', NULL, 8, true, true)
  ON CONFLICT (member_id, form_code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_accounting_id;

  INSERT INTO ui_forms (member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active)
  VALUES (p_member_id, 'reports', 'گزارشات مالی', '#', 'accounting', 'bx bx-stats', NULL, 9, true, true)
  ON CONFLICT (member_id, form_code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_reports_id;

  INSERT INTO ui_forms (member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active)
  VALUES (p_member_id, 'treasury', 'خزانه‌داری', '#', 'accounting', 'bx bx-wallet', NULL, 10, true, true)
  ON CONFLICT (member_id, form_code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_treasury_id;

  INSERT INTO ui_forms (member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active)
  VALUES (p_member_id, 'rent', 'اجاره انبار', '#', 'rent', 'bx bx-building-house', NULL, 11, true, true)
  ON CONFLICT (member_id, form_code) DO UPDATE SET title = EXCLUDED.title
  RETURNING id INTO v_rent_id;

  v_count := v_count + 10;

  INSERT INTO ui_forms (member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active)
  VALUES (p_member_id, 'dashboard', 'داشبورد', '/dashboard', 'dashboard', 'bx bx-home-circle', NULL, 1, true, true)
  ON CONFLICT (member_id, form_code) DO NOTHING;
  v_count := v_count + 1;

  INSERT INTO ui_forms (member_id, form_code, title, route, module, parent_id, menu_order) VALUES
  (p_member_id, 'members-list', 'لیست اعضا', '/members/list', 'member', v_member_management_id, 1),
  (p_member_id, 'members-add', 'افزودن عضو', '/members/add', 'member', v_member_management_id, 2),
  (p_member_id, 'system-users', 'مدیریت پرسنل من', '/system-users', 'member', v_member_management_id, 3),
  (p_member_id, 'customers-list', 'لیست مشتریان', '/customers/list', 'customer', v_customers_id, 1),
  (p_member_id, 'customers-add', 'افزودن مشتری', '/customers/add', 'customer', v_customers_id, 2),
  (p_member_id, 'products-list', 'لیست کالاها', '/inventory/product-list', 'inventory', v_inventory_id, 1),
  (p_member_id, 'products-add', 'افزودن کالا', '/inventory/add-product', 'inventory', v_inventory_id, 2),
  (p_member_id, 'categories-list', 'دسته‌بندی‌ها', '/inventory/category-list', 'inventory', v_inventory_id, 3),
  (p_member_id, 'units-list', 'واحدها', '/inventory/unit-list', 'inventory', v_inventory_id, 4),
  (p_member_id, 'receipts-list', 'لیست رسیدها', '/receipts', 'receipt', v_receipts_id, 1),
  (p_member_id, 'receipt-form', 'ثبت رسید جدید', '/receipt/form', 'receipt', v_receipts_id, 2),
  (p_member_id, 'loading-list', 'لیست بارگیری', '/loading/list', 'loading', v_loading_exit_id, 1),
  (p_member_id, 'loading-create', 'ثبت بارگیری', '/loading/create', 'loading', v_loading_exit_id, 2),
  (p_member_id, 'exit-list', 'لیست خروج نهایی', '/exit/list', 'exit', v_loading_exit_id, 3),
  (p_member_id, 'exit-create', 'ثبت خروج', '/exit/create', 'exit', v_loading_exit_id, 4),
  (p_member_id, 'clearance-form', 'ثبت ترخیص', '/clearances/form', 'clearance', v_clearance_id, 1),
  (p_member_id, 'clearance-report', 'گزارش ترخیص', '/clearances/report', 'clearance', v_clearance_id, 2),
  (p_member_id, 'accounting-documents', 'دفتر اسناد', '/accounting/documents', 'accounting', v_accounting_id, 1),
  (p_member_id, 'accounting-new', 'ثبت سند جدید', '/accounting/new', 'accounting', v_accounting_id, 2),
  (p_member_id, 'accounting-coding', 'کدینگ حسابداری', '/accounting/coding', 'accounting', v_accounting_id, 3),
  (p_member_id, 'reports-journal', 'دفتر روزنامه', '/accounting/reports/journal', 'accounting', v_reports_id, 1),
  (p_member_id, 'reports-customers', 'مانده مشتریان', '/accounting/reports/customers', 'accounting', v_reports_id, 2),
  (p_member_id, 'reports-ledger', 'دفتر معین', '/accounting/reports/ledger', 'accounting', v_reports_id, 3),
  (p_member_id, 'reports-comprehensive', 'گزارش جامع', '/accounting/reports/comprehensive', 'accounting', v_reports_id, 4),
  (p_member_id, 'treasury-list', 'لیست اسناد', '/accounting/list', 'accounting', v_treasury_id, 1),
  (p_member_id, 'treasury-checks', 'عملیات چک', '/accounting/check-operations', 'accounting', v_treasury_id, 2),
  (p_member_id, 'treasury-definitions', 'تعاریف خزانه‌داری', '/accounting/definitions', 'accounting', v_treasury_id, 3),
  (p_member_id, 'rent-list', 'لیست قراردادها', '/rent/list', 'rent', v_rent_id, 1),
  (p_member_id, 'rent-create', 'ثبت قرارداد جدید', '/rent/create', 'rent', v_rent_id, 2),
  (p_member_id, 'my-contracts', 'قراردادهای من', '/my-contracts', 'client', NULL, 100),
  (p_member_id, 'my-inventory', 'موجودی کالای من', '/my-inventory', 'client', NULL, 101),
  (p_member_id, 'my-invoices', 'صورتحساب‌های من', '/my-invoices', 'client', NULL, 102)
  ON CONFLICT (member_id, form_code) DO NOTHING;
  
  v_count := v_count + 32;

  RETURN v_count;
END;
$$;


ALTER FUNCTION public.seed_ui_forms_for_member(p_member_id uuid) OWNER TO postgres;

--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  new.updated_at = now();
  return new;
end;
$$;


ALTER FUNCTION public.set_updated_at() OWNER TO postgres;

--
-- Name: sync_clearance_inventory(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sync_clearance_inventory(p_clearance_id uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_header RECORD;
BEGIN
  SELECT * INTO v_header FROM public.clearances WHERE id = p_clearance_id;

  IF v_header.id IS NULL THEN
     RAISE NOTICE 'Clearance ID % not found', p_clearance_id;
     RETURN;
  END IF;

  -- پاکسازی تراکنش‌های قبلی
  DELETE FROM public.inventory_transactions 
  WHERE ref_clearance_id = p_clearance_id;

  -- ثبت تراکنش خروج
  IF v_header.status IN ('final', 'issued') THEN
  
    INSERT INTO public.inventory_transactions (
      type,                -- ✅ باید 'out' باشد
      transaction_type,
      ref_clearance_id, 
      product_id, 
      owner_id, 
      member_id, 
      batch_no,
      parent_batch_no,
      qty,                 -- ✅ باید منفی باشد
      weight,
      qty_real, 
      weight_real, 
      qty_available, 
      weight_available,
      transaction_date,
      created_at, 
      description
    )
    SELECT 
      'out',               -- ✅ تغییر از 'in' به 'out'
      'clearance',
      p_clearance_id, 
      i.product_id, 
      COALESCE(i.owner_id, v_header.customer_id), 
      v_header.member_id, 
      i.new_batch_no,
      i.parent_batch_no,
      
      -- ✅ منفی برای خروج
      -ABS(i.qty),
      -ABS(i.weight),
      -ABS(i.qty),
      -ABS(i.weight),
      -ABS(i.qty),
      -ABS(i.weight),
      
      v_header.clearance_date,
      now(), 
      'Clearance: ' || COALESCE(v_header.clearance_no::text, '-') || ' / Batch: ' || COALESCE(i.new_batch_no, '-')
      
    FROM public.clearance_items i
    WHERE i.clearance_id = p_clearance_id;
    
    RAISE NOTICE 'Synced % items for clearance %', (SELECT COUNT(*) FROM clearance_items WHERE clearance_id = p_clearance_id), p_clearance_id;
    
  END IF;
END;
$$;


ALTER FUNCTION public.sync_clearance_inventory(p_clearance_id uuid) OWNER TO postgres;

--
-- Name: sync_receipt_inventory(bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sync_receipt_inventory(p_receipt_id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_receipt RECORD;
BEGIN
  SELECT * INTO v_receipt FROM receipts WHERE id = p_receipt_id;
  
  -- پاکسازی قبلی‌ها
  DELETE FROM inventory_transactions WHERE ref_receipt_id = p_receipt_id;

  IF v_receipt.status = 'final' THEN
    INSERT INTO inventory_transactions (
      type, ref_receipt_id, product_id, owner_id, member_id, 
      batch_no, -- ✅ اینجا بچ نامبر پر می‌شود
      qty_real, weight_real,
      qty_available, weight_available,
      created_at
    )
    SELECT 
      'in', r_item.receipt_id, r_item.product_id, v_receipt.owner_id, v_receipt.member_id,
      r_item.row_code, -- ✅ اتصال حیاتی: row_code به batch_no تبدیل می‌شود
      r_item.count, r_item.weights_net,
      r_item.count, r_item.weights_net,
      now()
    FROM receipt_items r_item
    WHERE r_item.receipt_id = p_receipt_id;
  END IF;
END;
$$;


ALTER FUNCTION public.sync_receipt_inventory(p_receipt_id bigint) OWNER TO postgres;

--
-- Name: sync_tafsili_to_entities(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.sync_tafsili_to_entities() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_entity_id BIGINT;
BEGIN
    -- 🛑 جلوگیری از لوپ بی نهایت:
    -- اگر ref_id پر باشد، یعنی این تفصیلی توسط خودِ سیستم (بانک/مشتری) ساخته شده، پس کاری نکن.
    IF NEW.ref_id IS NOT NULL THEN
        RETURN NEW;
    END IF;

    -- 1️⃣ اگر نوع تفصیلی "حساب بانکی" بود
    IF NEW.tafsili_type = 'bank_account' THEN
        INSERT INTO treasury_banks (bank_name, account_no, tafsili_id)
        VALUES (
            split_part(NEW.title, '-', 1), -- نام بانک (قسمت اول تایتل)
            COALESCE(split_part(NEW.title, '-', 2), 'نامشخص'), -- شماره حساب (قسمت دوم)
            NEW.id
        ) RETURNING id INTO new_entity_id;
        
        -- آپدیت کردن تفصیلی با شناسه بانک ساخته شده
        UPDATE accounting_tafsili SET ref_id = new_entity_id WHERE id = NEW.id;

    -- 2️⃣ اگر نوع تفصیلی "صندوق" بود (فرض: cash یا other برای صندوق استفاده میشه)
    ELSIF NEW.tafsili_type = 'cash' OR (NEW.tafsili_type = 'other' AND NEW.title LIKE '%صندوق%') THEN
        INSERT INTO treasury_cashes (title, tafsili_id)
        VALUES (NEW.title, NEW.id)
        RETURNING id INTO new_entity_id;
        
        UPDATE accounting_tafsili SET ref_id = new_entity_id WHERE id = NEW.id;

    -- 3️⃣ اگر نوع تفصیلی "مشتری" بود
    ELSIF NEW.tafsili_type = 'customer' THEN
        -- چک کنیم که جدول مشتریان وجود داشته باشد
        INSERT INTO customers (name, phone, tafsili_id)
        VALUES (NEW.title, '', NEW.id)
        RETURNING id INTO new_entity_id;
        
        UPDATE accounting_tafsili SET ref_id = new_entity_id WHERE id = NEW.id;

    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.sync_tafsili_to_entities() OWNER TO postgres;

--
-- Name: test_rpc(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.test_rpc() RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_receipt_id bigint;
  v_product_id bigint;
begin
  v_receipt_id := 10;
  v_product_id := 2;

  insert into inventory_transactions (
    ref_receipt_id,
    product_id
  )
  values (
    v_receipt_id,
    v_product_id
  );
end;
$$;


ALTER FUNCTION public.test_rpc() OWNER TO postgres;

--
-- Name: trg_after_insert_exit_item(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trg_after_insert_exit_item() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_product_id bigint;
    v_owner_id bigint;
    v_batch_no text;
    v_qty numeric;
BEGIN
    SELECT
        loi.product_id,
        c.customer_id,
        loi.batch_no,
        loi.qty
    INTO
        v_product_id,
        v_owner_id,
        v_batch_no,
        v_qty
    FROM loading_order_items loi
    JOIN loading_orders lo ON lo.id = loi.loading_order_id
    JOIN clearances c ON c.id = lo.clearance_id
    WHERE loi.id = NEW.loading_item_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION
            'Inventory trigger error: loading_item_id % not found',
            NEW.loading_item_id;
    END IF;

    IF v_product_id IS NULL THEN
        RAISE EXCEPTION
            'Inventory trigger error: product_id is NULL for loading_item_id %',
            NEW.loading_item_id;
    END IF;

    INSERT INTO inventory_transactions (
        type,
        product_id,
        owner_id,
        qty,
        weight,
        batch_no,
        ref_exit_id,
        created_at,
        description
    ) VALUES (
        'exit',
        v_product_id,
        v_owner_id,
        v_qty,
        NEW.weight_net,
        v_batch_no,
        NEW.warehouse_exit_id,
        NOW(),
        'خروج خودکار سیستمی (باسکول)'
    );

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.trg_after_insert_exit_item() OWNER TO postgres;

--
-- Name: update_clearance_full(bigint, json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_clearance_full(p_clearance_id bigint, p_payload json) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_is_locked boolean;
  v_item json;
  
  -- متغیرهای محاسبه موجودی
  v_source_qty numeric; v_source_weight numeric;
  v_used_qty numeric; v_used_weight numeric;
  v_current_qty numeric; 
  v_plate_text text;
  
BEGIN
  -- 1. بررسی قفل بودن (اگر بچ‌های این سند جای دیگری استفاده شده باشند)
  SELECT EXISTS (
    SELECT 1 FROM clearance_items ci
    JOIN inventory_transactions it ON it.parent_batch_no = ci.batch_no
    WHERE ci.clearance_id = p_clearance_id
      AND it.ref_clearance_id != p_clearance_id 
  ) INTO v_is_locked;

  IF v_is_locked THEN
    RAISE EXCEPTION 'این سند دارای گردش عملیاتی بعدی است و قابل ویرایش نیست.' USING ERRCODE = 'P0001';
  END IF;

  -- 2. پاکسازی اقلام و تراکنش‌های قدیمی (برگشت موجودی به حالت قبل)
  DELETE FROM inventory_transactions 
  WHERE ref_clearance_id = p_clearance_id AND transaction_type = 'exit';

  DELETE FROM clearance_items 
  WHERE clearance_id = p_clearance_id;

  -- 3. آپدیت اطلاعات هدر (راننده، مشتری و...)
  v_plate_text := p_payload->>'plate_number';
  
  UPDATE clearances
  SET 
    customer_id = (p_payload->>'customer_id')::bigint,
    clearance_date = (p_payload->>'clearance_date')::timestamp,
    status = p_payload->>'status',
    receiver_person_name = p_payload->>'receiver_person_name',
    receiver_person_national_id = p_payload->>'receiver_person_national_id',
    driver_name = p_payload->>'driver_name',
    description = p_payload->>'description',
    vehicle_plate_left2 = split_part(v_plate_text, '-', 1),
    vehicle_plate_mid3 = split_part(v_plate_text, '-', 2),
    vehicle_plate_letter = split_part(v_plate_text, '-', 3),
    vehicle_plate_iran_right = split_part(v_plate_text, '-', 4),
    updated_at = now()
  WHERE id = p_clearance_id;

  -- 4. ثبت مجدد اقلام (دقیقاً مثل تابع Create)
  FOR v_item IN SELECT * FROM json_array_elements(p_payload->'items')
  LOOP
    
    -- الف) چک کردن موجودی (دقیقاً مثل قبل)
    -- نکته: چون در مرحله 2 تراکنش‌های قبلی را پاک کردیم، موجودی الان آزاد شده است
    v_source_qty := NULL; -- ریست متغیر
    
    -- جستجو در رسیدها
    IF (v_item->>'parent_batch_no') = 'بدون ردیف' THEN
       SELECT count, weights_net INTO v_source_qty, v_source_weight FROM receipt_items WHERE row_code IS NULL OR row_code = '';
    ELSE
       SELECT count, weights_net INTO v_source_qty, v_source_weight FROM receipt_items WHERE row_code = (v_item->>'parent_batch_no');
    END IF;

    -- جستجو در تراکنش‌ها
    IF v_source_qty IS NULL THEN
         SELECT qty, weight INTO v_source_qty, v_source_weight FROM inventory_transactions WHERE batch_no = (v_item->>'parent_batch_no') LIMIT 1;
    END IF;

    IF v_source_qty IS NULL AND (v_item->>'parent_batch_no') != 'بدون ردیف' THEN
        RAISE EXCEPTION 'ردیف مادر یافت نشد: %', (v_item->>'parent_batch_no') USING ERRCODE = 'P0001';
    END IF;

    -- محاسبه مصرف
    SELECT COALESCE(SUM(qty), 0) INTO v_used_qty FROM inventory_transactions WHERE parent_batch_no = (v_item->>'parent_batch_no');
    
    v_current_qty := v_source_qty - v_used_qty;
    
    IF (v_item->>'qty')::numeric > v_current_qty THEN
        RAISE EXCEPTION 'موجودی کافی نیست! درخواستی: %, موجودی: %', (v_item->>'qty'), v_current_qty USING ERRCODE = 'P0001';
    END IF;

    -- ب) اینسرت آیتم
    INSERT INTO clearance_items (
      clearance_id, owner_id, product_id, parent_batch_no, new_batch_no, batch_no, qty, weight, manual_ref_id, description, attachment_url, status
    )
    VALUES (
      p_clearance_id,
      (p_payload->>'customer_id')::bigint,
      (v_item->>'product_id')::bigint,
      NULLIF(v_item->>'parent_batch_no', 'بدون ردیف'),
      NULLIF(v_item->>'new_batch_no', 'بدون ردیف'),
      NULLIF(v_item->>'new_batch_no', 'بدون ردیف'),
      (v_item->>'qty')::numeric,
      (v_item->>'weight')::numeric,
      v_item->>'manual_ref_id',
      v_item->>'description',
      v_item->>'attachment_url',
      'issued'
    );

    -- ج) اینسرت تراکنش
    INSERT INTO inventory_transactions (
      type, transaction_type, owner_id, product_id, parent_batch_no, batch_no, qty, weight, transaction_date, reference_id, ref_clearance_id, receiver_name 
    )
    VALUES (
      'clearance', 'exit',
      (p_payload->>'customer_id')::bigint,
      (v_item->>'product_id')::bigint,
      NULLIF(v_item->>'parent_batch_no', 'بدون ردیف'),
      NULLIF(v_item->>'new_batch_no', 'بدون ردیف'), 
      (v_item->>'qty')::numeric,
      (v_item->>'weight')::numeric,
      (p_payload->>'clearance_date')::timestamp,
      p_clearance_id, p_clearance_id,
      p_payload->>'receiver_person_name'
    );

  END LOOP;

  RETURN json_build_object('status', 'success');
END;
$$;


ALTER FUNCTION public.update_clearance_full(p_clearance_id bigint, p_payload json) OWNER TO postgres;

--
-- Name: update_clearance_header(bigint, text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_clearance_header(p_clearance_id bigint, p_driver_name text, p_plate_number text, p_description text) RETURNS json
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- آپدیت فقط فیلدهای اطلاعاتی
  UPDATE clearances
  SET 
    driver_name = p_driver_name,
    description = p_description,
    -- آپدیت پلاک (تجزیه رشته)
    vehicle_plate_left2 = split_part(p_plate_number, '-', 1),
    vehicle_plate_mid3 = split_part(p_plate_number, '-', 2),
    vehicle_plate_letter = split_part(p_plate_number, '-', 3),
    vehicle_plate_iran_right = split_part(p_plate_number, '-', 4),
    updated_at = now()
  WHERE id = p_clearance_id;

  RETURN json_build_object('status', 'success');
END;
$$;


ALTER FUNCTION public.update_clearance_header(p_clearance_id bigint, p_driver_name text, p_plate_number text, p_description text) OWNER TO postgres;

--
-- Name: update_inventory_on_exit(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_inventory_on_exit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE
        v_product_id uuid;
        v_owner_id uuid;
        v_batch_no text;
        v_qty numeric;
        v_member_id text;
    BEGIN
        SELECT member_id, owner_id
        INTO v_member_id, v_owner_id
        FROM public.warehouse_exits
        WHERE id = NEW.warehouse_exit_id;

        SELECT product_id, batch_no, qty
        INTO v_product_id, v_batch_no, v_qty
        FROM public.loading_order_items
        WHERE id = NEW.loading_item_id;

        IF v_member_id IS NULL THEN
            RAISE EXCEPTION 'Member ID not found for exit id: %', NEW.warehouse_exit_id;
        END IF;

        INSERT INTO public.inventory_transactions (
            type, product_id, owner_id, member_id, qty, weight, batch_no, ref_exit_id, created_at, description
        ) VALUES (
            'exit', v_product_id, v_owner_id, v_member_id, v_qty, NEW.weight_net, v_batch_no,
            NEW.warehouse_exit_id, NOW(), 'خروج سیستمی (باسکول) - اصلاح شده'
        );

        RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.update_inventory_on_exit() OWNER TO postgres;

--
-- Name: update_loading_order(bigint, json); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_loading_order(p_order_id bigint, p_payload json) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_item json;
BEGIN
  -- 1. آپدیت اطلاعات هدر (راننده، تاریخ و...)
  UPDATE loading_orders
  SET 
    loading_date = (p_payload->>'loading_date')::timestamp,
    driver_name = p_payload->>'driver_name',
    plate_number = p_payload->>'plate_number',
    description = p_payload->>'description',
    updated_at = now()
  WHERE id = p_order_id;

  -- 2. حذف اقلام قدیمی (روش ساده برای ویرایش اقلام)
  DELETE FROM loading_order_items WHERE loading_order_id = p_order_id;

  -- 3. ثبت مجدد اقلام جدید
  FOR v_item IN SELECT * FROM json_array_elements(p_payload->'items')
  LOOP
    INSERT INTO loading_order_items (
      loading_order_id, clearance_item_id, product_id, batch_no, qty, weight
    )
    VALUES (
      p_order_id,
      (v_item->>'clearance_item_id')::bigint,
      (v_item->>'product_id')::bigint,
      v_item->>'batch_no',
      (v_item->>'qty')::numeric,
      (v_item->>'weight')::numeric
    );
  END LOOP;

  RETURN json_build_object('status', 'success', 'message', 'ویرایش انجام شد');
END;
$$;


ALTER FUNCTION public.update_loading_order(p_order_id bigint, p_payload json) OWNER TO postgres;

--
-- Name: update_receipt_items_diff(bigint, jsonb, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_receipt_items_diff(p_receipt_id bigint, p_payload jsonb, p_member_id bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  r_old record;
  r_new jsonb;
  v_old_qty numeric;
  v_new_qty numeric;
  v_diff numeric;
  v_before numeric;
begin
  -- receipt must be final
  if not exists (
    select 1 from public.receipts
    where id = p_receipt_id and status = 'final'
  ) then
    raise exception 'receipt must be final to update inventory';
  end if;

  -- loop new items
  for r_new in
    select * from jsonb_array_elements(p_payload->'items')
  loop
    v_new_qty := coalesce((r_new->>'count')::numeric, 0);

    select * into r_old
    from public.receipt_items
    where receipt_id = p_receipt_id
      and product_id = (r_new->>'product_id')::bigint;

    v_old_qty := coalesce(r_old.count, 0);
    v_diff := v_new_qty - v_old_qty;

    if v_diff <> 0 then
      select public.get_stock(r_old.product_id, r_old.owner_id)
        into v_before;

      insert into public.inventory_transactions (
        receipt_id,
        product_id,
        owner_id,
        member_id,
        qty,
        type,
        snapshot_qty_before,
        snapshot_qty_after,
        ref_type,
        ref_id
      )
      values (
        p_receipt_id,
        r_old.product_id,
        r_old.owner_id,
        p_member_id,
        abs(v_diff),
        case when v_diff > 0 then 'in' else 'out' end,
        v_before,
        v_before + v_diff,
        'receipt_update',
        p_receipt_id
      );
    end if;

    -- update item
    update public.receipt_items
    set count = v_new_qty
    where id = r_old.id;
  end loop;

  return jsonb_build_object(
    'success', true,
    'receipt_id', p_receipt_id
  );
end;
$$;


ALTER FUNCTION public.update_receipt_items_diff(p_receipt_id bigint, p_payload jsonb, p_member_id bigint) OWNER TO postgres;

--
-- Name: update_receipt_with_items(bigint, jsonb); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_receipt_with_items(p_receipt_id bigint, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_receipt_no BIGINT;
    v_owner_id BIGINT;
BEGIN
    v_owner_id := (p_payload->>'owner_id')::BIGINT;

    UPDATE receipts SET
        status = p_payload->>'status',
        doc_date = (p_payload->>'doc_date')::TIMESTAMP,
        tracking_code = p_payload->>'tracking_code',
        owner_id = v_owner_id,
        deliverer_id = (p_payload->>'deliverer_id')::BIGINT,
        driver_name = p_payload->>'driver_name',
        driver_national_id = p_payload->>'driver_national_id',
        driver_phone = p_payload->>'driver_phone',
        driver_birth_date = (p_payload->>'driver_birth_date')::TIMESTAMP,
        plate_iran_right = p_payload->>'plate_iran_right',
        plate_mid3 = p_payload->>'plate_mid3',
        plate_letter = p_payload->>'plate_letter',
        plate_left2 = p_payload->>'plate_left2',
        discharge_date = (p_payload->>'discharge_date')::TIMESTAMP,
        ref_type = p_payload->>'ref_type',
        ref_barnameh_number = p_payload->>'ref_barnameh_number',
        ref_barnameh_date = (p_payload->>'ref_barnameh_date')::TIMESTAMP,
        ref_barnameh_tracking = p_payload->>'ref_barnameh_tracking',
        ref_petteh_number = p_payload->>'ref_petteh_number',
        ref_havale_number = p_payload->>'ref_havale_number',
        ref_production_number = p_payload->>'ref_production_number',
        cost_load = COALESCE((p_payload->>'cost_load')::NUMERIC, 0),
        cost_unload = COALESCE((p_payload->>'cost_unload')::NUMERIC, 0),
        cost_warehouse = COALESCE((p_payload->>'cost_warehouse')::NUMERIC, 0),
        cost_tax = COALESCE((p_payload->>'cost_tax')::NUMERIC, 0),
        cost_return_freight = COALESCE((p_payload->>'cost_return_freight')::NUMERIC, 0),
        cost_loading_fee = COALESCE((p_payload->>'cost_loading_fee')::NUMERIC, 0),
        cost_misc = COALESCE((p_payload->>'cost_misc')::NUMERIC, 0),
        cost_misc_desc = p_payload->>'cost_misc_desc',
        payment_by = p_payload->>'payment_by',
        payment_amount = COALESCE((p_payload->>'payment_amount')::NUMERIC, 0),
        payment_source_id = (p_payload->>'payment_source_id')::BIGINT,
        payment_source_type = p_payload->>'payment_source_type',
        card_number = p_payload->>'card_number',
        account_number = p_payload->>'account_number',
        bank_name = p_payload->>'bank_name',
        payment_owner_name = p_payload->>'payment_owner_name',
        payment_tracking_code = p_payload->>'payment_tracking_code',
        updated_at = NOW()
    WHERE id = p_receipt_id
    RETURNING receipt_no INTO v_receipt_no;

    DELETE FROM receipt_items WHERE receipt_id = p_receipt_id;

    IF p_payload ? 'items' AND jsonb_array_length(p_payload->'items') > 0 THEN
        INSERT INTO receipt_items (
            receipt_id, owner_id, product_id, 
            count, 
            parent_row,         -- ✅ اضافه شد
            description_notes,  -- ✅ اضافه شد
            weights_full, weights_empty, weights_net, weights_origin, weights_diff,
            dim_length, dim_width, dim_thickness,
            heat_number, bundle_no, brand, order_no,
            depo_location, row_code, national_product_id, product_description,
            production_type, is_used, is_defective
        )
        SELECT
            p_receipt_id,
            v_owner_id,
            (item->>'product_id')::BIGINT,
            COALESCE((item->>'count')::NUMERIC, (item->>'amount')::NUMERIC, 0), -- پشتیبانی از هر دو نام
            item->>'parent_row',
            COALESCE(item->>'description_notes', item->>'description'), -- پشتیبانی از هر دو نام
            COALESCE((item->>'weights_full')::NUMERIC, 0),
            COALESCE((item->>'weights_empty')::NUMERIC, 0),
            COALESCE((item->>'weights_net')::NUMERIC, 0),
            COALESCE((item->>'weights_origin')::NUMERIC, 0),
            COALESCE((item->>'weights_diff')::NUMERIC, 0),
            COALESCE((item->>'dim_length')::NUMERIC, 0),
            COALESCE((item->>'dim_width')::NUMERIC, 0),
            COALESCE((item->>'dim_thickness')::NUMERIC, 0),
            item->>'heat_number',
            item->>'bundle_no',
            item->>'brand',
            item->>'order_no',
            item->>'depo_location',
            item->>'row_code',
            item->>'national_product_id',
            item->>'product_description',
            COALESCE(item->>'production_type', 'domestic'),
            COALESCE((item->>'is_used')::BOOLEAN, false),
            COALESCE((item->>'is_defective')::BOOLEAN, false)
        FROM jsonb_array_elements(p_payload->'items') AS item;
    END IF;

    RETURN jsonb_build_object('receipt_id', p_receipt_id, 'receipt_no', v_receipt_no, 'status', 'success');
END;
$$;


ALTER FUNCTION public.update_receipt_with_items(p_receipt_id bigint, p_payload jsonb) OWNER TO postgres;

--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer) OWNER TO postgres;

--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text) OWNER TO postgres;

--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) OWNER TO postgres;

--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


ALTER FUNCTION realtime."cast"(val text, type_ regtype) OWNER TO postgres;

--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) OWNER TO postgres;

--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) OWNER TO postgres;

--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


ALTER FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) OWNER TO postgres;

--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION realtime.quote_wal2json(entity regclass) OWNER TO postgres;

--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    -- Generate a new UUID for the id
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean) OWNER TO postgres;

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION realtime.subscription_check_filters() OWNER TO postgres;

--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION realtime.to_regrole(role_name text) OWNER TO postgres;

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: postgres
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION realtime.topic() OWNER TO postgres;

--
-- Name: add_prefixes(text, text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.add_prefixes(_bucket_id text, _name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    prefixes text[];
BEGIN
    prefixes := "storage"."get_prefixes"("_name");

    IF array_length(prefixes, 1) > 0 THEN
        INSERT INTO storage.prefixes (name, bucket_id)
        SELECT UNNEST(prefixes) as name, "_bucket_id" ON CONFLICT DO NOTHING;
    END IF;
END;
$$;


ALTER FUNCTION storage.add_prefixes(_bucket_id text, _name text) OWNER TO postgres;

--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) OWNER TO postgres;

--
-- Name: delete_leaf_prefixes(text[], text[]); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.delete_leaf_prefixes(bucket_ids text[], names text[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_rows_deleted integer;
BEGIN
    LOOP
        WITH candidates AS (
            SELECT DISTINCT
                t.bucket_id,
                unnest(storage.get_prefixes(t.name)) AS name
            FROM unnest(bucket_ids, names) AS t(bucket_id, name)
        ),
        uniq AS (
             SELECT
                 bucket_id,
                 name,
                 storage.get_level(name) AS level
             FROM candidates
             WHERE name <> ''
             GROUP BY bucket_id, name
        ),
        leaf AS (
             SELECT
                 p.bucket_id,
                 p.name,
                 p.level
             FROM storage.prefixes AS p
                  JOIN uniq AS u
                       ON u.bucket_id = p.bucket_id
                           AND u.name = p.name
                           AND u.level = p.level
             WHERE NOT EXISTS (
                 SELECT 1
                 FROM storage.objects AS o
                 WHERE o.bucket_id = p.bucket_id
                   AND o.level = p.level + 1
                   AND o.name COLLATE "C" LIKE p.name || '/%'
             )
             AND NOT EXISTS (
                 SELECT 1
                 FROM storage.prefixes AS c
                 WHERE c.bucket_id = p.bucket_id
                   AND c.level = p.level + 1
                   AND c.name COLLATE "C" LIKE p.name || '/%'
             )
        )
        DELETE
        FROM storage.prefixes AS p
            USING leaf AS l
        WHERE p.bucket_id = l.bucket_id
          AND p.name = l.name
          AND p.level = l.level;

        GET DIAGNOSTICS v_rows_deleted = ROW_COUNT;
        EXIT WHEN v_rows_deleted = 0;
    END LOOP;
END;
$$;


ALTER FUNCTION storage.delete_leaf_prefixes(bucket_ids text[], names text[]) OWNER TO postgres;

--
-- Name: delete_prefix(text, text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.delete_prefix(_bucket_id text, _name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Check if we can delete the prefix
    IF EXISTS(
        SELECT FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name") + 1
          AND "prefixes"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    )
    OR EXISTS(
        SELECT FROM "storage"."objects"
        WHERE "objects"."bucket_id" = "_bucket_id"
          AND "storage"."get_level"("objects"."name") = "storage"."get_level"("_name") + 1
          AND "objects"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    ) THEN
    -- There are sub-objects, skip deletion
    RETURN false;
    ELSE
        DELETE FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name")
          AND "prefixes"."name" = "_name";
        RETURN true;
    END IF;
END;
$$;


ALTER FUNCTION storage.delete_prefix(_bucket_id text, _name text) OWNER TO postgres;

--
-- Name: delete_prefix_hierarchy_trigger(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.delete_prefix_hierarchy_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prefix text;
BEGIN
    prefix := "storage"."get_prefix"(OLD."name");

    IF coalesce(prefix, '') != '' THEN
        PERFORM "storage"."delete_prefix"(OLD."bucket_id", prefix);
    END IF;

    RETURN OLD;
END;
$$;


ALTER FUNCTION storage.delete_prefix_hierarchy_trigger() OWNER TO postgres;

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION storage.enforce_bucket_name_length() OWNER TO postgres;

--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    SELECT _parts[array_length(_parts,1)] INTO _filename;
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION storage.extension(name text) OWNER TO postgres;

--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION storage.filename(name text) OWNER TO postgres;

--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION storage.foldername(name text) OWNER TO postgres;

--
-- Name: get_level(text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.get_level(name text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT array_length(string_to_array("name", '/'), 1);
$$;


ALTER FUNCTION storage.get_level(name text) OWNER TO postgres;

--
-- Name: get_prefix(text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.get_prefix(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT
    CASE WHEN strpos("name", '/') > 0 THEN
             regexp_replace("name", '[\/]{1}[^\/]+\/?$', '')
         ELSE
             ''
        END;
$_$;


ALTER FUNCTION storage.get_prefix(name text) OWNER TO postgres;

--
-- Name: get_prefixes(text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.get_prefixes(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    parts text[];
    prefixes text[];
    prefix text;
BEGIN
    -- Split the name into parts by '/'
    parts := string_to_array("name", '/');
    prefixes := '{}';

    -- Construct the prefixes, stopping one level below the last part
    FOR i IN 1..array_length(parts, 1) - 1 LOOP
            prefix := array_to_string(parts[1:i], '/');
            prefixes := array_append(prefixes, prefix);
    END LOOP;

    RETURN prefixes;
END;
$$;


ALTER FUNCTION storage.get_prefixes(name text) OWNER TO postgres;

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION storage.get_size_by_bucket() OWNER TO postgres;

--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text) OWNER TO postgres;

--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


ALTER FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text) OWNER TO postgres;

--
-- Name: lock_top_prefixes(text[], text[]); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.lock_top_prefixes(bucket_ids text[], names text[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket text;
    v_top text;
BEGIN
    FOR v_bucket, v_top IN
        SELECT DISTINCT t.bucket_id,
            split_part(t.name, '/', 1) AS top
        FROM unnest(bucket_ids, names) AS t(bucket_id, name)
        WHERE t.name <> ''
        ORDER BY 1, 2
        LOOP
            PERFORM pg_advisory_xact_lock(hashtextextended(v_bucket || '/' || v_top, 0));
        END LOOP;
END;
$$;


ALTER FUNCTION storage.lock_top_prefixes(bucket_ids text[], names text[]) OWNER TO postgres;

--
-- Name: objects_delete_cleanup(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.objects_delete_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket_ids text[];
    v_names      text[];
BEGIN
    IF current_setting('storage.gc.prefixes', true) = '1' THEN
        RETURN NULL;
    END IF;

    PERFORM set_config('storage.gc.prefixes', '1', true);

    SELECT COALESCE(array_agg(d.bucket_id), '{}'),
           COALESCE(array_agg(d.name), '{}')
    INTO v_bucket_ids, v_names
    FROM deleted AS d
    WHERE d.name <> '';

    PERFORM storage.lock_top_prefixes(v_bucket_ids, v_names);
    PERFORM storage.delete_leaf_prefixes(v_bucket_ids, v_names);

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.objects_delete_cleanup() OWNER TO postgres;

--
-- Name: objects_insert_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.objects_insert_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    NEW.level := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_insert_prefix_trigger() OWNER TO postgres;

--
-- Name: objects_update_cleanup(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.objects_update_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    -- NEW - OLD (destinations to create prefixes for)
    v_add_bucket_ids text[];
    v_add_names      text[];

    -- OLD - NEW (sources to prune)
    v_src_bucket_ids text[];
    v_src_names      text[];
BEGIN
    IF TG_OP <> 'UPDATE' THEN
        RETURN NULL;
    END IF;

    -- 1) Compute NEW−OLD (added paths) and OLD−NEW (moved-away paths)
    WITH added AS (
        SELECT n.bucket_id, n.name
        FROM new_rows n
        WHERE n.name <> '' AND position('/' in n.name) > 0
        EXCEPT
        SELECT o.bucket_id, o.name FROM old_rows o WHERE o.name <> ''
    ),
    moved AS (
         SELECT o.bucket_id, o.name
         FROM old_rows o
         WHERE o.name <> ''
         EXCEPT
         SELECT n.bucket_id, n.name FROM new_rows n WHERE n.name <> ''
    )
    SELECT
        -- arrays for ADDED (dest) in stable order
        COALESCE( (SELECT array_agg(a.bucket_id ORDER BY a.bucket_id, a.name) FROM added a), '{}' ),
        COALESCE( (SELECT array_agg(a.name      ORDER BY a.bucket_id, a.name) FROM added a), '{}' ),
        -- arrays for MOVED (src) in stable order
        COALESCE( (SELECT array_agg(m.bucket_id ORDER BY m.bucket_id, m.name) FROM moved m), '{}' ),
        COALESCE( (SELECT array_agg(m.name      ORDER BY m.bucket_id, m.name) FROM moved m), '{}' )
    INTO v_add_bucket_ids, v_add_names, v_src_bucket_ids, v_src_names;

    -- Nothing to do?
    IF (array_length(v_add_bucket_ids, 1) IS NULL) AND (array_length(v_src_bucket_ids, 1) IS NULL) THEN
        RETURN NULL;
    END IF;

    -- 2) Take per-(bucket, top) locks: ALL prefixes in consistent global order to prevent deadlocks
    DECLARE
        v_all_bucket_ids text[];
        v_all_names text[];
    BEGIN
        -- Combine source and destination arrays for consistent lock ordering
        v_all_bucket_ids := COALESCE(v_src_bucket_ids, '{}') || COALESCE(v_add_bucket_ids, '{}');
        v_all_names := COALESCE(v_src_names, '{}') || COALESCE(v_add_names, '{}');

        -- Single lock call ensures consistent global ordering across all transactions
        IF array_length(v_all_bucket_ids, 1) IS NOT NULL THEN
            PERFORM storage.lock_top_prefixes(v_all_bucket_ids, v_all_names);
        END IF;
    END;

    -- 3) Create destination prefixes (NEW−OLD) BEFORE pruning sources
    IF array_length(v_add_bucket_ids, 1) IS NOT NULL THEN
        WITH candidates AS (
            SELECT DISTINCT t.bucket_id, unnest(storage.get_prefixes(t.name)) AS name
            FROM unnest(v_add_bucket_ids, v_add_names) AS t(bucket_id, name)
            WHERE name <> ''
        )
        INSERT INTO storage.prefixes (bucket_id, name)
        SELECT c.bucket_id, c.name
        FROM candidates c
        ON CONFLICT DO NOTHING;
    END IF;

    -- 4) Prune source prefixes bottom-up for OLD−NEW
    IF array_length(v_src_bucket_ids, 1) IS NOT NULL THEN
        -- re-entrancy guard so DELETE on prefixes won't recurse
        IF current_setting('storage.gc.prefixes', true) <> '1' THEN
            PERFORM set_config('storage.gc.prefixes', '1', true);
        END IF;

        PERFORM storage.delete_leaf_prefixes(v_src_bucket_ids, v_src_names);
    END IF;

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.objects_update_cleanup() OWNER TO postgres;

--
-- Name: objects_update_level_trigger(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.objects_update_level_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Set the new level
        NEW."level" := "storage"."get_level"(NEW."name");
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_update_level_trigger() OWNER TO postgres;

--
-- Name: objects_update_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.objects_update_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    old_prefixes TEXT[];
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Retrieve old prefixes
        old_prefixes := "storage"."get_prefixes"(OLD."name");

        -- Remove old prefixes that are only used by this object
        WITH all_prefixes as (
            SELECT unnest(old_prefixes) as prefix
        ),
        can_delete_prefixes as (
             SELECT prefix
             FROM all_prefixes
             WHERE NOT EXISTS (
                 SELECT 1 FROM "storage"."objects"
                 WHERE "bucket_id" = OLD."bucket_id"
                   AND "name" <> OLD."name"
                   AND "name" LIKE (prefix || '%')
             )
         )
        DELETE FROM "storage"."prefixes" WHERE name IN (SELECT prefix FROM can_delete_prefixes);

        -- Add new prefixes
        PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    END IF;
    -- Set the new level
    NEW."level" := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.objects_update_prefix_trigger() OWNER TO postgres;

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION storage.operation() OWNER TO postgres;

--
-- Name: prefixes_delete_cleanup(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.prefixes_delete_cleanup() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    v_bucket_ids text[];
    v_names      text[];
BEGIN
    IF current_setting('storage.gc.prefixes', true) = '1' THEN
        RETURN NULL;
    END IF;

    PERFORM set_config('storage.gc.prefixes', '1', true);

    SELECT COALESCE(array_agg(d.bucket_id), '{}'),
           COALESCE(array_agg(d.name), '{}')
    INTO v_bucket_ids, v_names
    FROM deleted AS d
    WHERE d.name <> '';

    PERFORM storage.lock_top_prefixes(v_bucket_ids, v_names);
    PERFORM storage.delete_leaf_prefixes(v_bucket_ids, v_names);

    RETURN NULL;
END;
$$;


ALTER FUNCTION storage.prefixes_delete_cleanup() OWNER TO postgres;

--
-- Name: prefixes_insert_trigger(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.prefixes_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    RETURN NEW;
END;
$$;


ALTER FUNCTION storage.prefixes_insert_trigger() OWNER TO postgres;

--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql
    AS $$
declare
    can_bypass_rls BOOLEAN;
begin
    SELECT rolbypassrls
    INTO can_bypass_rls
    FROM pg_roles
    WHERE rolname = coalesce(nullif(current_setting('role', true), 'none'), current_user);

    IF can_bypass_rls THEN
        RETURN QUERY SELECT * FROM storage.search_v1_optimised(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    ELSE
        RETURN QUERY SELECT * FROM storage.search_legacy_v1(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    END IF;
end;
$$;


ALTER FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO postgres;

--
-- Name: search_legacy_v1(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select path_tokens[$1] as folder
           from storage.objects
             where objects.name ilike $2 || $3 || ''%''
               and bucket_id = $4
               and array_length(objects.path_tokens, 1) <> $1
           group by folder
           order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO postgres;

--
-- Name: search_v1_optimised(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select (string_to_array(name, ''/''))[level] as name
           from storage.prefixes
             where lower(prefixes.name) like lower($2 || $3) || ''%''
               and bucket_id = $4
               and level = $1
           order by name ' || v_sort_order || '
     )
     (select name,
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[level] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where lower(objects.name) like lower($2 || $3) || ''%''
       and bucket_id = $4
       and level = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


ALTER FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text) OWNER TO postgres;

--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    sort_col text;
    sort_ord text;
    cursor_op text;
    cursor_expr text;
    sort_expr text;
BEGIN
    -- Validate sort_order
    sort_ord := lower(sort_order);
    IF sort_ord NOT IN ('asc', 'desc') THEN
        sort_ord := 'asc';
    END IF;

    -- Determine cursor comparison operator
    IF sort_ord = 'asc' THEN
        cursor_op := '>';
    ELSE
        cursor_op := '<';
    END IF;
    
    sort_col := lower(sort_column);
    -- Validate sort column  
    IF sort_col IN ('updated_at', 'created_at') THEN
        cursor_expr := format(
            '($5 = '''' OR ROW(date_trunc(''milliseconds'', %I), name COLLATE "C") %s ROW(COALESCE(NULLIF($6, '''')::timestamptz, ''epoch''::timestamptz), $5))',
            sort_col, cursor_op
        );
        sort_expr := format(
            'COALESCE(date_trunc(''milliseconds'', %I), ''epoch''::timestamptz) %s, name COLLATE "C" %s',
            sort_col, sort_ord, sort_ord
        );
    ELSE
        cursor_expr := format('($5 = '''' OR name COLLATE "C" %s $5)', cursor_op);
        sort_expr := format('name COLLATE "C" %s', sort_ord);
    END IF;

    RETURN QUERY EXECUTE format(
        $sql$
        SELECT * FROM (
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name,
                    NULL::uuid AS id,
                    updated_at,
                    created_at,
                    NULL::timestamptz AS last_accessed_at,
                    NULL::jsonb AS metadata
                FROM storage.prefixes
                WHERE name COLLATE "C" LIKE $1 || '%%'
                    AND bucket_id = $2
                    AND level = $4
                    AND %s
                ORDER BY %s
                LIMIT $3
            )
            UNION ALL
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name,
                    id,
                    updated_at,
                    created_at,
                    last_accessed_at,
                    metadata
                FROM storage.objects
                WHERE name COLLATE "C" LIKE $1 || '%%'
                    AND bucket_id = $2
                    AND level = $4
                    AND %s
                ORDER BY %s
                LIMIT $3
            )
        ) obj
        ORDER BY %s
        LIMIT $3
        $sql$,
        cursor_expr,    -- prefixes WHERE
        sort_expr,      -- prefixes ORDER BY
        cursor_expr,    -- objects WHERE
        sort_expr,      -- objects ORDER BY
        sort_expr       -- final ORDER BY
    )
    USING prefix, bucket_name, limits, levels, start_after, sort_column_after;
END;
$_$;


ALTER FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text) OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: postgres
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION storage.update_updated_at_column() OWNER TO postgres;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE auth.audit_log_entries OWNER TO postgres;

--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


ALTER TABLE auth.flow_state OWNER TO postgres;

--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE auth.identities OWNER TO postgres;

--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE auth.instances OWNER TO postgres;

--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE auth.mfa_amr_claims OWNER TO postgres;

--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


ALTER TABLE auth.mfa_challenges OWNER TO postgres;

--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


ALTER TABLE auth.mfa_factors OWNER TO postgres;

--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


ALTER TABLE auth.oauth_authorizations OWNER TO postgres;

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE auth.oauth_client_states OWNER TO postgres;

--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048))
);


ALTER TABLE auth.oauth_clients OWNER TO postgres;

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


ALTER TABLE auth.oauth_consents OWNER TO postgres;

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


ALTER TABLE auth.one_time_tokens OWNER TO postgres;

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


ALTER TABLE auth.refresh_tokens OWNER TO postgres;

--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: postgres
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE auth.refresh_tokens_id_seq OWNER TO postgres;

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: postgres
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


ALTER TABLE auth.saml_providers OWNER TO postgres;

--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


ALTER TABLE auth.saml_relay_states OWNER TO postgres;

--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE auth.schema_migrations OWNER TO postgres;

--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


ALTER TABLE auth.sessions OWNER TO postgres;

--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


ALTER TABLE auth.sso_domains OWNER TO postgres;

--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


ALTER TABLE auth.sso_providers OWNER TO postgres;

--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: postgres
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


ALTER TABLE auth.users OWNER TO postgres;

--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: access_audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access_audit_logs (
    id bigint NOT NULL,
    member_id uuid NOT NULL,
    actor_user_id uuid NOT NULL,
    action text NOT NULL,
    target_type text NOT NULL,
    target_id text,
    payload jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.access_audit_logs OWNER TO postgres;

--
-- Name: access_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.access_audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.access_audit_logs_id_seq OWNER TO postgres;

--
-- Name: access_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.access_audit_logs_id_seq OWNED BY public.access_audit_logs.id;


--
-- Name: accounting_gl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounting_gl (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    group_id uuid,
    code character varying(10) NOT NULL,
    title text NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);


ALTER TABLE public.accounting_gl OWNER TO postgres;

--
-- Name: accounting_gl_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounting_gl_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounting_gl_id_seq OWNER TO postgres;

--
-- Name: accounting_gl_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounting_gl_id_seq OWNED BY public.accounting_gl.id;


--
-- Name: accounting_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounting_groups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(10) NOT NULL,
    title text NOT NULL,
    category text,
    nature text,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
    CONSTRAINT accounting_groups_category_check CHECK ((category = ANY (ARRAY['asset'::text, 'liability'::text, 'equity'::text, 'revenue'::text, 'expense'::text]))),
    CONSTRAINT accounting_groups_nature_check CHECK ((nature = ANY (ARRAY['debtor'::text, 'creditor'::text, 'dual'::text])))
);


ALTER TABLE public.accounting_groups OWNER TO postgres;

--
-- Name: accounting_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounting_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounting_groups_id_seq OWNER TO postgres;

--
-- Name: accounting_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounting_groups_id_seq OWNED BY public.accounting_groups.id;


--
-- Name: accounting_moein; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounting_moein (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    gl_id uuid,
    code character varying(20) NOT NULL,
    title text NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);


ALTER TABLE public.accounting_moein OWNER TO postgres;

--
-- Name: accounting_moein_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounting_moein_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounting_moein_id_seq OWNER TO postgres;

--
-- Name: accounting_moein_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounting_moein_id_seq OWNED BY public.accounting_moein.id;


--
-- Name: accounting_tafsili; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounting_tafsili (
    id uuid DEFAULT (md5(((random())::text || (clock_timestamp())::text)))::uuid NOT NULL,
    code character varying(50),
    title text NOT NULL,
    tafsili_type text DEFAULT 'other'::text,
    ref_id uuid,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
    member_id uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.accounting_tafsili OWNER TO postgres;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    member_id uuid NOT NULL,
    user_name text,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    description text,
    ip_address text,
    user_agent text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.activity_logs OWNER TO union_api;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: union_api
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO union_api;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: union_api
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: base_banks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.base_banks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    code character varying(10),
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);


ALTER TABLE public.base_banks OWNER TO postgres;

--
-- Name: base_banks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.base_banks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.base_banks_id_seq OWNER TO postgres;

--
-- Name: base_banks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.base_banks_id_seq OWNED BY public.base_banks.id;


--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.calendar_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    title text NOT NULL,
    description text,
    event_date date NOT NULL,
    event_time time without time zone,
    event_type text DEFAULT 'manual'::text NOT NULL,
    category text DEFAULT 'general'::text,
    ref_id uuid,
    ref_table text,
    color text DEFAULT '#556ee6'::text,
    is_reminder boolean DEFAULT false,
    reminder_date date,
    reminder_time time without time zone,
    reminder_method text DEFAULT 'native'::text,
    reminder_sent boolean DEFAULT false,
    is_recurring boolean DEFAULT false,
    recurrence_rule text,
    status text DEFAULT 'active'::text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.calendar_events OWNER TO union_api;

--
-- Name: clearances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clearances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    doc_type_id uuid NOT NULL,
    clearance_no bigint NOT NULL,
    member_id uuid NOT NULL,
    status text NOT NULL,
    clearance_date date NOT NULL,
    customer_id uuid NOT NULL,
    receiver_type text DEFAULT 'person'::text,
    receiver_person_name text,
    receiver_person_national_id text,
    receiver_company_name text,
    receiver_company_registration_no text,
    receiver_company_economic_code text,
    driver_name text,
    driver_national_id text,
    driver_phone text,
    vehicle_plate_iran_right text,
    vehicle_plate_mid3 text,
    vehicle_plate_letter text,
    vehicle_plate_left2 text,
    vehicle_vehicle_type text,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    nwms_id text,
    nwms_status text DEFAULT 'not_sent'::text,
    CONSTRAINT clearances_receiver_type_check CHECK ((receiver_type = ANY (ARRAY['person'::text, 'company'::text]))),
    CONSTRAINT clearances_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'final'::text, 'cancelled'::text]))),
    CONSTRAINT clearances_vehicle_vehicle_type_check CHECK ((vehicle_vehicle_type = ANY (ARRAY['pickup'::text, 'truck'::text, 'light_truck'::text, 'trailer'::text])))
);


ALTER TABLE public.clearances OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    customer_type text NOT NULL,
    name text NOT NULL,
    national_id text,
    mobile text,
    phone text,
    economic_code text,
    postal_code text,
    birth_or_register_date date,
    address text,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    tafsili_id uuid,
    auth_user_id uuid,
    member_id uuid,
    otp_code character varying(6),
    otp_expires timestamp with time zone,
    CONSTRAINT customers_customer_type_check CHECK ((customer_type = ANY (ARRAY['person'::text, 'company'::text])))
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: doc_no_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.doc_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.doc_no_seq OWNER TO postgres;

--
-- Name: document_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.document_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code integer NOT NULL,
    name text NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.document_types OWNER TO postgres;

--
-- Name: financial_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.financial_documents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    doc_no integer DEFAULT nextval('public.doc_no_seq'::regclass) NOT NULL,
    doc_date date NOT NULL,
    manual_no character varying(50),
    description text,
    status text DEFAULT 'draft'::text,
    doc_type text DEFAULT 'system'::text,
    related_exit_id uuid,
    created_by uuid,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
    reference_id uuid,
    reference_type text,
    member_id uuid NOT NULL
);


ALTER TABLE public.financial_documents OWNER TO postgres;

--
-- Name: financial_documents_doc_no_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.financial_documents_doc_no_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.financial_documents_doc_no_seq OWNER TO postgres;

--
-- Name: financial_documents_doc_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.financial_documents_doc_no_seq OWNED BY public.financial_documents.doc_no;


--
-- Name: financial_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.financial_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    doc_id uuid,
    moein_id uuid NOT NULL,
    tafsili_id uuid,
    bed numeric(18,0) DEFAULT 0,
    bes numeric(18,0) DEFAULT 0,
    description text,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
    moin_id uuid,
    member_id uuid
);


ALTER TABLE public.financial_entries OWNER TO postgres;

--
-- Name: inventory_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ref_receipt_id uuid,
    product_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    member_id text,
    unit_id uuid,
    type text,
    qty numeric DEFAULT 0,
    weight numeric DEFAULT 0,
    qty_real numeric DEFAULT 0,
    weight_real numeric DEFAULT 0,
    qty_available numeric DEFAULT 0,
    weight_available numeric DEFAULT 0,
    snapshot_qty_before numeric,
    snapshot_qty_after numeric,
    batch_no text,
    parent_batch_no text,
    description text,
    receiver_name text,
    receiver_national_id text,
    ref_clearance_id uuid,
    ref_exit_id uuid,
    reference_id uuid,
    transaction_type text,
    transaction_date timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.inventory_transactions OWNER TO postgres;

--
-- Name: inventory_stock; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.inventory_stock AS
 SELECT product_id,
    owner_id,
    sum(
        CASE
            WHEN (type = 'in'::text) THEN qty
            ELSE (0)::numeric
        END) AS qty_in,
    sum(
        CASE
            WHEN (type = 'in'::text) THEN weight
            ELSE (0)::numeric
        END) AS weight_in,
    sum(
        CASE
            WHEN (type = ANY (ARRAY['out'::text, 'exit'::text])) THEN qty
            ELSE (0)::numeric
        END) AS qty_out,
    sum(
        CASE
            WHEN (type = ANY (ARRAY['out'::text, 'exit'::text])) THEN weight
            ELSE (0)::numeric
        END) AS weight_out,
    sum(
        CASE
            WHEN (type = 'in'::text) THEN qty
            WHEN (type = ANY (ARRAY['out'::text, 'exit'::text])) THEN (- qty)
            ELSE (0)::numeric
        END) AS qty_on_hand,
    sum(
        CASE
            WHEN (type = 'in'::text) THEN weight
            WHEN (type = ANY (ARRAY['out'::text, 'exit'::text])) THEN (- weight)
            ELSE (0)::numeric
        END) AS weight_on_hand
   FROM public.inventory_transactions
  GROUP BY product_id, owner_id;


ALTER VIEW public.inventory_stock OWNER TO postgres;

--
-- Name: loading_order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loading_order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    loading_order_id uuid,
    clearance_item_id uuid,
    product_id uuid,
    batch_no text,
    qty numeric,
    weight numeric
);


ALTER TABLE public.loading_order_items OWNER TO postgres;

--
-- Name: loading_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.loading_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_no bigint NOT NULL,
    clearance_id uuid,
    loading_date timestamp without time zone DEFAULT now(),
    driver_name text,
    plate_number text,
    warehouse_keeper_id uuid,
    status text DEFAULT 'issued'::text,
    description text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    member_id uuid
);


ALTER TABLE public.loading_orders OWNER TO postgres;

--
-- Name: media; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    filepath text NOT NULL,
    filename text NOT NULL,
    mimetype text,
    size bigint,
    width integer,
    height integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    related_id uuid,
    related_table text,
    description text,
    member_id uuid
);


ALTER TABLE public.media OWNER TO postgres;

--
-- Name: members; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.members (
    role text DEFAULT 'union_member'::text NOT NULL,
    email text,
    member_code text NOT NULL,
    full_name text NOT NULL,
    father_name text,
    national_id text,
    mobile text NOT NULL,
    phone text,
    address text,
    birth_date date,
    business_name text,
    category text DEFAULT 'warehouse'::text,
    member_status text DEFAULT 'active'::text,
    otp_code text,
    otp_expires timestamp with time zone,
    license_number text,
    license_issue_date date,
    license_expire_date date,
    license_image bigint,
    national_card_image bigint,
    id_card_image bigint,
    company_license_image bigint,
    member_image bigint,
    company_name text,
    registration_number text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    auth_user_id uuid,
    owner_id uuid,
    permissions jsonb DEFAULT '[]'::jsonb,
    id uuid NOT NULL
);


ALTER TABLE public.members OWNER TO union_api;

--
-- Name: opening_balance_banks; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.opening_balance_banks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    opening_balance_id uuid NOT NULL,
    bank_id uuid NOT NULL,
    amount numeric DEFAULT 0 NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.opening_balance_banks OWNER TO union_api;

--
-- Name: opening_balance_cashes; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.opening_balance_cashes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    opening_balance_id uuid NOT NULL,
    cash_id uuid NOT NULL,
    amount numeric DEFAULT 0 NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.opening_balance_cashes OWNER TO union_api;

--
-- Name: opening_balance_customers; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.opening_balance_customers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    opening_balance_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    balance_type character varying(10) DEFAULT 'bedehkar'::character varying NOT NULL,
    amount numeric DEFAULT 0 NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.opening_balance_customers OWNER TO union_api;

--
-- Name: opening_balance_items; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.opening_balance_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    opening_balance_id uuid NOT NULL,
    product_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    qty numeric DEFAULT 0,
    weight numeric DEFAULT 0,
    batch_no text,
    description text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.opening_balance_items OWNER TO union_api;

--
-- Name: opening_balances; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.opening_balances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    description text,
    created_by uuid,
    is_locked boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    section character varying(20) DEFAULT 'inventory'::character varying
);


ALTER TABLE public.opening_balances OWNER TO union_api;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    module text NOT NULL,
    action text NOT NULL,
    title text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    parent_id uuid,
    description text,
    image_id uuid,
    is_active boolean DEFAULT true,
    sort_order integer DEFAULT 0,
    storage_cost numeric,
    loading_cost numeric,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    fee_type text DEFAULT 'weight'::text,
    fee_amount numeric DEFAULT 0,
    calc_method text DEFAULT 'weight'::text,
    member_id uuid,
    CONSTRAINT product_categories_calc_method_check CHECK ((calc_method = ANY (ARRAY['weight'::text, 'qty'::text])))
);


ALTER TABLE public.product_categories OWNER TO postgres;

--
-- Name: product_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_images (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    media_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.product_images OWNER TO postgres;

--
-- Name: product_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_units (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    symbol text NOT NULL,
    code text,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.product_units OWNER TO postgres;

--
-- Name: receipt_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.receipt_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    receipt_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    is_parent boolean DEFAULT false,
    parent_id uuid,
    parent_row text,
    row_code text,
    national_product_id text,
    product_description text,
    count numeric DEFAULT 0,
    production_type text DEFAULT 'domestic'::text NOT NULL,
    is_used boolean DEFAULT false,
    is_defective boolean DEFAULT false,
    weights_full numeric DEFAULT 0,
    weights_empty numeric DEFAULT 0,
    weights_net numeric DEFAULT 0,
    weights_origin numeric DEFAULT 0,
    weights_diff numeric DEFAULT 0,
    dim_length numeric DEFAULT 0,
    dim_width numeric DEFAULT 0,
    dim_thickness numeric DEFAULT 0,
    heat_number text,
    bundle_no text,
    brand text,
    order_no text,
    depo_location text,
    description_notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    product_id uuid NOT NULL,
    member_id uuid,
    CONSTRAINT receipt_items_count_nonnegative CHECK ((count >= (0)::numeric)),
    CONSTRAINT receipt_items_production_type_check CHECK ((production_type = ANY (ARRAY['domestic'::text, 'import'::text])))
);


ALTER TABLE public.receipt_items OWNER TO postgres;

--
-- Name: receipts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.receipts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    doc_type_id uuid NOT NULL,
    receipt_no bigint NOT NULL,
    member_id uuid,
    status text NOT NULL,
    doc_date date NOT NULL,
    ref_type text DEFAULT 'none'::text,
    ref_barnameh_number text,
    ref_barnameh_date date,
    ref_barnameh_tracking text,
    ref_petteh_number text,
    ref_havale_number text,
    ref_production_number text,
    owner_id uuid NOT NULL,
    deliverer_id uuid,
    driver_name text,
    driver_national_id text,
    driver_birth_date date,
    plate_iran_right text,
    plate_mid3 text,
    plate_letter text,
    plate_left2 text,
    load_cost numeric DEFAULT 0,
    unload_cost numeric DEFAULT 0,
    warehouse_cost numeric DEFAULT 0,
    tax numeric DEFAULT 0,
    return_freight numeric DEFAULT 0,
    loading_fee numeric DEFAULT 0,
    misc_cost numeric DEFAULT 0,
    misc_description text,
    payment_by text DEFAULT 'customer'::text NOT NULL,
    card_number text,
    account_number text,
    bank_name text,
    payment_owner_name text,
    tracking_code text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    driver_phone text,
    discharge_date date,
    cost_load numeric DEFAULT 0,
    cost_unload numeric DEFAULT 0,
    cost_warehouse numeric DEFAULT 0,
    cost_tax numeric DEFAULT 0,
    cost_return_freight numeric DEFAULT 0,
    cost_loading_fee numeric DEFAULT 0,
    cost_misc numeric DEFAULT 0,
    cost_misc_desc text,
    payment_amount numeric DEFAULT 0,
    payment_source_id uuid,
    payment_source_type text,
    payment_tracking_code text,
    nwms_id text,
    nwms_status text DEFAULT 'not_sent'::text,
    CONSTRAINT receipts_costs_nonnegative CHECK (((load_cost >= (0)::numeric) AND (unload_cost >= (0)::numeric) AND (warehouse_cost >= (0)::numeric) AND (tax >= (0)::numeric) AND (return_freight >= (0)::numeric) AND (loading_fee >= (0)::numeric) AND (misc_cost >= (0)::numeric))),
    CONSTRAINT receipts_payment_by_check CHECK ((payment_by = ANY (ARRAY['customer'::text, 'warehouse'::text]))),
    CONSTRAINT receipts_ref_type_check CHECK ((ref_type = ANY (ARRAY['none'::text, 'barnameh'::text, 'petteh'::text, 'havale'::text, 'production'::text]))),
    CONSTRAINT receipts_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'final'::text, 'cancelled'::text])))
);


ALTER TABLE public.receipts OWNER TO postgres;

--
-- Name: receipt_no_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.receipt_no_seq
    START WITH 1001
    INCREMENT BY 1
    MINVALUE 1001
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.receipt_no_seq OWNER TO postgres;

--
-- Name: receipt_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.receipt_no_seq OWNED BY public.receipts.receipt_no;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    constraints_json jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    code text NOT NULL,
    title text NOT NULL,
    description text,
    is_system boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: sms_logs; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.sms_logs (
    id integer NOT NULL,
    member_id uuid NOT NULL,
    recipients text[] NOT NULL,
    recipient_names text[],
    message text NOT NULL,
    send_type character varying(20) DEFAULT 'single'::character varying NOT NULL,
    category_filter character varying(50),
    status_filter character varying(50),
    total_count integer DEFAULT 0,
    success_count integer DEFAULT 0,
    fail_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.sms_logs OWNER TO union_api;

--
-- Name: sms_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: union_api
--

CREATE SEQUENCE public.sms_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sms_logs_id_seq OWNER TO union_api;

--
-- Name: sms_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: union_api
--

ALTER SEQUENCE public.sms_logs_id_seq OWNED BY public.sms_logs.id;


--
-- Name: ticket_categories; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.ticket_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    icon character varying(50) DEFAULT 'bx-help-circle'::character varying,
    color character varying(20) DEFAULT '#556ee6'::character varying,
    sort_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ticket_categories OWNER TO union_api;

--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.ticket_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ticket_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    sender_name character varying(100),
    sender_role character varying(30) DEFAULT 'user'::character varying,
    message text NOT NULL,
    is_internal boolean DEFAULT false,
    attachments jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ticket_messages OWNER TO union_api;

--
-- Name: tickets; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.tickets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    ticket_no integer NOT NULL,
    category_id uuid,
    subject character varying(255) NOT NULL,
    description text,
    priority character varying(20) DEFAULT 'medium'::character varying,
    status character varying(20) DEFAULT 'open'::character varying,
    created_by uuid NOT NULL,
    created_by_name character varying(100),
    assigned_to uuid,
    assigned_to_name character varying(100),
    closed_at timestamp with time zone,
    closed_by uuid,
    rating integer,
    rating_comment text,
    tags text[],
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tickets_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'urgent'::character varying])::text[]))),
    CONSTRAINT tickets_rating_check CHECK (((rating >= 1) AND (rating <= 5))),
    CONSTRAINT tickets_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'in_progress'::character varying, 'waiting'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


ALTER TABLE public.tickets OWNER TO union_api;

--
-- Name: tickets_ticket_no_seq; Type: SEQUENCE; Schema: public; Owner: union_api
--

CREATE SEQUENCE public.tickets_ticket_no_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tickets_ticket_no_seq OWNER TO union_api;

--
-- Name: tickets_ticket_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: union_api
--

ALTER SEQUENCE public.tickets_ticket_no_seq OWNED BY public.tickets.ticket_no;


--
-- Name: treasury_banks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.treasury_banks (
    id uuid DEFAULT (md5(((random())::text || (clock_timestamp())::text)))::uuid NOT NULL,
    bank_name text NOT NULL,
    branch_name text,
    account_no text,
    sheba_no text,
    card_no text,
    tafsili_id uuid,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
    member_id uuid,
    owner_id uuid,
    shaba_no text,
    initial_balance numeric DEFAULT 0,
    description text,
    is_active boolean DEFAULT true
);


ALTER TABLE public.treasury_banks OWNER TO postgres;

--
-- Name: treasury_cashes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.treasury_cashes (
    id uuid DEFAULT (md5(((random())::text || (clock_timestamp())::text)))::uuid NOT NULL,
    title text NOT NULL,
    keeper_name text,
    tafsili_id uuid,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
    member_id uuid NOT NULL,
    initial_balance numeric DEFAULT 0,
    description text,
    is_active boolean DEFAULT true
);


ALTER TABLE public.treasury_cashes OWNER TO postgres;

--
-- Name: treasury_check_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.treasury_check_details (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    checkbook_id uuid,
    serial_no text NOT NULL,
    status text DEFAULT 'unused'::text,
    check_id uuid,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
    member_id uuid
);


ALTER TABLE public.treasury_check_details OWNER TO postgres;

--
-- Name: treasury_checkbooks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.treasury_checkbooks (
    id uuid DEFAULT (md5(((random())::text || (clock_timestamp())::text)))::uuid NOT NULL,
    bank_id uuid,
    serial_start bigint NOT NULL,
    serial_end bigint NOT NULL,
    current_serial bigint,
    status text DEFAULT 'active'::text,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
    member_id uuid NOT NULL,
    description text
);


ALTER TABLE public.treasury_checkbooks OWNER TO postgres;

--
-- Name: treasury_checks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.treasury_checks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type text NOT NULL,
    amount numeric NOT NULL,
    cheque_no text NOT NULL,
    bank_name text,
    branch_name text,
    due_date date,
    status text DEFAULT 'pending'::text,
    owner_id uuid,
    receiver_id uuid,
    checkbook_id uuid,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
    sayadi_code text,
    branch_code text,
    account_no text,
    account_holder text,
    description text,
    endorsement text,
    target_bank_id uuid,
    member_id uuid NOT NULL,
    last_sms_reminder timestamp with time zone
);


ALTER TABLE public.treasury_checks OWNER TO postgres;

--
-- Name: treasury_pos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.treasury_pos (
    id uuid DEFAULT (md5(((random())::text || (clock_timestamp())::text)))::uuid NOT NULL,
    title text NOT NULL,
    bank_id uuid,
    terminal_id text,
    tafsili_id uuid,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()),
    member_id uuid NOT NULL,
    description text,
    is_active boolean DEFAULT true
);


ALTER TABLE public.treasury_pos OWNER TO postgres;

--
-- Name: ui_form_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ui_form_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    form_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    required_for text NOT NULL,
    CONSTRAINT ui_form_permissions_required_for_check CHECK ((required_for = ANY (ARRAY['view'::text, 'create'::text, 'edit'::text, 'delete'::text, 'approve'::text, 'print'::text, 'export'::text])))
);


ALTER TABLE public.ui_form_permissions OWNER TO postgres;

--
-- Name: ui_forms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ui_forms (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    form_code text NOT NULL,
    title text NOT NULL,
    route text NOT NULL,
    module text NOT NULL,
    icon text,
    parent_id uuid,
    menu_order integer DEFAULT 0 NOT NULL,
    is_menu_item boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    path text,
    permission_code text
);


ALTER TABLE public.ui_forms OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    valid_from timestamp with time zone DEFAULT now() NOT NULL,
    valid_to timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: view_receipt_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.view_receipt_summary AS
SELECT
    NULL::uuid AS id,
    NULL::bigint AS receipt_no,
    NULL::date AS doc_date,
    NULL::text AS status,
    NULL::text AS driver_name,
    NULL::text AS full_plate,
    NULL::numeric AS payment_amount,
    NULL::bigint AS total_items,
    NULL::numeric AS total_quantity,
    NULL::numeric AS total_net_weight,
    NULL::timestamp with time zone AS created_at;


ALTER VIEW public.view_receipt_summary OWNER TO postgres;

--
-- Name: warehouse_exit_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_exit_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    warehouse_exit_id uuid,
    loading_item_id uuid NOT NULL,
    weight_full numeric DEFAULT 0,
    weight_empty numeric DEFAULT 0,
    weight_net numeric DEFAULT 0,
    fee_type text,
    fee_price numeric,
    final_fee numeric,
    created_at timestamp without time zone DEFAULT now(),
    loading_fee numeric DEFAULT 0,
    qty numeric DEFAULT 0
);


ALTER TABLE public.warehouse_exit_items OWNER TO postgres;

--
-- Name: warehouse_exits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_exits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    exit_no bigint NOT NULL,
    loading_order_id uuid,
    exit_date timestamp without time zone DEFAULT now(),
    total_fee numeric DEFAULT 0,
    description text,
    status text DEFAULT 'final'::text,
    created_at timestamp without time zone DEFAULT now(),
    reference_no text,
    total_loading_fee numeric DEFAULT 0,
    weighbridge_fee numeric DEFAULT 0,
    extra_fee numeric DEFAULT 0,
    extra_description text,
    vat_fee numeric DEFAULT 0,
    driver_national_code text,
    payment_method text,
    account_id uuid,
    is_sent_to_tax boolean DEFAULT false,
    owner_id uuid,
    driver_name text,
    plate_number text,
    financial_account_id uuid,
    accounting_doc_id uuid,
    member_id uuid,
    nwms_id text,
    nwms_status text DEFAULT 'not_sent'::text
);


ALTER TABLE public.warehouse_exits OWNER TO postgres;

--
-- Name: COLUMN warehouse_exits.accounting_doc_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.warehouse_exits.accounting_doc_id IS 'شماره سند حسابداری صادر شده';


--
-- Name: warehouse_exits_exit_no_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.warehouse_exits ALTER COLUMN exit_no ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.warehouse_exits_exit_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: warehouse_rentals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouse_rentals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    customer_id uuid,
    start_date date NOT NULL,
    monthly_rent numeric DEFAULT 0,
    location_name text,
    rental_type text,
    rental_details jsonb,
    description text,
    billing_cycle text,
    verification_code text,
    contract_file_url text,
    status text DEFAULT 'active'::text,
    created_at timestamp with time zone DEFAULT now(),
    notification_config jsonb DEFAULT '[]'::jsonb,
    last_invoiced_at date,
    end_date date,
    member_id uuid,
    CONSTRAINT warehouse_rentals_status_check CHECK ((status = ANY (ARRAY['active'::text, 'draft'::text, 'terminated'::text, 'expired'::text, 'deleted'::text])))
);


ALTER TABLE public.warehouse_rentals OWNER TO postgres;

--
-- Name: warehouse_settings; Type: TABLE; Schema: public; Owner: union_api
--

CREATE TABLE public.warehouse_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id uuid NOT NULL,
    warehouse_name text,
    warehouse_name_en text,
    phone text,
    fax text,
    mobile text,
    email text,
    website text,
    address text,
    postal_code text,
    economic_code text,
    national_id text,
    registration_no text,
    logo_url text,
    stamp_url text,
    header_text text,
    footer_text text,
    province text,
    city text,
    manager_name text,
    manager_phone text,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    form_settings jsonb
);


ALTER TABLE public.warehouse_settings OWNER TO union_api;

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: postgres
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


ALTER TABLE realtime.messages OWNER TO postgres;

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: postgres
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


ALTER TABLE realtime.schema_migrations OWNER TO postgres;

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: postgres
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


ALTER TABLE realtime.subscription OWNER TO postgres;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: postgres
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: postgres
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


ALTER TABLE storage.buckets OWNER TO postgres;

--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: postgres
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: postgres
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE storage.buckets_analytics OWNER TO postgres;

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: postgres
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.buckets_vectors OWNER TO postgres;

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: postgres
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE storage.migrations OWNER TO postgres;

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: postgres
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    level integer
);


ALTER TABLE storage.objects OWNER TO postgres;

--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: postgres
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: prefixes; Type: TABLE; Schema: storage; Owner: postgres
--

CREATE TABLE storage.prefixes (
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    level integer GENERATED ALWAYS AS (storage.get_level(name)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE storage.prefixes OWNER TO postgres;

--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: postgres
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


ALTER TABLE storage.s3_multipart_uploads OWNER TO postgres;

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: postgres
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.s3_multipart_uploads_parts OWNER TO postgres;

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: postgres
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE storage.vector_indexes OWNER TO postgres;

--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Name: access_audit_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.access_audit_logs_id_seq'::regclass);


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: receipts receipt_no; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipts ALTER COLUMN receipt_no SET DEFAULT nextval('public.receipt_no_seq'::regclass);


--
-- Name: sms_logs id; Type: DEFAULT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.sms_logs ALTER COLUMN id SET DEFAULT nextval('public.sms_logs_id_seq'::regclass);


--
-- Name: tickets ticket_no; Type: DEFAULT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.tickets ALTER COLUMN ticket_no SET DEFAULT nextval('public.tickets_ticket_no_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
07f10513-f029-4ae5-9333-7350bfc9ed86	07f10513-f029-4ae5-9333-7350bfc9ed86	{"sub": "07f10513-f029-4ae5-9333-7350bfc9ed86", "email_verified": false, "phone_verified": false}	phone	2025-12-30 22:15:12.477577+00	2025-12-30 22:15:12.477627+00	2025-12-30 22:15:12.477627+00	8e667fe5-4866-4666-8eb3-471821990140
1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	{"sub": "1706a4e9-5cc4-4141-a2dd-6d2a3db1008b", "email_verified": false, "phone_verified": false}	phone	2025-12-31 10:46:46.063012+00	2025-12-31 10:46:46.063065+00	2025-12-31 10:46:46.063065+00	076ad3b1-9b58-42f5-9407-091d18604fc3
296d96ed-280c-4fd3-b4cf-062c0771d34a	296d96ed-280c-4fd3-b4cf-062c0771d34a	{"sub": "296d96ed-280c-4fd3-b4cf-062c0771d34a", "email_verified": false, "phone_verified": false}	phone	2026-01-04 15:50:45.763493+00	2026-01-04 15:50:45.763561+00	2026-01-04 15:50:45.763561+00	406940ad-31e4-40b3-a8c1-26b3294a7c88
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
fde70522-8bd3-4f88-b339-f532ec8e551f	2025-12-30 22:15:36.454564+00	2025-12-30 22:15:36.454564+00	otp	7c91117d-fda4-4c14-b35a-8ae12f0e8f61
7777d42f-92f1-422e-b7dd-2f09ba86626d	2025-12-30 22:16:24.221422+00	2025-12-30 22:16:24.221422+00	otp	f04c4ecf-0192-4816-8997-fa2c32f87c66
834cca30-5079-4e14-b0fe-7891193a6677	2025-12-30 22:17:12.365879+00	2025-12-30 22:17:12.365879+00	otp	b3a917bd-ac81-4fc9-924c-eb619da4fa03
90e2c199-2f39-4b4c-9efe-2f0901e366a5	2025-12-30 22:21:40.320719+00	2025-12-30 22:21:40.320719+00	otp	c559a475-2a1e-4563-a560-c06e7fef187e
f6be61b6-9d6e-4c67-bbb8-75526ae38fa7	2025-12-31 09:08:18.43271+00	2025-12-31 09:08:18.43271+00	otp	6434ab49-10b1-4c54-8f47-5843a91c97ae
c9de86ee-c5ef-41b9-a350-a103f0027f3c	2025-12-31 09:32:32.97816+00	2025-12-31 09:32:32.97816+00	otp	e7b37d01-44ed-4961-a98d-572853d51430
31c216ba-b123-41bf-94fa-a51e49f3532d	2025-12-31 09:39:36.194078+00	2025-12-31 09:39:36.194078+00	otp	cec48a2e-3d85-4c9a-a16e-831433e80b16
bf086e0f-d817-4c6a-8c11-f701330e83a3	2025-12-31 09:43:24.61846+00	2025-12-31 09:43:24.61846+00	otp	28ac5a26-afd5-4ea6-b417-796095beb045
b3c8e843-ac92-4396-b766-68a8acbd0615	2025-12-31 09:49:02.98539+00	2025-12-31 09:49:02.98539+00	otp	cae40233-8df5-481b-88bd-bc07422819d6
ac99874d-78a2-430f-9501-5800e14de3a9	2025-12-31 10:47:03.591235+00	2025-12-31 10:47:03.591235+00	otp	6b23f741-acf4-4e0f-8e70-f43b0c24848e
504b5209-e07a-417a-ba2e-a54504fe0740	2025-12-31 10:47:31.781832+00	2025-12-31 10:47:31.781832+00	otp	65928b99-986a-43bd-b417-5a2b5f0ec1f1
e63fb8c9-ad95-4643-b108-a58dcbaf56ba	2025-12-31 11:00:31.746997+00	2025-12-31 11:00:31.746997+00	otp	a193fb69-8235-4db2-94c5-189212666bff
13c1c670-11de-4e89-918a-015ff49469f2	2025-12-31 11:40:30.821617+00	2025-12-31 11:40:30.821617+00	otp	c1d15b39-a9e5-4a08-a011-2c2e5ec33618
d8adbcfd-4a2d-45cb-9b16-fdc0f5cc26a4	2025-12-31 11:43:54.623668+00	2025-12-31 11:43:54.623668+00	otp	458b0bca-4a75-4035-b27d-0a260145dbf5
d3e8197a-5338-43f2-960b-b5e7bdfbf682	2025-12-31 11:45:10.687859+00	2025-12-31 11:45:10.687859+00	otp	6866577a-76bd-4ad2-bf54-9dab0f8ae32f
73c5b89d-1b82-44af-b6f8-093d58005f03	2025-12-31 12:03:27.319323+00	2025-12-31 12:03:27.319323+00	otp	e4664baa-12d7-4491-9634-f9483768388f
62d677a8-882e-4f0d-8a07-51eb3e6d67e0	2025-12-31 12:23:08.323968+00	2025-12-31 12:23:08.323968+00	otp	00977e97-b8d2-4aca-8806-06ac5d0cd287
97f3dfe4-f8fc-40b7-bd70-706e175f75b5	2025-12-31 12:32:23.841695+00	2025-12-31 12:32:23.841695+00	otp	936c190b-8842-4979-9a12-63c6d5d68f28
d135a5ab-0619-4d44-b133-9ffa4b3db9f0	2025-12-31 15:53:22.768044+00	2025-12-31 15:53:22.768044+00	otp	c928c49f-01a0-4112-9ffb-91a2d7fdd65d
6c6502e3-9010-43a6-b62f-ce378268576c	2025-12-31 16:08:22.380761+00	2025-12-31 16:08:22.380761+00	otp	5cec11f7-0e18-4c78-a77e-22c97a4f27cf
ac40200c-d170-4d1d-a0c3-43d07bd68f4a	2025-12-31 16:56:18.442339+00	2025-12-31 16:56:18.442339+00	otp	b94e20d0-d555-4012-922e-ea739181b694
4a4a0ce1-c8b7-403d-ac85-63256bb639aa	2025-12-31 17:02:17.511718+00	2025-12-31 17:02:17.511718+00	otp	6755d46d-b793-409f-8362-4edf2fea65f0
02339ac1-e02c-4a4a-b12b-89ddf83924d2	2025-12-31 17:06:34.336038+00	2025-12-31 17:06:34.336038+00	otp	d0b7e992-3a66-47a6-aae0-0724dc1dcc75
452c3ae1-d2ee-40c1-90e1-8b7c23128be6	2025-12-31 17:14:59.051244+00	2025-12-31 17:14:59.051244+00	otp	f1cd986b-3ae8-427d-9c61-dfea32058871
a766038a-e5e6-4c04-971a-85d89ccf1821	2025-12-31 17:23:42.300992+00	2025-12-31 17:23:42.300992+00	otp	3e017725-228a-4464-b85a-73059edf4b50
2f96b5c6-2f61-4536-a3ab-edb74d5bb9ef	2025-12-31 17:24:51.051512+00	2025-12-31 17:24:51.051512+00	otp	39c78506-af8d-4e4d-adf2-5aa84cecd36a
5ec1f934-76b4-42de-9156-1a2b51e215b8	2025-12-31 17:52:09.972453+00	2025-12-31 17:52:09.972453+00	otp	ca3a0754-e403-4728-99ab-272bd2da1bb5
619fce68-c2a1-4880-a198-7517dd6b9fe6	2025-12-31 18:11:16.235671+00	2025-12-31 18:11:16.235671+00	otp	2629e787-a3f1-4380-aaef-b25036e055ae
e5e39ddb-1875-4ea8-8700-5de2b1fe3466	2026-01-01 08:48:22.927816+00	2026-01-01 08:48:22.927816+00	otp	6613885d-673d-4536-84bb-e2081289e171
75503ce1-a6fd-43cd-83ec-96984f808414	2026-01-01 08:55:03.25814+00	2026-01-01 08:55:03.25814+00	otp	45c81073-627d-4a2c-96c8-76fca0cbd881
392edd6b-1bed-4691-98e8-bbe1868ec94c	2026-01-01 09:02:37.365358+00	2026-01-01 09:02:37.365358+00	otp	7e98c2fd-d95d-4547-989d-81584997edb6
ef16e2a6-ec30-4193-91b0-87934691fe1a	2026-01-01 09:19:51.818312+00	2026-01-01 09:19:51.818312+00	otp	4b79a2d7-5db5-49bf-9e94-2fa8812f3881
b4c5d2f6-ec17-4221-a38b-cc93fbbfc5a0	2026-01-01 09:42:51.744642+00	2026-01-01 09:42:51.744642+00	otp	606f57de-27a6-4ae8-ad4a-e97e9e57d3ed
69051615-20f5-4690-91c8-385ccc4ee3ff	2026-01-01 09:46:08.641316+00	2026-01-01 09:46:08.641316+00	otp	143a2d92-ce9d-400b-9514-d1d58406bd8f
aac4c88d-4bac-47a7-85f9-558029e78427	2026-01-01 09:49:19.775626+00	2026-01-01 09:49:19.775626+00	otp	d1f7d8dd-2563-48f3-b3f4-1848b59cf210
463af7cc-9675-4a73-96c8-f6a4ee50b5d5	2026-01-01 10:03:46.156981+00	2026-01-01 10:03:46.156981+00	otp	f409eb3d-01f4-4376-aa54-5f19606c9b6a
f506644e-3e78-409b-8c3d-49f28f3bd5bd	2026-01-01 10:08:21.280365+00	2026-01-01 10:08:21.280365+00	otp	5ecbde60-ad6d-4098-941d-1599eb38c734
06904b8c-9e67-4faf-956a-fce500eef7ce	2026-01-01 15:31:30.778258+00	2026-01-01 15:31:30.778258+00	otp	6ee0d425-39ff-4f8a-9c01-110e40fd0119
3392e24a-1fb5-4cbb-a726-b26920f05b68	2026-01-01 15:38:29.524702+00	2026-01-01 15:38:29.524702+00	otp	23dbebfb-01fe-4f74-9264-3f404310a769
6d05e575-a58a-4b91-96c8-dd270d6b9fa7	2026-01-01 16:20:05.440379+00	2026-01-01 16:20:05.440379+00	otp	0de42ff8-9ff7-474e-bca1-cbcfb9b02996
5ac92a5b-f40e-48c5-8b6c-4323b02739fa	2026-01-01 20:36:02.806942+00	2026-01-01 20:36:02.806942+00	otp	a363c54e-6e06-4a2a-a687-e91db365a6de
a7366eae-4a32-48dc-acdd-406db6242ce3	2026-01-01 21:38:03.751438+00	2026-01-01 21:38:03.751438+00	otp	109c145a-2fb6-4b78-9070-5122c792a589
2d0aebd5-e202-45c1-b63c-c8bd54147412	2026-01-02 09:42:30.736245+00	2026-01-02 09:42:30.736245+00	otp	13b8203f-deef-455a-9e36-b29793be08a0
32571343-7f84-488a-959c-a29e419629d5	2026-01-02 09:55:16.517873+00	2026-01-02 09:55:16.517873+00	otp	bb7998b7-d4f6-4dbd-8bb4-d0a3990f7a00
5fab0870-1723-4b7f-a747-f870ac7028ac	2026-01-02 09:56:55.146509+00	2026-01-02 09:56:55.146509+00	otp	7960739e-25c6-4606-b2e8-7fa45b938ffb
07897902-0938-48f5-be6c-832850fa1bf3	2026-01-03 21:33:28.612448+00	2026-01-03 21:33:28.612448+00	otp	f9bdece8-c908-4b8a-be15-5028f5879345
70025fbd-9c5a-4a56-bddb-71ec82529cce	2026-01-03 22:57:31.700517+00	2026-01-03 22:57:31.700517+00	otp	7f0e579c-df2b-48fb-8392-b6fcadeecfb3
1d86b03c-3104-46c1-80e5-132eff4c188a	2026-01-03 23:09:21.882264+00	2026-01-03 23:09:21.882264+00	otp	b01de517-c919-4621-ba69-c9040cb93657
8688af58-3600-4d8d-a7e1-12c6293e2043	2026-01-04 14:15:04.144916+00	2026-01-04 14:15:04.144916+00	otp	a5872c7c-28aa-4969-b5ea-c9314e1e7280
7e183eef-277a-4245-b34b-ec318699f9d5	2026-01-04 15:20:10.004464+00	2026-01-04 15:20:10.004464+00	otp	551b53c3-e182-4a2c-9129-416f98a577db
b72d4dcf-b6f4-4830-9257-5b4f423dbe87	2026-01-04 15:51:27.420699+00	2026-01-04 15:51:27.420699+00	otp	e3e2d880-d227-4abd-b411-8d3d3a9cde8b
b35ab67c-c6c1-4cf1-b472-cf95d36a4644	2026-01-04 15:58:25.46345+00	2026-01-04 15:58:25.46345+00	otp	c6b0bc86-b32a-4046-b3a3-863a3ad7cc8e
362982bc-0d4c-4f84-8053-e50467870846	2026-01-04 16:24:48.389463+00	2026-01-04 16:24:48.389463+00	otp	55295848-5e4d-470b-8638-d331eb68f8ca
832f0eff-bee6-482c-a077-5d847df6812a	2026-01-04 17:30:59.738778+00	2026-01-04 17:30:59.738778+00	otp	29d41a49-e932-438d-a2bb-19c9147b5b0f
36e8a363-194f-48a0-81dd-ac2b64de8d65	2026-01-05 12:09:08.387833+00	2026-01-05 12:09:08.387833+00	otp	ca922e0f-44be-42f2-9eeb-c864404ba6d5
bf1780c7-f4cc-4871-b9bd-f84bf020b35a	2026-01-05 12:25:10.554119+00	2026-01-05 12:25:10.554119+00	otp	a23f4fdf-2056-4ea0-8c9e-4ccdffde829b
cab72e21-8813-43b5-bbd8-81d4845710dd	2026-01-05 12:38:41.822856+00	2026-01-05 12:38:41.822856+00	otp	6fa0d07c-6033-4c0d-b1c9-4af519cbf6d1
82549379-d7c0-4c7c-9017-fa9a0b5c6ab9	2026-01-05 15:40:02.184071+00	2026-01-05 15:40:02.184071+00	otp	c4279c75-dfe3-4eb7-8d04-0e24a8017585
f3eb1960-6bf1-4209-9f3f-a1dcd91151c1	2026-01-05 19:01:02.44339+00	2026-01-05 19:01:02.44339+00	otp	d9eab26d-5a8b-4e91-b4ff-bc82906ef9b1
dd8f7fd7-5fdd-40e0-8dd4-910cc2209e62	2026-01-05 19:32:24.339354+00	2026-01-05 19:32:24.339354+00	otp	02c2cc24-cab8-48b8-bb47-c00545a46749
93becea2-ea0c-44cc-8eb5-b25e2a4e74c3	2026-01-05 21:59:49.327706+00	2026-01-05 21:59:49.327706+00	otp	9fb61962-eb38-43cd-aa69-81ff312d1b43
fbf6110a-11f0-4bd5-a98c-7b644067da11	2026-01-05 22:15:47.350828+00	2026-01-05 22:15:47.350828+00	otp	9e63b47d-250e-482a-8a2e-fdb43e3fb4a5
1c27fd2d-43c0-4a2e-931c-490f1d080b22	2026-01-05 22:20:17.841706+00	2026-01-05 22:20:17.841706+00	otp	fcc69392-2daf-4038-8671-24e62c7afd41
c4de9d44-530f-4efc-9c65-ca1e44c12ede	2026-01-05 22:23:38.538943+00	2026-01-05 22:23:38.538943+00	otp	d72d06b2-bf16-417b-a089-ce92614f1a04
3d3d978a-90f6-4660-9792-d52f100fef69	2026-01-05 22:33:48.910174+00	2026-01-05 22:33:48.910174+00	otp	e3f3af0c-15df-451d-827e-31b636400445
8f873259-5f7a-45a5-9862-cbccdc407730	2026-01-05 22:50:52.475346+00	2026-01-05 22:50:52.475346+00	otp	a4d97a0b-c663-49e4-921e-6806bd376116
b13cb7e0-df21-4b30-a56a-8359978cd52a	2026-01-05 22:54:12.232882+00	2026-01-05 22:54:12.232882+00	otp	75222d43-e02a-4485-863c-51905cd6889f
0fc68075-a398-4367-a7e8-5c3fde3c3c40	2026-01-05 23:01:40.401524+00	2026-01-05 23:01:40.401524+00	otp	b98af71b-0832-4dbd-b821-a3501f9c964e
c13c5e0a-61fa-40d1-be39-bbe3dea0adb7	2026-01-05 23:05:12.485875+00	2026-01-05 23:05:12.485875+00	otp	e6107930-5183-4d3b-997e-8cbf889ef080
288b6655-ea39-48e5-951c-42a2f52109e6	2026-01-06 21:30:14.644774+00	2026-01-06 21:30:14.644774+00	otp	fff455fa-351b-444b-9259-a746567ce7ff
db1233c6-baba-49ce-a3c3-372e38bc5ad9	2026-01-06 22:40:41.019967+00	2026-01-06 22:40:41.019967+00	otp	7969bd14-9de3-44b8-9024-5c4fee0cf8c1
18c1f72f-a39b-4651-a9b7-0d3eccbfa88a	2026-01-06 22:47:49.873852+00	2026-01-06 22:47:49.873852+00	otp	d8445559-eb66-4101-aef2-6df4b68cd2b3
83d8cb4b-fe66-47ec-894c-155b00ddfe54	2026-01-06 22:55:38.106608+00	2026-01-06 22:55:38.106608+00	otp	35bd2c41-93d6-4b64-b7b0-09d878f5ba3a
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	1	yoeyfxh7bteg	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2025-12-30 22:15:36.42141+00	2025-12-30 22:15:36.42141+00	\N	fde70522-8bd3-4f88-b339-f532ec8e551f
00000000-0000-0000-0000-000000000000	2	mbaqesukjk7s	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2025-12-30 22:16:24.220129+00	2025-12-30 22:16:24.220129+00	\N	7777d42f-92f1-422e-b7dd-2f09ba86626d
00000000-0000-0000-0000-000000000000	3	piv7n7jzczha	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2025-12-30 22:17:12.364668+00	2025-12-30 22:17:12.364668+00	\N	834cca30-5079-4e14-b0fe-7891193a6677
00000000-0000-0000-0000-000000000000	4	cvimsxf3p3bl	07f10513-f029-4ae5-9333-7350bfc9ed86	t	2025-12-30 22:21:40.31764+00	2025-12-31 08:54:14.533961+00	\N	90e2c199-2f39-4b4c-9efe-2f0901e366a5
00000000-0000-0000-0000-000000000000	5	swfpahb7jgsj	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2025-12-31 08:54:14.582529+00	2025-12-31 08:54:14.582529+00	cvimsxf3p3bl	90e2c199-2f39-4b4c-9efe-2f0901e366a5
00000000-0000-0000-0000-000000000000	6	yzr7gjtftym6	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2025-12-31 09:08:18.422919+00	2025-12-31 09:08:18.422919+00	\N	f6be61b6-9d6e-4c67-bbb8-75526ae38fa7
00000000-0000-0000-0000-000000000000	7	pfqxdwld5pv3	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2025-12-31 09:32:32.934351+00	2025-12-31 09:32:32.934351+00	\N	c9de86ee-c5ef-41b9-a350-a103f0027f3c
00000000-0000-0000-0000-000000000000	8	nhvi36ac3q22	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2025-12-31 09:39:36.192178+00	2025-12-31 09:39:36.192178+00	\N	31c216ba-b123-41bf-94fa-a51e49f3532d
00000000-0000-0000-0000-000000000000	9	e7fsfexkiop7	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2025-12-31 09:43:24.599568+00	2025-12-31 09:43:24.599568+00	\N	bf086e0f-d817-4c6a-8c11-f701330e83a3
00000000-0000-0000-0000-000000000000	11	jrxci3zo3znc	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 10:47:03.559659+00	2025-12-31 10:47:03.559659+00	\N	ac99874d-78a2-430f-9501-5800e14de3a9
00000000-0000-0000-0000-000000000000	12	24zf6ea24kun	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 10:47:31.779413+00	2025-12-31 10:47:31.779413+00	\N	504b5209-e07a-417a-ba2e-a54504fe0740
00000000-0000-0000-0000-000000000000	10	roibx2dzl4ef	07f10513-f029-4ae5-9333-7350bfc9ed86	t	2025-12-31 09:49:02.979821+00	2025-12-31 10:47:41.27147+00	\N	b3c8e843-ac92-4396-b766-68a8acbd0615
00000000-0000-0000-0000-000000000000	14	fg57fc4hvn63	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 11:00:31.728182+00	2025-12-31 11:00:31.728182+00	\N	e63fb8c9-ad95-4643-b108-a58dcbaf56ba
00000000-0000-0000-0000-000000000000	15	s52jp4xapm5b	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 11:40:30.805937+00	2025-12-31 11:40:30.805937+00	\N	13c1c670-11de-4e89-918a-015ff49469f2
00000000-0000-0000-0000-000000000000	16	ny374dx3lw6f	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 11:43:54.608585+00	2025-12-31 11:43:54.608585+00	\N	d8adbcfd-4a2d-45cb-9b16-fdc0f5cc26a4
00000000-0000-0000-0000-000000000000	17	d2ukf2nrflcg	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 11:45:10.686669+00	2025-12-31 11:45:10.686669+00	\N	d3e8197a-5338-43f2-960b-b5e7bdfbf682
00000000-0000-0000-0000-000000000000	13	x23gedrrjzee	07f10513-f029-4ae5-9333-7350bfc9ed86	t	2025-12-31 10:47:41.272181+00	2025-12-31 12:02:51.058791+00	roibx2dzl4ef	b3c8e843-ac92-4396-b766-68a8acbd0615
00000000-0000-0000-0000-000000000000	19	henypj7fkygl	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 12:03:27.317941+00	2025-12-31 12:03:27.317941+00	\N	73c5b89d-1b82-44af-b6f8-093d58005f03
00000000-0000-0000-0000-000000000000	20	z2g6ic6zimqm	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 12:23:08.309514+00	2025-12-31 12:23:08.309514+00	\N	62d677a8-882e-4f0d-8a07-51eb3e6d67e0
00000000-0000-0000-0000-000000000000	18	abng372evcps	07f10513-f029-4ae5-9333-7350bfc9ed86	t	2025-12-31 12:02:51.074573+00	2025-12-31 15:51:22.597066+00	x23gedrrjzee	b3c8e843-ac92-4396-b766-68a8acbd0615
00000000-0000-0000-0000-000000000000	22	ohgwcrzekoa3	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2025-12-31 15:51:22.608062+00	2025-12-31 15:51:22.608062+00	abng372evcps	b3c8e843-ac92-4396-b766-68a8acbd0615
00000000-0000-0000-0000-000000000000	21	kvxu24qwr6n3	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2025-12-31 12:32:23.837475+00	2025-12-31 15:51:28.009092+00	\N	97f3dfe4-f8fc-40b7-bd70-706e175f75b5
00000000-0000-0000-0000-000000000000	23	gpjegpggv2m5	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 15:51:28.011765+00	2025-12-31 15:51:28.011765+00	kvxu24qwr6n3	97f3dfe4-f8fc-40b7-bd70-706e175f75b5
00000000-0000-0000-0000-000000000000	24	ykbuz2snkknt	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2025-12-31 15:53:22.756432+00	2025-12-31 16:54:00.056925+00	\N	d135a5ab-0619-4d44-b133-9ffa4b3db9f0
00000000-0000-0000-0000-000000000000	26	w7iw7l6b6ctx	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 16:54:00.091799+00	2025-12-31 16:54:00.091799+00	ykbuz2snkknt	d135a5ab-0619-4d44-b133-9ffa4b3db9f0
00000000-0000-0000-0000-000000000000	27	ng7pmobsvtgp	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 16:56:18.437009+00	2025-12-31 16:56:18.437009+00	\N	ac40200c-d170-4d1d-a0c3-43d07bd68f4a
00000000-0000-0000-0000-000000000000	28	3yzmrhxlu34w	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 17:02:17.508621+00	2025-12-31 17:02:17.508621+00	\N	4a4a0ce1-c8b7-403d-ac85-63256bb639aa
00000000-0000-0000-0000-000000000000	29	264jnb65nlcu	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 17:06:34.323804+00	2025-12-31 17:06:34.323804+00	\N	02339ac1-e02c-4a4a-b12b-89ddf83924d2
00000000-0000-0000-0000-000000000000	30	baywfsur6oel	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 17:14:59.020335+00	2025-12-31 17:14:59.020335+00	\N	452c3ae1-d2ee-40c1-90e1-8b7c23128be6
00000000-0000-0000-0000-000000000000	31	f3dyklkwf4th	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 17:23:42.293497+00	2025-12-31 17:23:42.293497+00	\N	a766038a-e5e6-4c04-971a-85d89ccf1821
00000000-0000-0000-0000-000000000000	32	rcrp6amhto55	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 17:24:51.049135+00	2025-12-31 17:24:51.049135+00	\N	2f96b5c6-2f61-4536-a3ab-edb74d5bb9ef
00000000-0000-0000-0000-000000000000	25	aa6vjxrja63y	07f10513-f029-4ae5-9333-7350bfc9ed86	t	2025-12-31 16:08:22.357346+00	2025-12-31 17:27:43.347172+00	\N	6c6502e3-9010-43a6-b62f-ce378268576c
00000000-0000-0000-0000-000000000000	34	g7wchjzdrmu6	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2025-12-31 17:52:09.941034+00	2025-12-31 17:52:09.941034+00	\N	5ec1f934-76b4-42de-9156-1a2b51e215b8
00000000-0000-0000-0000-000000000000	35	mzwgqn2ol3xx	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2025-12-31 18:11:16.230396+00	2025-12-31 19:09:22.920697+00	\N	619fce68-c2a1-4880-a198-7517dd6b9fe6
00000000-0000-0000-0000-000000000000	36	xmslnmor7ddb	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2025-12-31 19:09:22.966859+00	2025-12-31 20:07:52.984955+00	mzwgqn2ol3xx	619fce68-c2a1-4880-a198-7517dd6b9fe6
00000000-0000-0000-0000-000000000000	37	nrezoni6zy6l	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2025-12-31 20:07:53.030833+00	2025-12-31 21:06:22.921266+00	xmslnmor7ddb	619fce68-c2a1-4880-a198-7517dd6b9fe6
00000000-0000-0000-0000-000000000000	38	ss2pintarhds	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2025-12-31 21:06:22.960951+00	2026-01-01 08:31:19.477328+00	nrezoni6zy6l	619fce68-c2a1-4880-a198-7517dd6b9fe6
00000000-0000-0000-0000-000000000000	39	u6zfkzw7w6ae	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 08:31:19.528547+00	2026-01-01 08:31:19.528547+00	ss2pintarhds	619fce68-c2a1-4880-a198-7517dd6b9fe6
00000000-0000-0000-0000-000000000000	33	zscizbmi4sue	07f10513-f029-4ae5-9333-7350bfc9ed86	t	2025-12-31 17:27:43.352866+00	2026-01-01 08:44:05.832632+00	aa6vjxrja63y	6c6502e3-9010-43a6-b62f-ce378268576c
00000000-0000-0000-0000-000000000000	40	aoehpmadk3oq	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2026-01-01 08:44:05.834586+00	2026-01-01 08:44:05.834586+00	zscizbmi4sue	6c6502e3-9010-43a6-b62f-ce378268576c
00000000-0000-0000-0000-000000000000	41	s37irr6irb32	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 08:48:22.905302+00	2026-01-01 08:48:22.905302+00	\N	e5e39ddb-1875-4ea8-8700-5de2b1fe3466
00000000-0000-0000-0000-000000000000	42	ooafov5vrrvn	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 08:55:03.237759+00	2026-01-01 08:55:03.237759+00	\N	75503ce1-a6fd-43cd-83ec-96984f808414
00000000-0000-0000-0000-000000000000	43	xnpfa2qeqx5v	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 09:02:37.343452+00	2026-01-01 09:02:37.343452+00	\N	392edd6b-1bed-4691-98e8-bbe1868ec94c
00000000-0000-0000-0000-000000000000	44	bzq7ugipsgkv	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 09:19:51.779628+00	2026-01-01 09:19:51.779628+00	\N	ef16e2a6-ec30-4193-91b0-87934691fe1a
00000000-0000-0000-0000-000000000000	45	jdd6h7r5jlgn	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 09:42:51.725668+00	2026-01-01 09:42:51.725668+00	\N	b4c5d2f6-ec17-4221-a38b-cc93fbbfc5a0
00000000-0000-0000-0000-000000000000	46	ovr4rp6snyrc	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 09:46:08.638347+00	2026-01-01 09:46:08.638347+00	\N	69051615-20f5-4690-91c8-385ccc4ee3ff
00000000-0000-0000-0000-000000000000	47	xqpcr6f25ikn	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 09:49:19.772476+00	2026-01-01 09:49:19.772476+00	\N	aac4c88d-4bac-47a7-85f9-558029e78427
00000000-0000-0000-0000-000000000000	48	ydwgptidttp5	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2026-01-01 10:03:46.121175+00	2026-01-01 10:03:46.121175+00	\N	463af7cc-9675-4a73-96c8-f6a4ee50b5d5
00000000-0000-0000-0000-000000000000	49	lxd2pbvkppi2	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-01 10:08:21.277244+00	2026-01-01 15:23:02.019701+00	\N	f506644e-3e78-409b-8c3d-49f28f3bd5bd
00000000-0000-0000-0000-000000000000	50	hnh6ji5wewlj	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 15:23:02.072944+00	2026-01-01 15:23:02.072944+00	lxd2pbvkppi2	f506644e-3e78-409b-8c3d-49f28f3bd5bd
00000000-0000-0000-0000-000000000000	51	fv6vynzi54gt	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 15:31:30.76593+00	2026-01-01 15:31:30.76593+00	\N	06904b8c-9e67-4faf-956a-fce500eef7ce
00000000-0000-0000-0000-000000000000	52	wopqbf7zekil	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 15:38:29.507658+00	2026-01-01 15:38:29.507658+00	\N	3392e24a-1fb5-4cbb-a726-b26920f05b68
00000000-0000-0000-0000-000000000000	53	7v4v5k43yz3i	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-01 16:20:05.413002+00	2026-01-01 20:23:45.280899+00	\N	6d05e575-a58a-4b91-96c8-dd270d6b9fa7
00000000-0000-0000-0000-000000000000	54	56x2dofuqdsx	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 20:23:45.337939+00	2026-01-01 20:23:45.337939+00	7v4v5k43yz3i	6d05e575-a58a-4b91-96c8-dd270d6b9fa7
00000000-0000-0000-0000-000000000000	55	kou4lv47zcx7	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-01 20:36:02.794691+00	2026-01-01 21:35:06.270747+00	\N	5ac92a5b-f40e-48c5-8b6c-4323b02739fa
00000000-0000-0000-0000-000000000000	56	zr47tnngsssr	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-01 21:35:06.312027+00	2026-01-01 21:35:06.312027+00	kou4lv47zcx7	5ac92a5b-f40e-48c5-8b6c-4323b02739fa
00000000-0000-0000-0000-000000000000	57	lmdabcuwbhus	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-01 21:38:03.747386+00	2026-01-02 09:37:29.65734+00	\N	a7366eae-4a32-48dc-acdd-406db6242ce3
00000000-0000-0000-0000-000000000000	58	cvgaxjillb7u	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-02 09:37:29.708423+00	2026-01-02 09:37:29.708423+00	lmdabcuwbhus	a7366eae-4a32-48dc-acdd-406db6242ce3
00000000-0000-0000-0000-000000000000	59	2qcoff4bz7tb	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-02 09:42:30.715079+00	2026-01-02 09:42:30.715079+00	\N	2d0aebd5-e202-45c1-b63c-c8bd54147412
00000000-0000-0000-0000-000000000000	61	6wihn5xwnclj	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-02 09:56:55.14035+00	2026-01-02 10:57:20.350094+00	\N	5fab0870-1723-4b7f-a747-f870ac7028ac
00000000-0000-0000-0000-000000000000	60	33iwqygb25i6	07f10513-f029-4ae5-9333-7350bfc9ed86	t	2026-01-02 09:55:16.511584+00	2026-01-02 11:28:14.405901+00	\N	32571343-7f84-488a-959c-a29e419629d5
00000000-0000-0000-0000-000000000000	62	ntlb4gxhchcm	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-02 10:57:20.368806+00	2026-01-03 09:38:17.465981+00	6wihn5xwnclj	5fab0870-1723-4b7f-a747-f870ac7028ac
00000000-0000-0000-0000-000000000000	64	hvgmrdvl7q2s	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-03 09:38:17.497541+00	2026-01-03 10:47:06.499702+00	ntlb4gxhchcm	5fab0870-1723-4b7f-a747-f870ac7028ac
00000000-0000-0000-0000-000000000000	65	ee7ogakmdjrx	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-03 10:47:06.553632+00	2026-01-03 16:47:28.476235+00	hvgmrdvl7q2s	5fab0870-1723-4b7f-a747-f870ac7028ac
00000000-0000-0000-0000-000000000000	66	xywesqv6ettb	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-03 16:47:28.520256+00	2026-01-03 21:14:44.229662+00	ee7ogakmdjrx	5fab0870-1723-4b7f-a747-f870ac7028ac
00000000-0000-0000-0000-000000000000	67	hs5vtweechhe	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-03 21:14:44.269044+00	2026-01-03 21:14:44.269044+00	xywesqv6ettb	5fab0870-1723-4b7f-a747-f870ac7028ac
00000000-0000-0000-0000-000000000000	68	zdkl27k3ksr4	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-03 21:33:28.602726+00	2026-01-03 22:53:13.983988+00	\N	07897902-0938-48f5-be6c-832850fa1bf3
00000000-0000-0000-0000-000000000000	69	3mb5kzs63dr7	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-03 22:53:14.015832+00	2026-01-03 22:53:14.015832+00	zdkl27k3ksr4	07897902-0938-48f5-be6c-832850fa1bf3
00000000-0000-0000-0000-000000000000	70	ybxz5zrexzhz	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-03 22:57:31.694153+00	2026-01-03 22:57:31.694153+00	\N	70025fbd-9c5a-4a56-bddb-71ec82529cce
00000000-0000-0000-0000-000000000000	63	ipxfhj32pwlp	07f10513-f029-4ae5-9333-7350bfc9ed86	t	2026-01-02 11:28:14.432489+00	2026-01-03 23:07:59.654409+00	33iwqygb25i6	32571343-7f84-488a-959c-a29e419629d5
00000000-0000-0000-0000-000000000000	72	2heqpdekuzfj	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-03 23:09:21.879759+00	2026-01-04 13:46:52.941055+00	\N	1d86b03c-3104-46c1-80e5-132eff4c188a
00000000-0000-0000-0000-000000000000	73	upceot7slzdp	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-04 13:46:52.997323+00	2026-01-04 13:46:52.997323+00	2heqpdekuzfj	1d86b03c-3104-46c1-80e5-132eff4c188a
00000000-0000-0000-0000-000000000000	71	fcjgeokogb3b	07f10513-f029-4ae5-9333-7350bfc9ed86	t	2026-01-03 23:07:59.665428+00	2026-01-04 14:36:47.944141+00	ipxfhj32pwlp	32571343-7f84-488a-959c-a29e419629d5
00000000-0000-0000-0000-000000000000	75	q2qqjbkwgxxy	07f10513-f029-4ae5-9333-7350bfc9ed86	f	2026-01-04 14:36:47.975181+00	2026-01-04 14:36:47.975181+00	fcjgeokogb3b	32571343-7f84-488a-959c-a29e419629d5
00000000-0000-0000-0000-000000000000	74	32w7sslrzedp	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-04 14:15:04.129204+00	2026-01-04 15:14:59.395345+00	\N	8688af58-3600-4d8d-a7e1-12c6293e2043
00000000-0000-0000-0000-000000000000	76	iq7gyby57fgs	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-04 15:14:59.408226+00	2026-01-04 15:14:59.408226+00	32w7sslrzedp	8688af58-3600-4d8d-a7e1-12c6293e2043
00000000-0000-0000-0000-000000000000	77	hut7ripkfymd	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-04 15:20:09.997205+00	2026-01-04 15:20:09.997205+00	\N	7e183eef-277a-4245-b34b-ec318699f9d5
00000000-0000-0000-0000-000000000000	78	jd2yah7lxwbm	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-04 15:51:27.367271+00	2026-01-04 15:51:27.367271+00	\N	b72d4dcf-b6f4-4830-9257-5b4f423dbe87
00000000-0000-0000-0000-000000000000	79	skrtwzch5lo2	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-04 15:58:25.457381+00	2026-01-04 15:58:25.457381+00	\N	b35ab67c-c6c1-4cf1-b472-cf95d36a4644
00000000-0000-0000-0000-000000000000	80	oen72lgv4yrl	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-04 16:24:48.356159+00	2026-01-04 17:29:19.108971+00	\N	362982bc-0d4c-4f84-8053-e50467870846
00000000-0000-0000-0000-000000000000	81	q5cl5ehfemrl	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-04 17:29:19.145599+00	2026-01-04 17:29:19.145599+00	oen72lgv4yrl	362982bc-0d4c-4f84-8053-e50467870846
00000000-0000-0000-0000-000000000000	82	gzrzkf5fyufz	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-04 17:30:59.736362+00	2026-01-05 12:02:48.265093+00	\N	832f0eff-bee6-482c-a077-5d847df6812a
00000000-0000-0000-0000-000000000000	83	mlooufvuwlqy	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-05 12:02:48.316167+00	2026-01-05 12:02:48.316167+00	gzrzkf5fyufz	832f0eff-bee6-482c-a077-5d847df6812a
00000000-0000-0000-0000-000000000000	84	legpr3r7ukzi	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-05 12:09:08.379661+00	2026-01-05 12:09:08.379661+00	\N	36e8a363-194f-48a0-81dd-ac2b64de8d65
00000000-0000-0000-0000-000000000000	85	njiks43y2g7l	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-05 12:25:10.534623+00	2026-01-05 12:25:10.534623+00	\N	bf1780c7-f4cc-4871-b9bd-f84bf020b35a
00000000-0000-0000-0000-000000000000	86	xpbp726lxx4i	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-05 12:38:41.809442+00	2026-01-05 15:37:45.362139+00	\N	cab72e21-8813-43b5-bbd8-81d4845710dd
00000000-0000-0000-0000-000000000000	87	5yasid732dd3	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-05 15:37:45.378948+00	2026-01-05 15:37:45.378948+00	xpbp726lxx4i	cab72e21-8813-43b5-bbd8-81d4845710dd
00000000-0000-0000-0000-000000000000	88	ea3egbhncl5s	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-05 15:40:02.179083+00	2026-01-05 16:40:01.917687+00	\N	82549379-d7c0-4c7c-9017-fa9a0b5c6ab9
00000000-0000-0000-0000-000000000000	89	xjtxycugrlma	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-05 16:40:01.954447+00	2026-01-05 18:59:15.936652+00	ea3egbhncl5s	82549379-d7c0-4c7c-9017-fa9a0b5c6ab9
00000000-0000-0000-0000-000000000000	90	45xv26nzbk4p	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-05 18:59:15.9748+00	2026-01-05 18:59:15.9748+00	xjtxycugrlma	82549379-d7c0-4c7c-9017-fa9a0b5c6ab9
00000000-0000-0000-0000-000000000000	91	4h5yxdnkclzb	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-05 19:01:02.434007+00	2026-01-05 19:01:02.434007+00	\N	f3eb1960-6bf1-4209-9f3f-a1dcd91151c1
00000000-0000-0000-0000-000000000000	92	qqhbemg55cjx	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-05 19:32:24.309514+00	2026-01-05 21:54:33.15134+00	\N	dd8f7fd7-5fdd-40e0-8dd4-910cc2209e62
00000000-0000-0000-0000-000000000000	93	mxbmlcwrnnt2	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-05 21:54:33.194501+00	2026-01-05 21:54:33.194501+00	qqhbemg55cjx	dd8f7fd7-5fdd-40e0-8dd4-910cc2209e62
00000000-0000-0000-0000-000000000000	94	mtmopkhdjytr	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-05 21:59:49.311927+00	2026-01-05 21:59:49.311927+00	\N	93becea2-ea0c-44cc-8eb5-b25e2a4e74c3
00000000-0000-0000-0000-000000000000	95	phhk2kfndaoe	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-05 22:15:47.320399+00	2026-01-05 22:15:47.320399+00	\N	fbf6110a-11f0-4bd5-a98c-7b644067da11
00000000-0000-0000-0000-000000000000	96	5aaw7dg722ih	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-05 22:20:17.794449+00	2026-01-05 22:20:17.794449+00	\N	1c27fd2d-43c0-4a2e-931c-490f1d080b22
00000000-0000-0000-0000-000000000000	97	lphkmmlbfjj7	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-05 22:23:38.531778+00	2026-01-05 22:23:38.531778+00	\N	c4de9d44-530f-4efc-9c65-ca1e44c12ede
00000000-0000-0000-0000-000000000000	98	oftkrqrkbnlf	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-05 22:33:48.901867+00	2026-01-05 22:33:48.901867+00	\N	3d3d978a-90f6-4660-9792-d52f100fef69
00000000-0000-0000-0000-000000000000	99	5wfsufgkx2og	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-05 22:50:52.430731+00	2026-01-05 22:50:52.430731+00	\N	8f873259-5f7a-45a5-9862-cbccdc407730
00000000-0000-0000-0000-000000000000	100	sgwboxivxt7a	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-05 22:54:12.224729+00	2026-01-05 22:54:12.224729+00	\N	b13cb7e0-df21-4b30-a56a-8359978cd52a
00000000-0000-0000-0000-000000000000	101	6rlfsta4ugos	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-05 23:01:40.398435+00	2026-01-05 23:01:40.398435+00	\N	0fc68075-a398-4367-a7e8-5c3fde3c3c40
00000000-0000-0000-0000-000000000000	102	5yfooe6kaawy	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-05 23:05:12.478652+00	2026-01-06 21:28:38.04333+00	\N	c13c5e0a-61fa-40d1-be39-bbe3dea0adb7
00000000-0000-0000-0000-000000000000	103	sswm3dfa2bye	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-06 21:28:38.102542+00	2026-01-06 21:28:38.102542+00	5yfooe6kaawy	c13c5e0a-61fa-40d1-be39-bbe3dea0adb7
00000000-0000-0000-0000-000000000000	104	qjf673w7ef6e	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	t	2026-01-06 21:30:14.636629+00	2026-01-06 22:38:36.348732+00	\N	288b6655-ea39-48e5-951c-42a2f52109e6
00000000-0000-0000-0000-000000000000	105	ud7vfcxnh5uu	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-06 22:38:36.379229+00	2026-01-06 22:38:36.379229+00	qjf673w7ef6e	288b6655-ea39-48e5-951c-42a2f52109e6
00000000-0000-0000-0000-000000000000	106	6aznxkeslkpv	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	f	2026-01-06 22:40:40.95955+00	2026-01-06 22:40:40.95955+00	\N	db1233c6-baba-49ce-a3c3-372e38bc5ad9
00000000-0000-0000-0000-000000000000	107	fqkol7y6ypw7	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-06 22:47:49.863574+00	2026-01-06 22:47:49.863574+00	\N	18c1f72f-a39b-4651-a9b7-0d3eccbfa88a
00000000-0000-0000-0000-000000000000	108	5gnw6xhxxly5	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-06 22:55:38.094198+00	2026-01-07 19:46:26.786734+00	\N	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	109	kbbwtutb5tkx	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-07 19:46:26.83162+00	2026-01-07 22:13:43.121204+00	5gnw6xhxxly5	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	110	lycy4zlc5nnw	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-07 22:13:43.170871+00	2026-01-24 08:04:20.732495+00	kbbwtutb5tkx	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	111	xmljacvxop22	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:04:20.761593+00	2026-01-24 08:04:21.018002+00	lycy4zlc5nnw	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	112	xqbfxtevnjge	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:04:21.0189+00	2026-01-24 08:04:22.461122+00	xmljacvxop22	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	113	ynoosz56avds	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:04:22.461592+00	2026-01-24 08:08:01.160746+00	xqbfxtevnjge	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	114	sy3mtqh3tcge	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:08:01.164682+00	2026-01-24 08:08:04.912518+00	ynoosz56avds	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	115	dlbpmr57nyai	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:08:04.913191+00	2026-01-24 08:08:11.938487+00	sy3mtqh3tcge	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	116	tp6uh3b2hm7b	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:08:11.939215+00	2026-01-24 08:08:35.063988+00	dlbpmr57nyai	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	117	ggimilbohh4g	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:08:35.064724+00	2026-01-24 08:08:37.219608+00	tp6uh3b2hm7b	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	118	wy6zatdd4jda	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:08:37.219983+00	2026-01-24 08:08:39.931327+00	ggimilbohh4g	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	119	q63psizy47yx	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:08:39.931738+00	2026-01-24 08:08:53.543573+00	wy6zatdd4jda	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	120	4logu4etglu2	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:08:53.543921+00	2026-01-24 08:10:00.802517+00	q63psizy47yx	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	121	3cnq5in6t4d5	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:10:00.807668+00	2026-01-24 08:10:03.264486+00	4logu4etglu2	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	122	lryepais2x2l	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:10:03.265174+00	2026-01-24 08:10:10.475357+00	3cnq5in6t4d5	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	123	apdg7q6jfkwc	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:10:10.483812+00	2026-01-24 08:10:23.929722+00	lryepais2x2l	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	124	7w7swlz4vu4w	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:10:23.939223+00	2026-01-24 08:10:48.079285+00	apdg7q6jfkwc	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	125	axoswpyqduhl	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:10:48.081721+00	2026-01-24 08:11:27.69808+00	7w7swlz4vu4w	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	126	nktlrnvabahk	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:11:27.698931+00	2026-01-24 08:12:54.638471+00	axoswpyqduhl	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	127	higle6vnkpgg	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:12:54.640527+00	2026-01-24 08:13:02.725122+00	nktlrnvabahk	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	128	ru7au3ia23ho	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:13:02.725908+00	2026-01-24 08:13:51.377859+00	higle6vnkpgg	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	129	hajzygxbon5r	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:13:51.378535+00	2026-01-24 08:14:00.898908+00	ru7au3ia23ho	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	130	jt6ismyyhni4	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:14:00.899308+00	2026-01-24 08:14:34.509132+00	hajzygxbon5r	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	131	qtxlkdakcc64	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-24 08:14:34.509492+00	2026-01-25 07:33:35.390225+00	jt6ismyyhni4	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	132	6xq2msc3hjbn	296d96ed-280c-4fd3-b4cf-062c0771d34a	t	2026-01-25 07:33:35.440003+00	2026-01-25 14:02:33.006024+00	qtxlkdakcc64	83d8cb4b-fe66-47ec-894c-155b00ddfe54
00000000-0000-0000-0000-000000000000	133	j6xq6q4wlamr	296d96ed-280c-4fd3-b4cf-062c0771d34a	f	2026-01-25 14:02:33.041151+00	2026-01-25 14:02:33.041151+00	6xq2msc3hjbn	83d8cb4b-fe66-47ec-894c-155b00ddfe54
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
fde70522-8bd3-4f88-b339-f532ec8e551f	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-30 22:15:36.396617+00	2025-12-30 22:15:36.396617+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
7777d42f-92f1-422e-b7dd-2f09ba86626d	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-30 22:16:24.218185+00	2025-12-30 22:16:24.218185+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
834cca30-5079-4e14-b0fe-7891193a6677	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-30 22:17:12.363863+00	2025-12-30 22:17:12.363863+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
90e2c199-2f39-4b4c-9efe-2f0901e366a5	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-30 22:21:40.316316+00	2025-12-31 08:54:14.644522+00	\N	aal1	\N	2025-12-31 08:54:14.640307	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
f6be61b6-9d6e-4c67-bbb8-75526ae38fa7	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-31 09:08:18.412998+00	2025-12-31 09:08:18.412998+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
c9de86ee-c5ef-41b9-a350-a103f0027f3c	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-31 09:32:32.910147+00	2025-12-31 09:32:32.910147+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
31c216ba-b123-41bf-94fa-a51e49f3532d	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-31 09:39:36.18871+00	2025-12-31 09:39:36.18871+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
bf086e0f-d817-4c6a-8c11-f701330e83a3	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-31 09:43:24.567426+00	2025-12-31 09:43:24.567426+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
ac99874d-78a2-430f-9501-5800e14de3a9	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 10:47:03.531987+00	2025-12-31 10:47:03.531987+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
504b5209-e07a-417a-ba2e-a54504fe0740	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 10:47:31.778578+00	2025-12-31 10:47:31.778578+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
392edd6b-1bed-4691-98e8-bbe1868ec94c	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 09:02:37.318715+00	2026-01-01 09:02:37.318715+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
e63fb8c9-ad95-4643-b108-a58dcbaf56ba	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 11:00:31.718389+00	2025-12-31 11:00:31.718389+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
13c1c670-11de-4e89-918a-015ff49469f2	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 11:40:30.782735+00	2025-12-31 11:40:30.782735+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
d8adbcfd-4a2d-45cb-9b16-fdc0f5cc26a4	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 11:43:54.596531+00	2025-12-31 11:43:54.596531+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
d3e8197a-5338-43f2-960b-b5e7bdfbf682	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 11:45:10.685835+00	2025-12-31 11:45:10.685835+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
ef16e2a6-ec30-4193-91b0-87934691fe1a	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 09:19:51.752901+00	2026-01-01 09:19:51.752901+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
73c5b89d-1b82-44af-b6f8-093d58005f03	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 12:03:27.312634+00	2025-12-31 12:03:27.312634+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
62d677a8-882e-4f0d-8a07-51eb3e6d67e0	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 12:23:08.299791+00	2025-12-31 12:23:08.299791+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
b3c8e843-ac92-4396-b766-68a8acbd0615	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-31 09:49:02.977475+00	2025-12-31 15:51:22.629011+00	\N	aal1	\N	2025-12-31 15:51:22.628892	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
97f3dfe4-f8fc-40b7-bd70-706e175f75b5	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 12:32:23.836127+00	2025-12-31 15:51:28.026037+00	\N	aal1	\N	2025-12-31 15:51:28.025923	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
d135a5ab-0619-4d44-b133-9ffa4b3db9f0	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 15:53:22.738269+00	2025-12-31 16:54:00.129135+00	\N	aal1	\N	2025-12-31 16:54:00.129024	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
ac40200c-d170-4d1d-a0c3-43d07bd68f4a	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 16:56:18.426277+00	2025-12-31 16:56:18.426277+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
4a4a0ce1-c8b7-403d-ac85-63256bb639aa	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 17:02:17.505184+00	2025-12-31 17:02:17.505184+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
02339ac1-e02c-4a4a-b12b-89ddf83924d2	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 17:06:34.319087+00	2025-12-31 17:06:34.319087+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
452c3ae1-d2ee-40c1-90e1-8b7c23128be6	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 17:14:58.992815+00	2025-12-31 17:14:58.992815+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
a766038a-e5e6-4c04-971a-85d89ccf1821	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 17:23:42.2858+00	2025-12-31 17:23:42.2858+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
2f96b5c6-2f61-4536-a3ab-edb74d5bb9ef	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 17:24:51.044291+00	2025-12-31 17:24:51.044291+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
b4c5d2f6-ec17-4221-a38b-cc93fbbfc5a0	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 09:42:51.710153+00	2026-01-01 09:42:51.710153+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
5ec1f934-76b4-42de-9156-1a2b51e215b8	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 17:52:09.918617+00	2025-12-31 17:52:09.918617+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
69051615-20f5-4690-91c8-385ccc4ee3ff	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 09:46:08.635993+00	2026-01-01 09:46:08.635993+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
619fce68-c2a1-4880-a198-7517dd6b9fe6	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2025-12-31 18:11:16.224402+00	2026-01-01 08:31:19.585692+00	\N	aal1	\N	2026-01-01 08:31:19.583501	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
6c6502e3-9010-43a6-b62f-ce378268576c	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-31 16:08:22.346547+00	2026-01-01 08:44:05.840816+00	\N	aal1	\N	2026-01-01 08:44:05.840718	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
e5e39ddb-1875-4ea8-8700-5de2b1fe3466	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 08:48:22.870471+00	2026-01-01 08:48:22.870471+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
75503ce1-a6fd-43cd-83ec-96984f808414	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 08:55:03.218438+00	2026-01-01 08:55:03.218438+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
aac4c88d-4bac-47a7-85f9-558029e78427	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 09:49:19.763403+00	2026-01-01 09:49:19.763403+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
463af7cc-9675-4a73-96c8-f6a4ee50b5d5	07f10513-f029-4ae5-9333-7350bfc9ed86	2026-01-01 10:03:46.088082+00	2026-01-01 10:03:46.088082+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
f506644e-3e78-409b-8c3d-49f28f3bd5bd	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 10:08:21.274608+00	2026-01-01 15:23:02.123021+00	\N	aal1	\N	2026-01-01 15:23:02.120752	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
06904b8c-9e67-4faf-956a-fce500eef7ce	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 15:31:30.748024+00	2026-01-01 15:31:30.748024+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
3392e24a-1fb5-4cbb-a726-b26920f05b68	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 15:38:29.492358+00	2026-01-01 15:38:29.492358+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
6d05e575-a58a-4b91-96c8-dd270d6b9fa7	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 16:20:05.388962+00	2026-01-01 20:23:45.421066+00	\N	aal1	\N	2026-01-01 20:23:45.418787	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
5ac92a5b-f40e-48c5-8b6c-4323b02739fa	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 20:36:02.784633+00	2026-01-01 21:35:06.362429+00	\N	aal1	\N	2026-01-01 21:35:06.362311	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
a7366eae-4a32-48dc-acdd-406db6242ce3	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-01 21:38:03.740922+00	2026-01-02 09:37:29.767811+00	\N	aal1	\N	2026-01-02 09:37:29.765567	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
2d0aebd5-e202-45c1-b63c-c8bd54147412	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-02 09:42:30.704357+00	2026-01-02 09:42:30.704357+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
cab72e21-8813-43b5-bbd8-81d4845710dd	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-05 12:38:41.789362+00	2026-01-05 15:37:45.397602+00	\N	aal1	\N	2026-01-05 15:37:45.395469	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	213.208.157.36	\N	\N	\N	\N	\N
0fc68075-a398-4367-a7e8-5c3fde3c3c40	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-05 23:01:40.395037+00	2026-01-05 23:01:40.395037+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
82549379-d7c0-4c7c-9017-fa9a0b5c6ab9	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-05 15:40:02.172463+00	2026-01-05 18:59:16.01877+00	\N	aal1	\N	2026-01-05 18:59:16.013384	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
5fab0870-1723-4b7f-a747-f870ac7028ac	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-02 09:56:55.138932+00	2026-01-03 21:14:44.321917+00	\N	aal1	\N	2026-01-03 21:14:44.321751	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
07897902-0938-48f5-be6c-832850fa1bf3	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-03 21:33:28.588481+00	2026-01-03 22:53:14.056599+00	\N	aal1	\N	2026-01-03 22:53:14.055325	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
70025fbd-9c5a-4a56-bddb-71ec82529cce	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-03 22:57:31.687452+00	2026-01-03 22:57:31.687452+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
f3eb1960-6bf1-4209-9f3f-a1dcd91151c1	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-05 19:01:02.418789+00	2026-01-05 19:01:02.418789+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
1d86b03c-3104-46c1-80e5-132eff4c188a	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-03 23:09:21.877506+00	2026-01-04 13:46:53.056373+00	\N	aal1	\N	2026-01-04 13:46:53.056253	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
32571343-7f84-488a-959c-a29e419629d5	07f10513-f029-4ae5-9333-7350bfc9ed86	2026-01-02 09:55:16.500487+00	2026-01-04 14:36:48.005055+00	\N	aal1	\N	2026-01-04 14:36:48.00393	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
8688af58-3600-4d8d-a7e1-12c6293e2043	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-04 14:15:04.110394+00	2026-01-04 15:14:59.432926+00	\N	aal1	\N	2026-01-04 15:14:59.430954	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
7e183eef-277a-4245-b34b-ec318699f9d5	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-04 15:20:09.984872+00	2026-01-04 15:20:09.984872+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
b72d4dcf-b6f4-4830-9257-5b4f423dbe87	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-04 15:51:27.333247+00	2026-01-04 15:51:27.333247+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
b35ab67c-c6c1-4cf1-b472-cf95d36a4644	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-04 15:58:25.452941+00	2026-01-04 15:58:25.452941+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
362982bc-0d4c-4f84-8053-e50467870846	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-04 16:24:48.334949+00	2026-01-04 17:29:19.206647+00	\N	aal1	\N	2026-01-04 17:29:19.200228	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
832f0eff-bee6-482c-a077-5d847df6812a	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-04 17:30:59.724733+00	2026-01-05 12:02:48.367822+00	\N	aal1	\N	2026-01-05 12:02:48.365634	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
36e8a363-194f-48a0-81dd-ac2b64de8d65	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-05 12:09:08.364313+00	2026-01-05 12:09:08.364313+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
bf1780c7-f4cc-4871-b9bd-f84bf020b35a	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-05 12:25:10.509496+00	2026-01-05 12:25:10.509496+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	194.208.64.147	\N	\N	\N	\N	\N
dd8f7fd7-5fdd-40e0-8dd4-910cc2209e62	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-05 19:32:24.294778+00	2026-01-05 21:54:33.248723+00	\N	aal1	\N	2026-01-05 21:54:33.244576	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
93becea2-ea0c-44cc-8eb5-b25e2a4e74c3	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-05 21:59:49.285731+00	2026-01-05 21:59:49.285731+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
fbf6110a-11f0-4bd5-a98c-7b644067da11	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-05 22:15:47.302268+00	2026-01-05 22:15:47.302268+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
1c27fd2d-43c0-4a2e-931c-490f1d080b22	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-05 22:20:17.645102+00	2026-01-05 22:20:17.645102+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
c4de9d44-530f-4efc-9c65-ca1e44c12ede	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-05 22:23:38.52705+00	2026-01-05 22:23:38.52705+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
3d3d978a-90f6-4660-9792-d52f100fef69	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-05 22:33:48.894142+00	2026-01-05 22:33:48.894142+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
8f873259-5f7a-45a5-9862-cbccdc407730	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-05 22:50:52.396866+00	2026-01-05 22:50:52.396866+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
b13cb7e0-df21-4b30-a56a-8359978cd52a	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-05 22:54:12.221202+00	2026-01-05 22:54:12.221202+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
c13c5e0a-61fa-40d1-be39-bbe3dea0adb7	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-05 23:05:12.473008+00	2026-01-06 21:28:38.16304+00	\N	aal1	\N	2026-01-06 21:28:38.162919	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
288b6655-ea39-48e5-951c-42a2f52109e6	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-06 21:30:14.626862+00	2026-01-06 22:38:36.413474+00	\N	aal1	\N	2026-01-06 22:38:36.413368	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
db1233c6-baba-49ce-a3c3-372e38bc5ad9	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	2026-01-06 22:40:40.887604+00	2026-01-06 22:40:40.887604+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
18c1f72f-a39b-4651-a9b7-0d3eccbfa88a	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-06 22:47:49.853103+00	2026-01-06 22:47:49.853103+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	46.140.220.38	\N	\N	\N	\N	\N
83d8cb4b-fe66-47ec-894c-155b00ddfe54	296d96ed-280c-4fd3-b4cf-062c0771d34a	2026-01-06 22:55:38.083278+00	2026-01-25 14:02:33.072457+00	\N	aal1	\N	2026-01-25 14:02:33.072343	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36	45.93.170.19	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: postgres
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	1706a4e9-5cc4-4141-a2dd-6d2a3db1008b	authenticated	authenticated	\N	$2a$10$mRmdouGoFGYI6CgJkK6WWO6yzXuTxWEN.OAFnn0p84TuBYAZ1t7nq	\N	\N		2026-01-06 22:40:26.380943+00		\N			\N	2026-01-06 22:40:40.881825+00	{"provider": "phone", "providers": ["phone"]}	{"sub": "1706a4e9-5cc4-4141-a2dd-6d2a3db1008b", "email_verified": false, "phone_verified": false}	\N	2025-12-31 10:46:45.979917+00	2026-01-06 22:40:41.016389+00	989123338877	2026-01-06 22:40:40.791597+00			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	07f10513-f029-4ae5-9333-7350bfc9ed86	authenticated	authenticated	\N	$2a$10$jEOd.MT/eSC3zAnCbDP/muX7sAwTDzAomhReDWSlw3Jt4qqBysPte	\N	\N		2026-01-02 09:55:06.198025+00		\N			\N	2026-01-02 09:55:16.496542+00	{"provider": "phone", "providers": ["phone"]}	{"sub": "07f10513-f029-4ae5-9333-7350bfc9ed86", "email_verified": false, "phone_verified": false}	\N	2025-12-30 22:15:12.46336+00	2026-01-04 14:36:47.991192+00	989121137675	2026-01-02 09:55:16.484418+00			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	296d96ed-280c-4fd3-b4cf-062c0771d34a	authenticated	authenticated	\N	$2a$10$SolENjf6kJBxfylam5V1nut1MxFsJO2f1RLjk/UC..R5tJVgV0tDG	\N	\N		2026-01-06 22:55:12.997476+00		\N			\N	2026-01-06 22:55:38.080894+00	{"provider": "phone", "providers": ["phone"]}	{"sub": "296d96ed-280c-4fd3-b4cf-062c0771d34a", "email_verified": false, "phone_verified": false}	\N	2026-01-04 15:50:45.524423+00	2026-01-25 14:02:33.057357+00	989123318756	2026-01-06 22:55:38.076221+00			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: access_audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.access_audit_logs (id, member_id, actor_user_id, action, target_type, target_id, payload, created_at) FROM stdin;
\.


--
-- Data for Name: accounting_gl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounting_gl (id, group_id, code, title, created_at) FROM stdin;
730a88f9-7692-ce4c-7e82-6d2cc6d93f61	3e7e91d2-acb1-eada-ce1f-16cabfff9aa8	101	موجودی نقد و بانک	2025-12-20 05:31:51.627516+00
217227ac-2327-838b-0b1d-758bbba01e8a	65b0278b-704d-2e95-65e4-4450376a1b87	102	سرمایه‌گذاری‌های کوتاه‌مدت	2025-12-20 05:31:51.627516+00
3b05e304-a5aa-cacf-2d6a-701f4f707328	3a7e9f44-42f1-bcfa-3f54-932ec31175d2	103	حساب‌ها و اسناد دریافتنی تجاری	2025-12-20 05:31:51.627516+00
ac548a9c-3d64-ea96-23ce-19f899d9587b	6d0bfdb7-9392-55ba-6a40-92cac2aa8446	104	سایر حساب‌های دریافتنی	2025-12-20 05:31:51.627516+00
ffab149a-70aa-0bee-15f8-b95e990484c3	dd2197a0-5d5b-e111-d01c-dd60d29a96ec	105	موجودی مواد و کالا	2025-12-20 05:31:51.627516+00
a7e80a9d-7bb0-b85e-a510-18bfd1ee5ae9	d0f38d9c-55c1-e7b7-2f14-96a9ceeb4bcd	106	پیش‌پرداخت‌ها	2025-12-20 05:31:51.627516+00
4a16332f-a3a1-da6a-b3b9-0da1a85ec077	418fbd2c-d1b5-fc92-a70e-4567b5f0dc07	201	دارایی‌های ثابت مشهود	2025-12-20 05:31:51.627516+00
0e239013-8323-e5da-cc24-ba5b7b13515c	e6ad543a-893d-74ad-a9d8-5940da564a26	301	حساب‌ها و اسناد پرداختنی تجاری	2025-12-20 05:31:51.627516+00
4ae3e967-06f6-e394-b200-4497cc051846	328ce3b0-6e0c-2379-88a1-0a353de435aa	302	سایر حساب‌های پرداختنی	2025-12-20 05:31:51.627516+00
1bf80f4e-6a12-81a6-f58e-fe6778b91ae7	45a6a941-2357-6899-345a-33caed1c10c8	303	پیش‌دریافت‌ها	2025-12-20 05:31:51.627516+00
aee0ef39-367b-d9b4-fae6-6067ee041ff4	18d59e33-af7b-2f16-0c18-4d2d42bb9d32	501	سرمایه	2025-12-20 05:31:51.627516+00
7c6ec69a-5d14-6d61-f358-a8ee3efbb121	74fa47c4-9101-ab8c-bd56-fb2a96b7f9fc	601	درآمدهای عملیاتی	2025-12-20 05:31:51.627516+00
e2a797f9-43bc-334b-c9b9-642de9401faa	927b6a63-34a2-b132-c30d-ef385e926419	602	سایر درآمدها	2025-12-20 05:31:51.627516+00
2d72f2c4-6e3d-9aeb-1c7b-ea0d400ce3b3	2aff731b-18bd-34fe-2501-f654446da440	801	هزینه‌های حقوق و دستمزد	2025-12-20 05:31:51.627516+00
9422a9f2-eb16-9912-902c-fde2c415d560	dde933a6-4240-47cb-97f9-9f3e33ff478e	802	هزینه‌های اداری و عمومی	2025-12-20 05:31:51.627516+00
\.


--
-- Data for Name: accounting_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounting_groups (id, code, title, category, nature, created_at) FROM stdin;
6bbfa2dc-2309-9ba7-ef6b-ec73c59cf89f	1	دارایی‌های جاری	asset	debtor	2025-12-20 05:31:51.627516+00
aff63608-d3d6-2af9-d3d6-78d6f65a6ab2	2	دارایی‌های غیرجاری	asset	debtor	2025-12-20 05:31:51.627516+00
0cd06ce2-4b74-99ec-2261-1fb9337f36c3	3	بدهی‌های جاری	liability	creditor	2025-12-20 05:31:51.627516+00
bc02821f-828d-9185-fb3d-b432effadd5a	4	بدهی‌های بلندمدت	liability	creditor	2025-12-20 05:31:51.627516+00
d0e885e0-d051-1773-4926-c4fe9912a037	5	حقوق صاحبان سهام	equity	creditor	2025-12-20 05:31:51.627516+00
4de5e2ce-dc60-985a-1766-733d2c766075	6	درآمدها	revenue	creditor	2025-12-20 05:31:51.627516+00
020c8a71-aec3-2713-4b6d-d4ca8ef777ac	7	بهای تمام شده	expense	debtor	2025-12-20 05:31:51.627516+00
dd26eb65-9291-4edb-676f-19c6d3400dbc	8	هزینه‌ها	expense	debtor	2025-12-20 05:31:51.627516+00
\.


--
-- Data for Name: accounting_moein; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounting_moein (id, gl_id, code, title, created_at) FROM stdin;
fcad560f-ae49-10bf-48dd-6a865e5f558b	bf1059c4-164a-ca1b-c642-8cc4b75b09d7	10101	صندوق ریالی	2025-12-20 05:31:51.627516+00
ad6c0bc6-4890-0d0d-6eed-9a86cd5a122b	cf42ba39-f0ff-0892-5e17-aa8d7e4a0098	10102	تنخواه‌گردان	2025-12-20 05:31:51.627516+00
26fd8975-3b2a-02c9-e574-7c1cbb871f0b	f89aa22b-8c04-a270-d98e-712c92689e12	10103	بانک‌های ریالی	2025-12-20 05:31:51.627516+00
2b20175e-944b-b5e9-1b8c-aab56bd0b918	724fc2ef-8f6e-33fe-72dc-c51b418809c0	10104	موجودی نزد کارتخوان (POS)	2025-12-20 05:31:51.627516+00
55b25abe-a385-fcea-5f4f-951293860337	f65a039e-b212-3831-ca4c-2f9c78f0fc74	10301	حساب‌های دریافتنی (مشتریان)	2025-12-20 05:31:51.627516+00
7393d9ee-ccb2-cfb4-49e1-d57e65d9d7d5	6db41729-ef5d-4825-f891-7514365f5ee1	10302	اسناد دریافتنی (چک‌ها)	2025-12-20 05:31:51.627516+00
39602702-39c5-1419-7554-3dd448a9db4b	46766ae9-cb9d-f54c-ed91-b5af5acbcf72	30101	حساب‌های پرداختنی (تامین‌کنندگان)	2025-12-20 05:31:51.627516+00
6bbf21a7-f4aa-949f-a0dd-033e50e7dada	3a209126-c72b-7a1c-4aa6-1fbf81440eb9	30201	مالیات بر ارزش افزوده	2025-12-20 05:31:51.627516+00
23d3c0ae-470d-ec89-dafa-3d04816c7d86	fbb3fdbb-4da3-cbd8-dd88-1b694cbe7b0c	30202	بیمه پرداختنی	2025-12-20 05:31:51.627516+00
ad0efd2f-fe61-2f49-688a-aa86b1166f99	b9699612-dc77-63dd-86ae-d37d679a8772	60101	درآمد انبارداری	2025-12-20 05:31:51.627516+00
8da3a452-1d4c-ca83-4fcd-029ed3843231	726d80c3-3467-8bf0-2c52-e1dc7fbd053e	60102	درآمد تخلیه و بارگیری	2025-12-20 05:31:51.627516+00
3845ade2-4ddc-07a2-df80-afba3f93ff5c	f13982e7-a2d2-571c-4adc-3a9ad2d0317e	60103	درآمد باسکول	2025-12-20 05:31:51.627516+00
e7f9461b-61c5-1b99-a7fb-e477ad801de6	dbe0748b-d71a-4a6b-af6a-089a8ad2a101	60104	سایر درآمدهای عملیاتی	2025-12-20 05:31:51.627516+00
38a785fc-c72f-9bbe-b920-19ea08851d77	6e83dfc9-fd08-bcac-7986-5df671171810	80201	هزینه اجاره	2025-12-20 05:31:51.627516+00
2886a128-4170-e687-fe7d-09d42bfe1cbf	ee3941ad-e971-bb9d-af8f-4110854991b7	80202	هزینه آب، برق، گاز	2025-12-20 05:31:51.627516+00
541c161a-083d-333b-f610-a30b65d0c228	67abe503-7d1b-7ba8-138c-bc87d9200a53	80203	هزینه تعمیر و نگهداری	2025-12-20 05:31:51.627516+00
93957e10-210a-112a-c9f0-0e4fab716965	b3385bfb-3f41-2057-768f-c4ce4268c361	80204	هزینه ملزومات و پذیرایی	2025-12-20 05:31:51.627516+00
79e0e5d0-3677-c884-fc76-70b318c5d1f9	0e604080-3563-bd1b-60ba-ff000a0a1268	10303	اسناد در جریان وصول	2025-12-20 09:46:33.72571+00
a06283c9-4300-508e-b8ae-6bbef4c9d159	80de0067-7f89-7a36-e912-588f444de5ac	30102	اسناد پرداختنی	2025-12-20 12:20:47.060569+00
777c53d6-91eb-a86f-578c-264fce2c0e2b	3acb8817-a313-e8e5-5486-7729a59c27c1	80205	هزینه های کارمزد بانک	2025-12-20 12:38:23.211239+00
\.


--
-- Data for Name: accounting_tafsili; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounting_tafsili (id, code, title, tafsili_type, ref_id, is_active, created_at, member_id, updated_at) FROM stdin;
2066491f-8e12-ed70-0499-8c66ba5b0ed3	0002	بانک ملی ایران - 01199287723	bank_account	\N	t	2025-12-20 06:37:50.116643+00	\N	2026-02-02 11:33:00.679813+00
3c3f0715-cf2c-3b00-19c5-2f3c9c4ad03a	0004	بانک ملت - 32423423	bank_account	\N	t	2025-12-20 10:43:13.888146+00	\N	2026-02-02 11:33:00.679813+00
cec95b25-8a2b-42b5-dbaf-0028e1db92e4	0001	صندوق اصلی	cash	\N	t	2025-12-20 10:43:25.183776+00	\N	2026-02-02 11:33:00.679813+00
1ed4503c-d517-d5c3-81ec-eb1d8ac82d8a	0005	ملت	bank_account	\N	t	2025-12-20 10:43:35.598581+00	\N	2026-02-02 11:33:00.679813+00
e1620db2-e093-9b94-dce5-c234dba96d9a	0006	ملی - 0211078009	bank_account	\N	t	2026-01-04 14:15:38.68387+00	\N	2026-02-02 11:33:00.679813+00
40619d3f-ffa1-02f6-52bc-fb8b34fe370e	0002	صندوق بنگاه 	cash	\N	t	2026-01-04 14:19:15.978282+00	\N	2026-02-02 11:33:00.679813+00
801c2b8c-db20-f3f5-cae5-5e27fb05bb78	0001	ملی	pos	\N	t	2026-01-04 14:19:31.564225+00	\N	2026-02-02 11:33:00.679813+00
ec5b82cd-df70-693b-f646-38c004267dd0	0001	افبغفبغف	customer	79f15f1d-5ff4-4549-a7dd-16103cf1dee9	t	2026-01-30 19:17:00.674228+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-02 11:33:00.679813+00
8f2b201f-2b78-8367-25a8-09db09605b5f	0001	صادرات - 878678	bank_account	fa7fcd32-c5f2-b2ed-d466-184bd677dc32	t	2026-01-30 20:56:34.077385+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-02 11:33:00.679813+00
1c6062f3-3853-5e60-7255-b8849fc400bf	0001	786	cash	acf66379-03b0-775c-74df-8297c50bd6fe	t	2026-01-30 20:59:40.377225+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-02 11:33:00.679813+00
17107706-9e3c-be82-df71-ff86ee9cac8e	0001	تندت	pos	ece1042f-a55b-a757-f376-dbc7e79f74ba	t	2026-01-30 20:59:49.376298+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-02 11:33:00.679813+00
da3fc0fe-ce79-dd85-e59f-fb521c8883e1	0002	ملت - 76575675	bank	51a89a63-cd63-def6-48ed-c2126854233a	t	2026-01-30 21:12:35.688326+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-02 11:33:00.679813+00
b3724c7e-e598-1355-b1e5-5803d9fc9cb4	0002	صادرات - 7656756	bank_account	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	t	2026-01-30 21:25:23.512368+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-02 11:33:00.679813+00
fc6c7fec-4f82-e21d-215e-b041990d703d	0002	yugu	cash	104c14e9-a833-1b7e-308f-00808f71e718	t	2026-01-30 21:25:33.572088+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-02 11:33:00.679813+00
e041f769-4ea6-4a91-b246-73f1d8574f9f	0002	محمدی	customer	87a73478-b42b-4e0a-9079-430c290190ae	t	2026-02-01 18:34:28.891482+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-02 11:33:00.679813+00
c0d34ee7-9211-bc5b-9f74-56569d751cee	0003	حسینی 666	customer	d300ce05-8008-4bb0-95f1-2eb231fb4346	t	2026-02-02 08:41:40.595811+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-02 11:39:16.207146+00
005997f3-7a69-42ee-238d-02b92c147c9f	0003	تجارت - 64654564	bank_account	aca210e0-e628-37b1-a65f-ba14926bef53	t	2026-02-07 18:39:02.294597+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-07 18:39:02.294597+00
153810e3-6d65-d46f-f2f5-c775d5430aed	0002	صادرات - 7656756	bank_account	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	t	2026-02-07 18:45:58.909613+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-07 18:45:58.909613+00
5ee414e5-1c66-7ec8-2823-8015d622e1a6	0003	ملت	bank_account	51a89a63-cd63-def6-48ed-c2126854233a	t	2026-02-07 18:45:58.925545+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-07 18:45:58.925545+00
b4d28845-9115-a129-2235-aaf260bb2787	0004	صادرات	bank_account	fa7fcd32-c5f2-b2ed-d466-184bd677dc32	t	2026-02-07 18:45:58.929781+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-07 18:45:58.929781+00
4a50a421-071a-1824-70af-da7d7dbe41b0	0001	yugu	cash	104c14e9-a833-1b7e-308f-00808f71e718	t	2026-02-07 18:45:58.933531+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-07 18:45:58.933531+00
ac3dc153-0995-6893-16b5-7e04baf7f559	0002	786	cash	acf66379-03b0-775c-74df-8297c50bd6fe	t	2026-02-07 18:45:58.93679+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-07 18:45:58.93679+00
db32264d-c759-1996-37f0-fd1800522a54	0005	پاسارگاد - 67564564-98-899	bank_account	cb22769d-a989-3a07-6f13-3e490a7d1945	t	2026-02-07 18:55:28.070603+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-07 18:55:28.070603+00
2ed159ac-23e0-aa64-7ae2-565069027ff3	0002	پوز پاسارگاد	pos	ac04bade-f1d7-3e36-fa0c-f5dab52b4ee6	t	2026-02-07 18:56:04.641674+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-07 18:56:04.641674+00
01f80c12-6740-42d1-0dd7-690e29d1606d	0003	hhh	pos	82fb6891-93be-dd24-1786-b471757c5f06	t	2026-02-16 11:33:51.886382+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-16 11:33:51.886382+00
b180d0ff-f27a-b4bf-7a1c-163b40ce63f0	0004	اکبری	customer	15772138-b50b-4a5f-ab45-523ef0916536	t	2026-02-19 12:08:24.322599+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-19 12:08:24.322599+00
96f5f3e7-3dcf-ff73-7c68-ee54dca70d33	0001	علی رضایی	customer	2db3438c-0865-4cf1-955e-d9197e63061f	t	2026-02-20 18:45:52.042855+00	f04fb725-d8b4-43f1-811d-8267e8761430	2026-02-20 18:45:52.042855+00
e7033a0e-dbc0-e33e-21b9-93484e7a92a1	0001	ملت - 882773663	bank_account	32faf08b-bfc3-b5ea-c940-56137e66d2f4	t	2026-02-21 08:32:20.279708+00	f04fb725-d8b4-43f1-811d-8267e8761430	2026-02-21 08:32:20.279708+00
2cae6253-377a-0faf-b890-7c870d707ba0	0001	صندوق انبار	cash	135c309d-e1cb-7ed3-b243-cac11d095158	t	2026-02-22 06:01:47.469782+00	f04fb725-d8b4-43f1-811d-8267e8761430	2026-02-22 06:01:47.469782+00
f7a0ac06-bb1c-866e-0eba-0b592a64d543	0001	ملت	pos	5d47c395-68a7-7617-aab2-cce31f46aeaa	t	2026-02-22 06:01:59.839512+00	f04fb725-d8b4-43f1-811d-8267e8761430	2026-02-22 06:01:59.839512+00
3544fac7-673e-1adf-6af6-98ff8756303f	0001	آیدین آیدین اعتمادمقدم	customer	c13cefd5-7df3-47a4-80d7-88a6c7a9451c	t	2026-02-23 08:10:30.433463+00	b5021974-30e8-41d3-acec-126d65f18aef	2026-02-23 08:10:30.433463+00
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.activity_logs (id, member_id, user_name, action, entity_type, entity_id, description, ip_address, user_agent, metadata, created_at) FROM stdin;
1	45004958-852d-4b19-9de9-80c1d47e6292	kjbjb	update	settings	fd3760c0-d7ca-45e4-8a8f-53a5a1c454de	بروزرسانی تنظیمات	::ffff:127.0.0.1		{"path": "/api/settings", "method": "POST"}	2026-02-19 12:06:49.633049+00
2	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مدیر سیستم	create	customer	15772138-b50b-4a5f-ab45-523ef0916536	ثبت مشتری جدید	185.11.179.249, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/customers", "method": "POST"}	2026-02-19 12:08:24.354469+00
3	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مدیر سیستم	create	receipt	8f12a96b-f10d-4006-a32f-44a142e243d6	ثبت رسید جدید	185.11.179.249, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/receipts", "method": "POST"}	2026-02-20 09:33:28.145935+00
4	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مدیر سیستم	update	settings	c6f39177-eba0-42ac-847e-5b84b5cac59e	بروزرسانی تنظیمات	185.11.179.249, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/settings", "method": "POST"}	2026-02-20 10:03:36.453352+00
5	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مدیر سیستم	create	receipt	9a5fbd2f-79a0-4f11-a352-b64f5a43514a	ثبت رسید جدید	185.11.179.249, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/receipts", "method": "POST"}	2026-02-20 10:05:39.219802+00
6	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مدیر سیستم	update	settings	c6f39177-eba0-42ac-847e-5b84b5cac59e	بروزرسانی تنظیمات	185.11.179.249, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/settings", "method": "POST"}	2026-02-20 10:19:27.382545+00
7	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مدیر سیستم	create	receipt	e345955f-2c20-485d-aef1-9f6aac413284	ثبت رسید جدید	185.11.179.249, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/receipts", "method": "POST"}	2026-02-20 10:21:06.338913+00
8	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مدیر سیستم	create	receipt	05bf3439-cdfa-43c9-9768-32d1aba46130	ثبت رسید جدید	185.11.179.249, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/receipts", "method": "POST"}	2026-02-20 10:36:24.168308+00
9	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	create	customer	2db3438c-0865-4cf1-955e-d9197e63061f	ثبت مشتری جدید	185.11.179.249, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/customers", "method": "POST"}	2026-02-20 18:45:52.061908+00
10	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مدیر سیستم	update	product	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	ویرایش کالا	185.11.179.249, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/products/4eb1fc4e-c643-2f02-0342-2bcc81cde3b4", "method": "PUT"}	2026-02-20 20:38:23.367896+00
11	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	create	product	55cd5b7a-2898-4588-90b5-c8de22219328	ثبت کالای جدید	185.11.179.249, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/products", "method": "POST"}	2026-02-20 20:54:58.304986+00
12	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	create	receipt	34dd857c-84d8-479f-b997-58b46e9d67e2	ثبت رسید جدید	87.107.143.27, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/receipts", "method": "POST"}	2026-02-21 08:32:43.531532+00
13	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	update	receipt	34dd857c-84d8-479f-b997-58b46e9d67e2	ویرایش رسید	87.107.143.27, 94.101.182.2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/receipts/34dd857c-84d8-479f-b997-58b46e9d67e2", "method": "PUT"}	2026-02-21 08:33:30.668244+00
14	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	update	customer	2db3438c-0865-4cf1-955e-d9197e63061f	ویرایش مشتری	185.11.179.249, 94.101.182.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/customers/2db3438c-0865-4cf1-955e-d9197e63061f", "method": "PUT"}	2026-02-21 19:57:51.23376+00
15	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	create	clearance	\N	ثبت ترخیص جدید	13.201.48.46, 185.215.232.192	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/clearances", "method": "POST"}	2026-02-22 05:57:02.952098+00
16	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	create	loading	0276dcb6-9304-447b-b70c-dcfe4c4691c9	ثبت بارگیری جدید	13.201.48.46, 185.215.232.192	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/loadings", "method": "POST"}	2026-02-22 05:57:44.176173+00
17	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	create	exit	\N	ثبت خروجی جدید	13.201.48.46, 185.215.232.192	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/exits", "method": "POST"}	2026-02-22 06:00:38.67924+00
18	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	create	rental	d57b181c-ecd9-4819-8c6e-da239da0d179	ثبت قرارداد اجاره	13.201.48.46, 185.215.232.192	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/rentals", "method": "POST"}	2026-02-22 06:22:11.702568+00
19	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	update	settings	4265ded9-9a93-4475-8593-e051875bdfdb	بروزرسانی تنظیمات	95.38.99.178, 94.101.182.13	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36	{"path": "/api/settings", "method": "POST"}	2026-02-22 13:54:40.200976+00
20	b5021974-30e8-41d3-acec-126d65f18aef	آیدین اعتماد مقدم	create	customer	c13cefd5-7df3-47a4-80d7-88a6c7a9451c	ثبت مشتری جدید	217.218.48.1, 94.101.182.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36	{"path": "/api/customers", "method": "POST"}	2026-02-23 08:10:30.485397+00
21	b5021974-30e8-41d3-acec-126d65f18aef	آیدین اعتماد مقدم	create	product	fe1bc505-0155-49cb-ab48-3471beddc36c	ثبت کالای جدید	217.218.48.1, 94.101.182.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36	{"path": "/api/products", "method": "POST"}	2026-02-23 08:11:44.235063+00
22	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مدیر سیستم	create	receipt	3f3a9111-12c1-40c4-8450-03de23e03923	ثبت رسید جدید	134.122.122.14, 185.215.232.191	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	{"path": "/api/receipts", "method": "POST"}	2026-02-23 12:14:34.628361+00
\.


--
-- Data for Name: base_banks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.base_banks (id, name, code, created_at) FROM stdin;
2a0c7c20-f058-5ff6-4c25-6f52f8c6e506	بانک ملی ایران	\N	2025-12-20 06:34:26.396459+00
450643a1-23ba-807b-f59c-17225ab3969d	بانک ملت	\N	2025-12-20 06:34:26.396459+00
50aca59a-81d1-7c0f-7d7f-6b31b1869ec6	بانک صادرات	\N	2025-12-20 06:34:26.396459+00
6def4072-7e56-9ea0-6ac0-d3ba1c25acc6	بانک تجارت	\N	2025-12-20 06:34:26.396459+00
8cf7949a-e866-0246-634c-e612bccbdadc	بانک سپه	\N	2025-12-20 06:34:26.396459+00
6dde748f-51b3-faac-8d5c-4c6a06f9d81e	بانک کشاورزی	\N	2025-12-20 06:34:26.396459+00
16c9495c-d304-ddf2-c0a9-a5690a98298d	بانک مسکن	\N	2025-12-20 06:34:26.396459+00
1a5dd55e-45e2-ee42-d067-0006d28d579f	بانک رفاه کارگران	\N	2025-12-20 06:34:26.396459+00
e860ca7d-bcea-ae6e-0147-78d3c1162b80	بانک پاسارگاد	\N	2025-12-20 06:34:26.396459+00
0dc3be08-6fb1-e04b-6176-26e81597cfc8	بانک پارسیان	\N	2025-12-20 06:34:26.396459+00
5a61a86c-5535-4cbb-f993-0982d8f31389	بانک سامان	\N	2025-12-20 06:34:26.396459+00
659235d4-1957-12ed-3f9b-d4078e330d99	بانک اقتصاد نوین	\N	2025-12-20 06:34:26.396459+00
2e14b399-8ca4-f201-a4c4-2f5b2fef3f35	بانک شهر	\N	2025-12-20 06:34:26.396459+00
cccbdb4d-8454-341d-3946-9fc26f61e153	بانک آینده	\N	2025-12-20 06:34:26.396459+00
e5f2bbab-deef-8523-3e2a-edfd24eb35ed	بانک رسالت	\N	2025-12-20 06:34:26.396459+00
cbf49f62-4926-008b-adc5-056c4ffee7cf	بانک دی	\N	2025-12-20 06:34:26.396459+00
acbe4a5c-8243-758a-9c08-49df1f56f321	بانک مهر ایران	\N	2025-12-20 06:34:26.396459+00
fe45cdd8-b218-330c-e84a-38013c5cea1b	بانک گردشگری	\N	2025-12-20 06:34:26.396459+00
dd010643-caaa-7443-b54b-f81c25144454	بانک ایران زمین	\N	2025-12-20 06:34:26.396459+00
716da356-d8aa-3f98-c4d4-93f9880cb5eb	بانک سینا	\N	2025-12-20 06:34:26.396459+00
c7eb9d7d-bd62-c0e5-384e-ed259b2475b4	بانک خاورمیانه	\N	2025-12-20 06:34:26.396459+00
b356d29b-c6c6-c5a7-e775-8eb281129523	پست بانک	\N	2025-12-20 06:34:26.396459+00
\.


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.calendar_events (id, member_id, title, description, event_date, event_time, event_type, category, ref_id, ref_table, color, is_reminder, reminder_date, reminder_time, reminder_method, reminder_sent, is_recurring, recurrence_rule, status, created_by, created_at, updated_at) FROM stdin;
b1d1d0dd-0133-4835-80b3-be1c8c1ccbc1	dc66ad9a-8bc5-4556-9860-aeab96211fa3	دیدار با هادی	\N	2026-02-24	\N	manual	general	\N	\N	#f1b44c	t	\N	\N	native	f	f	\N	active	dc66ad9a-8bc5-4556-9860-aeab96211fa3	2026-02-19 09:41:19.724258+00	2026-02-19 09:41:19.724258+00
\.


--
-- Data for Name: clearance_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clearance_items (id, clearance_id, product_id, owner_id, qty, weight, created_at, updated_at, parent_batch_no, new_batch_no, manual_ref_id, attachment_url, status, description, batch_no) FROM stdin;
87a1f079-5c2a-41ac-91b2-8231e5d43764	62e43a78-7ff7-44b2-87ae-4adbf4ad20ed	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	500	100	2026-02-13 21:21:45.31958+00	2026-02-13 21:21:45.31958+00	بدون ردیف	بدون ردیف		\N	issued		\N
5d98d43c-d8be-41b4-8fbb-9493b4c1e85a	eeb30a8f-fdfb-483b-bc43-cc5e5d487fea	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	2400	6500	2026-02-13 21:23:17.989407+00	2026-02-13 21:23:17.989407+00	بدون ردیف	بدون ردیف		\N	issued		\N
e71e8bb0-4802-4a69-babf-04e4e8e78429	3b1c9b66-1bd1-4678-aecb-997569feff8f	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	2400	100	2026-02-14 07:24:18.711465+00	2026-02-14 07:24:18.711465+00	بدون ردیف	بدون ردیف		\N	issued		\N
7571dadb-dcba-4626-9c77-ffe1815a7618	e4eadb5b-0c90-4478-86d2-feed0dea98b6	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	30	20000	2026-02-15 13:31:51.389505+00	2026-02-15 13:31:51.389505+00	100	100/1		\N	issued		100/1
04ee9849-53a4-43a5-894e-18a8f8094fef	900c8787-5912-4126-94d4-e57644b06cd9	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	4	500	2026-02-15 13:46:56.693238+00	2026-02-15 13:46:56.693238+00	100	100/1		\N	issued		100/1
bd0fbf01-0039-43e4-adb8-f5b9de01e336	abb4c468-1959-49b2-a6d7-683b92e2d34e	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	4	2000	2026-02-16 07:21:53.11082+00	2026-02-16 07:21:53.11082+00	100	100/2		\N	issued		100/2
e53e6ff5-b302-4a6e-b1a7-758e10cfa69b	3aecde6f-bbc6-44bf-a1b3-82df6c8b64ee	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	2	200	2026-02-16 07:22:50.280805+00	2026-02-16 07:22:50.280805+00	100/2	100/2/1		\N	issued		100/2/1
6b2f4ed6-3101-4474-906b-5f156b333703	d85a00bb-2dbd-48a0-8916-0c70c976e929	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	2	1800	2026-02-16 07:43:51.209941+00	2026-02-16 07:43:51.209941+00	100/2	100/2/2		\N	issued		100/2/2
7a25f7a3-cbe0-404f-9144-966fcf7370c9	fb294c39-1050-490d-a5c8-38eb4a0d3146	55cd5b7a-2898-4588-90b5-c8de22219328	2db3438c-0865-4cf1-955e-d9197e63061f	1	2000	2026-02-22 05:57:02.888909+00	2026-02-22 05:57:02.888909+00	110/14	110/14/1		\N	issued		110/14/1
\.


--
-- Data for Name: clearances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clearances (id, doc_type_id, clearance_no, member_id, status, clearance_date, customer_id, receiver_type, receiver_person_name, receiver_person_national_id, receiver_company_name, receiver_company_registration_no, receiver_company_economic_code, driver_name, driver_national_id, driver_phone, vehicle_plate_iran_right, vehicle_plate_mid3, vehicle_plate_letter, vehicle_plate_left2, vehicle_vehicle_type, description, created_at, updated_at, nwms_id, nwms_status) FROM stdin;
62e43a78-7ff7-44b2-87ae-4adbf4ad20ed	72b5831e-f37b-8c8b-c189-2e3538aff23a	10001	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-13	d300ce05-8008-4bb0-95f1-2eb231fb4346	person	hgfffutf		\N	\N	\N		\N	\N					\N		2026-02-13 21:21:45.31958+00	2026-02-16 11:52:00.699943+00	\N	not_sent
eeb30a8f-fdfb-483b-bc43-cc5e5d487fea	72b5831e-f37b-8c8b-c189-2e3538aff23a	10002	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-13	d300ce05-8008-4bb0-95f1-2eb231fb4346	person	xgfgfx		\N	\N	\N		\N	\N					\N		2026-02-13 21:23:17.989407+00	2026-02-16 11:52:00.699943+00	\N	not_sent
3b1c9b66-1bd1-4678-aecb-997569feff8f	72b5831e-f37b-8c8b-c189-2e3538aff23a	10003	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-14	d300ce05-8008-4bb0-95f1-2eb231fb4346	person	mbjb		\N	\N	\N		\N	\N					\N		2026-02-14 07:24:18.711465+00	2026-02-16 11:52:00.699943+00	\N	not_sent
e4eadb5b-0c90-4478-86d2-feed0dea98b6	72b5831e-f37b-8c8b-c189-2e3538aff23a	10004	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-15	d300ce05-8008-4bb0-95f1-2eb231fb4346	person	حسینی		\N	\N	\N	شسسش	\N	\N					\N		2026-02-15 13:31:51.389505+00	2026-02-16 11:52:00.699943+00	\N	not_sent
900c8787-5912-4126-94d4-e57644b06cd9	72b5831e-f37b-8c8b-c189-2e3538aff23a	10005	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-15	d300ce05-8008-4bb0-95f1-2eb231fb4346	person	6654		\N	\N	\N		\N	\N					\N		2026-02-15 13:46:56.693238+00	2026-02-16 11:52:00.699943+00	\N	not_sent
abb4c468-1959-49b2-a6d7-683b92e2d34e	72b5831e-f37b-8c8b-c189-2e3538aff23a	10006	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-16	d300ce05-8008-4bb0-95f1-2eb231fb4346	person	7867ف	7675	\N	\N	\N		\N	\N					\N		2026-02-16 07:21:53.11082+00	2026-02-16 11:52:00.699943+00	\N	not_sent
3aecde6f-bbc6-44bf-a1b3-82df6c8b64ee	72b5831e-f37b-8c8b-c189-2e3538aff23a	10007	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-16	d300ce05-8008-4bb0-95f1-2eb231fb4346	person	75675		\N	\N	\N		\N	\N					\N		2026-02-16 07:22:50.280805+00	2026-02-16 11:52:00.699943+00	\N	not_sent
d85a00bb-2dbd-48a0-8916-0c70c976e929	72b5831e-f37b-8c8b-c189-2e3538aff23a	10008	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-16	d300ce05-8008-4bb0-95f1-2eb231fb4346	person	اترعرا		\N	\N	\N		\N	\N					\N		2026-02-16 07:43:51.209941+00	2026-02-16 11:52:00.699943+00	\N	not_sent
fb294c39-1050-490d-a5c8-38eb4a0d3146	72b5831e-f37b-8c8b-c189-2e3538aff23a	10001	f04fb725-d8b4-43f1-811d-8267e8761430	final	2026-02-22	2db3438c-0865-4cf1-955e-d9197e63061f	person	محمدی		\N	\N	\N		\N	\N					\N		2026-02-22 05:57:02.888909+00	2026-02-22 05:57:02.888909+00	\N	not_sent
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, customer_type, name, national_id, mobile, phone, economic_code, postal_code, birth_or_register_date, address, description, created_at, updated_at, tafsili_id, auth_user_id, member_id, otp_code, otp_expires) FROM stdin;
87a73478-b42b-4e0a-9079-430c290190ae	person	محمدی	64646545645	09889908756	\N	\N	\N	\N	\N	\N	2026-02-01 18:34:28.891482+00	2026-02-02 11:39:38.187361+00	e041f769-4ea6-4a91-b246-73f1d8574f9f	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	\N
d300ce05-8008-4bb0-95f1-2eb231fb4346	person	حسینی 666	\N	09998112342	\N	\N	\N	\N	\N	\N	2026-02-02 08:41:40.595811+00	2026-02-16 07:43:51.130077+00	c0d34ee7-9211-bc5b-9f74-56569d751cee	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	\N
15772138-b50b-4a5f-ab45-523ef0916536	person	اکبری	\N	09345566775	\N	\N	\N	2026-02-19	\N	\N	2026-02-19 12:08:24.322599+00	2026-02-19 12:08:24.322599+00	b180d0ff-f27a-b4bf-7a1c-163b40ce63f0	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	\N
2db3438c-0865-4cf1-955e-d9197e63061f	person	علی رضایی	\N	09203010060	\N	\N	\N	2026-02-20	\N	\N	2026-02-20 18:45:52.042855+00	2026-02-22 05:57:02.275384+00	96f5f3e7-3dcf-ff73-7c68-ee54dca70d33	\N	f04fb725-d8b4-43f1-811d-8267e8761430	\N	\N
c13cefd5-7df3-47a4-80d7-88a6c7a9451c	person	آیدین آیدین اعتمادمقدم	\N	09120618479	\N	\N	\N	2026-02-23	تهران-شورآباد- بعد از پل 60متری شورآباد-اول جاده واوان(یادگار امام)-پلاک 119 - انبار دلتا	\N	2026-02-23 08:10:30.433463+00	2026-02-23 08:10:30.433463+00	3544fac7-673e-1adf-6af6-98ff8756303f	\N	b5021974-30e8-41d3-acec-126d65f18aef	\N	\N
\.


--
-- Data for Name: document_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.document_types (id, code, name, description, is_active, created_at, updated_at) FROM stdin;
22bdf2b7-75c6-2674-8248-96d26a207d63	1	رسید ورود	ورود کالا به انبار	t	2025-12-08 20:11:11.858887+00	2025-12-08 20:11:11.858887+00
6af4a8cd-74e4-82b9-2a57-aed46997f2f6	2	رسید خروج	خروج کالا از انبار	t	2025-12-08 20:11:11.858887+00	2025-12-08 20:11:11.858887+00
2f248449-30da-d7cb-9f96-556acc6be790	3	برگشت	برگشت کالا	t	2025-12-08 20:11:11.858887+00	2025-12-08 20:11:11.858887+00
4d27b284-9845-c4f1-9946-51f5279fd4d2	4	اصلاح موجودی	Adjustment	t	2025-12-08 20:11:11.858887+00	2025-12-08 20:11:11.858887+00
72b5831e-f37b-8c8b-c189-2e3538aff23a	200	ترخیص	سند خروج کالا از انبار	t	2025-12-15 13:16:25.498447+00	2025-12-15 13:16:25.498447+00
\.


--
-- Data for Name: financial_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.financial_documents (id, doc_no, doc_date, manual_no, description, status, doc_type, related_exit_id, created_by, created_at, reference_id, reference_type, member_id) FROM stdin;
4d76c018-71ce-ccdd-195d-ac1dd32c4fde	20046	2026-01-05	\N	بابت خدمات خروج شماره 11004 - تاذتذ	confirmed	auto	cc9ac918-0744-6267-c007-17a3d858bd62	\N	2026-01-05 12:39:51.337263+00	c8b1f661-823a-d1eb-52f4-cbcf4e4f5a03	\N	73979cc3-97cb-96ba-fcc1-91c3b43293ad
9a0266a6-4590-e7dc-b382-1aba48bfb519	3	2025-12-20		دریافت وجه - 	final	manual	cfcd0edb-6972-f026-5bc2-da1a9510474b	\N	2025-12-20 08:12:43.020493+00	37b4d201-8055-7176-5ca8-c095bd1569da	\N	8936cca5-bc81-682b-4997-d92239c42047
c8cf4663-766f-ec96-be15-1fc4ca1b1cb4	4	2025-12-20		دریافت - 	final	manual	c8b8dceb-0f59-223f-facb-830c15dba53e	\N	2025-12-20 10:00:27.10555+00	bb7119a4-dbc6-8ca1-8529-0936d3769129	\N	e1c8fd5e-c465-a232-c7ee-3c4f69d90710
f6640cfd-bc29-440f-7255-e5c7a26f64cf	5	2025-12-20		واگذاری چک 123123	final	manual	ba48bee1-8695-0ff8-6722-8a9630aa39f1	\N	2025-12-20 10:00:48.224071+00	58c92c1c-800c-a93e-8645-b9bf1ccdbec9	\N	9827a695-7be5-69e8-b633-542959128e6b
30d61d17-3fcd-3d15-62e2-4cd041f079f7	6	2025-12-20		وصول چک 123123	final	manual	ce276eef-9431-d3a6-0b76-8b5974dfb838	\N	2025-12-20 10:01:04.113484+00	e7659eed-7493-650b-43c6-d83e638f06e6	\N	16b5792d-4539-3170-fff2-134172550d77
0623012e-7540-3d5c-eb37-9380b29200ae	7	2025-12-20		دریافت - 	final	manual	d8c85fbd-0352-598d-3d60-a2f3e989415b	\N	2025-12-20 10:03:38.009068+00	20e90b67-41be-9b8c-2a29-2e3ee87c00a1	\N	f29c8596-192b-3711-6d8a-23382773ba32
731d2db7-8667-d47f-c2b5-c60de606b275	8	2025-12-20		واگذاری چک 232	final	manual	37373d40-a24d-15b6-095c-066f97d77c6f	\N	2025-12-20 10:03:53.525057+00	d1c45540-debb-b3d9-958b-3cb43406f481	\N	bcb3f07f-6a8b-35da-f640-52dbb5729c58
4d7feb39-2209-cc82-1da4-2e32be500c91	9	2025-12-20		برگشت چک 232	final	manual	46f80701-7771-7709-d0b0-a4dd69b6e49e	\N	2025-12-20 10:04:15.722577+00	8b39e2a3-5bff-aee2-3c49-ecc266253c12	\N	e245a547-897c-a452-1910-dfc738a5cb50
752f2750-9464-443e-3d70-25f1e207fb9a	10	2025-12-20		دریافت - 	final	manual	6f03d1ed-5b30-2ea6-58a8-208714ff8dd9	\N	2025-12-20 10:08:27.359556+00	22c46c0a-b495-1b07-0dd2-6e6e269d6e33	\N	7b4a104b-373f-30b4-7f52-5c6a2a0eba24
89ad74a2-39e9-bd8d-068e-005adf77cc14	11	2025-12-20		پرداخت - 	final	manual	d7106f3b-b165-15e9-e3f9-f085b7930dc2	\N	2025-12-20 10:10:29.290412+00	901d8f05-31ab-ec29-a4b9-f0853cfd96d5	\N	405ee6eb-411b-5961-0e38-46444749824d
9fbec4ba-f9e1-f385-b27f-7c564770dcca	13	2025-12-20		پرداخت - 	final	manual	8ab7dd11-dd43-38c3-4a32-da6ff10060bd	\N	2025-12-20 12:20:53.696585+00	8f988146-651e-fb07-52b7-f061be1d8ef6	\N	90551a95-a3d0-525d-9f70-820233cb49ab
f40817f6-88eb-15a7-d932-e9f221735b51	14	2025-12-20		وصول چک صادره 39285	final	manual	6f978bb4-5f48-7814-c20f-0f245a0d16f5	\N	2025-12-20 12:23:36.235814+00	52b5b4ae-f413-141b-b87d-70f36a804089	\N	335fe2c1-fd60-cc58-c63d-0543694b3698
82b61fb1-df3d-5aea-3858-9fb4b9799a11	15	2025-12-20		وصول چک صادره 39297	final	manual	0c8da41e-5f0a-b2e6-5512-bb7ff2a6e12b	\N	2025-12-20 12:32:18.670523+00	8eedbe7d-fbb9-21cb-144b-923334aa9e4a	\N	147e0a11-3562-db31-11f8-0e9de379f2ed
3a0994e0-f989-d1f6-72cd-d49716471a8c	16	2025-12-20		پرداخت - سی	final	manual	b6245364-f4a7-3d2f-8122-5e2a7249fdde	\N	2025-12-20 12:32:50.419946+00	a05ff442-bf06-bf11-d6d2-a8be7a7e6b66	\N	cdedfede-7a50-f149-b7e8-96c12cf50bff
200dc07b-e0d2-5583-51a8-2e1c2a4b6f75	19	2026-01-07		پرداخت شماره P250001 - sdfsdfsdf	final	manual	b5bdef02-fff8-e1e0-ca09-426e2a2ad87f	\N	2025-12-21 13:46:46.310356+00	0a902920-5ca0-7c1f-53bf-cd3fb772556d	\N	5c43dd64-a5ca-182c-eab9-5ec711b31de4
2b5494cb-c206-bff1-5373-9ce8c54fb21c	20	2025-12-21		پرداخت شماره P250002 - سیب	final	manual	4b467455-10a7-00be-5982-8a6fb1056e74	\N	2025-12-21 13:55:52.641127+00	b820570f-a0a3-1689-a2d2-21c92a0181cf	\N	d83a1ab5-0df1-9aad-f036-b1436a86d0b3
d0368d90-681f-6f5b-707f-40aed37a0418	18	2025-12-20		دریافت شماره D250001 hjh	final	manual	bc1bc4df-44bf-0871-e267-b150db8fbd98	\N	2025-12-20 13:29:58.259935+00	fb8ecb8e-d470-fbde-4e14-d02fab6be340	\N	9ba3aabe-bb12-a97c-1158-bb4bffe223b9
7f295b8d-da18-5d6d-2feb-b453476bb69a	17	2025-12-20		دریافت - hgfy	final	manual	27b7929d-9dd5-9d85-96b6-6272a5e0f57c	\N	2025-12-20 12:33:50.006111+00	7d4cd02e-0831-5068-21a5-971bd20fa5ca	\N	bf3d1b24-8cf4-d7e8-bc94-b588ed672ad9
96ac2b45-b8d7-e3bc-1059-982191d3ecad	22	2025-12-22		هزینه‌های رسید انبار 1006 - راننده: 	final	manual	724f7c6e-6dce-0ea5-1c81-453bc83a46b7	\N	2025-12-22 19:39:55.953229+00	6b1b9d13-1ca0-2977-b53d-ccb286ee5b54	\N	dc69f355-edfa-b6a3-88aa-faf65e3c558b
4d1de928-af66-c67b-0cb7-e30337a115e6	23	2025-12-23		سند اتوماتیک رسید انبار شماره 1008	confirmed	system	3809ddb5-1e9d-54ed-dee7-e881dffee6e7	\N	2025-12-23 11:14:26.968494+00	c2052a83-02aa-15dd-b3d5-6f132002ae76	receipt	ae05d098-7fed-bb8a-bb63-ce5850b4d901
7e69b7a3-5ad4-15c3-d83f-c5a7cb937a13	24	2025-12-23		سند خدمات و هزینه‌های رسید انبار 1009	confirmed	system	df87ecc0-1d48-07d4-40c3-61700b7d04c8	\N	2025-12-23 20:59:44.976852+00	52a65073-d562-7021-c4ee-24310d7a13a2	receipt	b8088b2a-350a-123a-af54-580e377f308d
8f625cff-14e0-6b02-830e-e733a0dce9ae	25	2025-12-24		سند خدمات و هزینه‌های رسید انبار 1015	confirmed	system	cfff5940-a54d-c998-7216-cba01ebe74b9	\N	2025-12-24 15:45:30.711012+00	9014e5b6-f1bf-dff5-06ee-b616560c5c02	receipt	7d79d0a7-5ff7-48fc-4f2e-69429e91d3d7
b1a17487-374f-99d0-5ca5-e04d97afb4f3	26	2025-12-27	\N	سند خروج شماره 38 - راننده: صصصث	final	system	a42e402f-e94b-a6ae-a7b5-84dbbb44e726	\N	2025-12-27 16:19:57.166336+00	4aab726e-e57e-88b1-a251-dcdcc1128cda	\N	398a16ca-124f-ae0a-5fab-2ebb67904d77
ebae65e5-6411-6911-76d3-831911af90cf	27	2025-12-27	\N	سند خروج شماره 39 - راننده: یبس	final	system	c6cfb846-ffdc-49e5-d4cb-e3f854deeb2b	\N	2025-12-27 20:02:09.281889+00	6e7ce10c-647b-68ac-7e85-060d4a469ccc	\N	16965b58-28d1-bc0e-e53e-dc6675691611
560d7188-0d3e-61c4-a08e-9beea7177645	28	2025-12-27	\N	سند خروج شماره 41 - راننده: یسی	final	system	c5f6b66e-b564-33b2-9c2e-c04ef1fba862	\N	2025-12-27 20:50:08.779751+00	786d4ca6-5e5b-c380-b063-fa840839b037	\N	45d58fc4-de7e-308d-24f2-8570c69649dd
68ab6307-ca8c-9274-9243-245345ff77c5	29	2025-12-27	\N	سند خروج شماره 42 - راننده: یسی	final	system	702adbcb-3dcc-dbbc-6a16-c8d303d4eea4	\N	2025-12-27 20:57:52.896537+00	0e674b5a-3e15-8567-da8c-c1418ff2897c	\N	aed9da7d-92b0-7d3e-a702-4220443c00ae
1b26f619-9a6e-3569-aa9e-78178982e3c0	30	2025-12-27	\N	سند خروج شماره 43 - راننده: یسی	final	system	88a00288-c516-66c8-36ff-f9ac80eb363c	\N	2025-12-27 21:00:05.120197+00	fa149a58-b15b-3c30-3094-c0a46d4a1618	\N	938b6e17-8f57-ffd7-55e1-f3fd9f42c6ae
20968f0d-12c8-e6a9-3d8a-0ba048c4a10d	31	2025-12-27	\N	سند خروج شماره 44 - راننده: یسی	final	system	487de968-ddd1-fad7-19a3-0e4cfe0d4153	\N	2025-12-27 21:09:17.353731+00	df51dbd0-0c4e-ae38-8258-a86fae3b18c4	\N	e073b1bc-7419-6a09-0575-9c8a901cfdca
33dfeeb7-55d8-f1c8-ef55-b74c963f7bce	32	2025-12-27	\N	سند خروج شماره 45 - راننده: یسی	final	system	994d2af7-9c0f-06df-d663-07d2373110af	\N	2025-12-27 21:11:22.9459+00	6161c7a7-dd3e-2b37-5b0f-bfab5aa8a94e	\N	00262341-108f-dd55-71b9-a7a8d1d8c50e
54bd4843-3fc3-888f-3e98-14a8123e04e0	33	2025-12-27	\N	سند خروج شماره 46 - راننده: یبس	final	system	e9508bab-e27c-6d41-5da4-57e35b97b380	\N	2025-12-27 21:16:02.148816+00	d457456a-cbbd-0c9f-82e2-d92291a28ccc	\N	a0959b3f-c279-619c-6ac9-262e15b75c62
af493100-2ff0-3c63-fde4-683772d46229	35	2025-12-27	\N	سند خروج شماره 48 - راننده: یسی	final	system	a3484f6d-1bbd-0c8e-c602-ccd842ca9b72	\N	2025-12-27 21:56:07.37021+00	f170129a-51cd-5745-fca7-3b3627fe6ac4	\N	0c537a1d-fc10-8cc6-ad40-f5cd6add88af
73aa38ac-7bec-b953-e3bd-e39d2c0108db	36	2025-12-28	\N	سند خروج شماره 49 - راننده: 	final	system	95dfc643-89f9-77f3-511e-8b12786528d2	\N	2025-12-28 15:31:43.190097+00	e673689c-e2d1-a125-d17d-ba8e2dc65761	\N	4776d04f-f8b3-dea6-d4ed-a065025d2309
02fe03bb-fd36-491f-68a8-39516873c763	37	2025-12-28	\N	سند خروج شماره 50 - راننده: 	final	system	1025380b-180e-161c-3e52-00cb475b131c	\N	2025-12-28 15:44:20.574366+00	2622e77f-4a1d-ae64-2b56-0116d067d20f	\N	c24dd819-879f-9616-bfd2-e9427823cb40
552e4c08-e3b6-67ca-ee89-fe172b815326	38	2025-12-28	\N	سند خروج شماره 51 - راننده: راننده 	final	system	fc68db10-c3e3-71ca-151f-4d1da624991b	\N	2025-12-28 15:59:46.57648+00	8d424ce5-c584-9c57-ce16-c3678a2c8913	\N	9c1d8fc3-c51a-f2c8-bbcd-33f7ea01fec3
4ab58129-a3d2-61d7-ff6e-5bdcd9e8e4b8	39	2025-12-28	\N	خروج کالا شماره 51 - راننده 	final	system	5bdb8489-5d0c-cb2d-4451-c65413129162	\N	2025-12-28 16:07:16.859684+00	9eb0779c-10f0-4403-071f-8c4957596a6f	\N	eb8a02b0-f8cf-8e09-abc8-a4d920417afc
18c6452b-0f0e-2cc8-562a-22bcb0b59f29	40	2025-12-28	\N	خروج کالا شماره 51 - راننده 	final	system	2b4fb065-96d4-d422-c691-bf8ce8d6c498	\N	2025-12-28 16:07:26.283904+00	faf3098b-e578-7893-048c-bf099eb25799	\N	bfb1fada-4389-3244-0ee9-933f655b17ed
27267580-d462-d3ec-6017-cfb4e4a19cf1	41	2025-12-28	\N	خروج کالا شماره 51 - راننده 	final	system	1000f130-dcb5-d247-c273-2e76fa391b0f	\N	2025-12-28 16:07:37.191541+00	68a93760-135b-e262-f4f1-724ab4ea9e1b	\N	7a0e02fc-bdad-560d-455b-4febf71b6359
5a2c4dd8-4625-a61e-d269-7e0f265f4c38	42	2025-12-28	\N	خروج کالا شماره 51 - راننده 	final	system	31139475-9a53-dd5d-b438-093d9fa48fd3	\N	2025-12-28 16:07:44.890568+00	589c58ac-9d47-00ee-234a-568078e57354	\N	0c465758-b045-acae-23c3-73d33a9e2811
3ed21e2d-4e2f-0412-1c4d-5eb98bd12dd6	43	2025-12-28	\N	سند خروج شماره 52 - راننده: تالعرعغر	final	system	43e86dd2-b717-32c4-d256-8f830c66dffe	\N	2025-12-28 16:20:15.12193+00	b657fec5-b0b7-7519-0b26-ac127aa4bae7	\N	d8975d33-3660-8063-9ef3-244ecbe111ff
36ec27c5-7ad5-2358-a9c2-87966b9bf635	44	2025-12-28	\N	سند خروج شماره 53 - راننده: راننده	final	system	f90b1cc3-75ba-eba0-881f-3a7147aede3c	\N	2025-12-28 19:47:09.822811+00	4013c8ff-c162-e0c0-4e13-93f75922e95e	\N	83d9d2e8-c04a-c45d-c38c-629f0a071f4e
e3834b07-649f-dc12-3d84-1a072ee71f47	45	2025-12-27	\N	سند خروج 47	final	system	efc6b26a-e777-3996-7628-670fc56b2c04	\N	2025-12-28 19:52:51.29236+00	f65e9d82-a592-e6e2-dc99-b8ed26caaf73	\N	754c649c-aab4-c416-6a8d-3204e847a387
83911473-9e62-f1f5-f1ff-4733974ff263	46	2025-12-28	\N	سند خروج شماره 57	confirmed	system	ffc3aa3b-a9a1-bdba-f1fd-f9909da736b1	\N	2025-12-28 21:40:43.277362+00	d634a56a-5335-a62f-ea6d-f61a7c95b0ba	warehouse_exit	96c3634d-b179-2539-de76-eb439d04a946
1cfefec2-178a-2981-fdb6-2471e99028bf	47	2025-12-30	\N	تسویه حساب قرارداد انبار (خاتمه در ۱۴۰۴/۱۰/۰۹)	confirmed	system	a091fd09-3e2a-73f7-1c27-e915aeeb353c	\N	2025-12-30 19:39:18.810094+00	6f888cee-5d7a-3d6f-086c-e16d884b5d2b	\N	c8b013ad-380e-fa38-ee25-55e53c7864e5
27d84520-56af-5cee-6ed7-6dc1adc507c6	48	2025-12-30	\N	تسویه حساب قرارداد (خاتمه در ۱۴۰۴/۱۰/۰۹)	confirmed	system	d4dcbcc9-3a1b-bc68-15b2-8b2a7423d39c	\N	2025-12-30 20:12:00.407923+00	9d20403b-1b71-6fcf-5712-26ad2769be0c	\N	171d9748-e455-fcac-8037-16e04f02e49c
1baa7c84-e480-a6cc-ae06-73200e1b297a	49	2026-01-03		سند خدمات و هزینه‌های رسید انبار 2102	confirmed	system	8463fb5a-a86d-f833-cfcf-38cb0d05eb81	\N	2026-01-03 09:40:38.868906+00	2f00d9e9-ecb3-ddd8-a53a-199761568086	receipt	57f8a1bc-4958-de95-ce6c-e210a14d0a95
36feb7fb-94a5-c7a3-5d23-c51ce63b45ec	50	2026-01-03		سند خدمات و هزینه‌های رسید انبار 2103	confirmed	system	f26f3b5a-48c9-5a9f-6ce4-80afb472358d	\N	2026-01-03 22:59:53.047688+00	45319100-d6d9-a387-d0ec-c110ac9eb174	receipt	fe2cff35-4885-aba9-1569-61bba486eb76
298fc944-d979-40cd-bc99-3323b2bddc2e	53	2026-02-01	\N	\N	confirmed	system	\N	\N	2026-02-01 19:46:52.900571+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
da51ea09-15b4-47a4-9cfb-0cd234e3ab9c	54	2026-02-07	\N	سند خودکار رسید شماره 1014	confirmed	auto_receipt	\N	\N	2026-02-07 10:51:48.665069+00	953c17ac-6674-4b37-a916-204f37e58b0a	receipt	dc66ad9a-8bc5-4556-9860-aeab96211fa3
32a038bd-4857-44ca-851d-8d7db115dcf5	56	2026-02-07	\N	پرداخت توسط انبار بابت رسید 1016 (انبارداری، بارگیری، تخلیه، کرایه حمل، مالیات، سایر)	confirmed	auto_receipt	\N	\N	2026-02-07 11:38:51.46177+00	244cc114-fe74-41df-ae16-1d6dd8e6bf37	receipt	dc66ad9a-8bc5-4556-9860-aeab96211fa3
c0016b7e-4526-4f40-9c02-83affabee146	57	2026-02-07	\N	پرداخت توسط انبار بابت رسید 1017 (انبارداری، بارگیری، تخلیه، کرایه حمل، مالیات، سایر)	confirmed	auto_receipt	\N	\N	2026-02-07 12:47:52.125367+00	b5f1409a-7275-401d-8d06-36dfa0e3a924	receipt	dc66ad9a-8bc5-4556-9860-aeab96211fa3
6257e7dd-c345-492c-b123-a630821c3c7f	58	2026-02-07	\N	پرداخت توسط انبار بابت رسید 1018 (انبارداری، بارگیری، تخلیه، کرایه حمل، مالیات، سایر)	confirmed	auto_receipt	\N	\N	2026-02-07 18:26:48.188699+00	d21b45bc-c54f-4849-bfaa-699892a3c828	receipt	dc66ad9a-8bc5-4556-9860-aeab96211fa3
0a37b376-522f-41c9-b06e-805afbd77552	59	2026-02-07	\N	پرداخت توسط انبار بابت رسید 1019 (انبارداری، بارگیری، تخلیه، کرایه حمل، مالیات، سایر)	confirmed	auto_receipt	\N	\N	2026-02-07 18:33:50.957934+00	d3902200-1b65-4dd8-a2e0-c2a177264009	receipt	dc66ad9a-8bc5-4556-9860-aeab96211fa3
a47bc809-ea9b-4f76-a025-21135394c0e3	60	2026-02-16	\N	بابت خدمات خروج شماره 9001 - راننده	confirmed	auto	\N	\N	2026-02-16 11:51:22.872622+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
0dd10ad6-dece-4790-b9cd-af2a0bf0c6dc	61	2026-02-16	\N	پرداخت پسکرایه	confirmed	treasury	\N	\N	2026-02-16 12:57:40.207619+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
69a1b217-ce41-41af-8729-7bd07d6bd68a	62	2026-02-16	\N	لابالز	confirmed	treasury	\N	\N	2026-02-16 13:02:45.782584+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
72238009-aa6b-4094-8a8c-54c592e8afac	63	2026-02-18	\N	پرداخت وجه - محمدی	confirmed	treasury	\N	\N	2026-02-18 21:55:37.804336+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
e1d2368e-a907-499b-ab63-e1b2fd8b0923	64	2026-02-19	\N	پرداخت وجه - محمدی	confirmed	treasury	\N	\N	2026-02-19 06:47:29.771927+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
4e370683-c6c3-4c73-9a60-adb587a503e7	65	2026-02-19	\N	پرداخت وجه از/به حسینی 666 - جمع: ۳۰٬۰۲۰٬۰۰۰ ریال - صدور چک 12 - ۳۰٬۰۲۰٬۰۰۰ ریال	confirmed	treasury	\N	\N	2026-02-19 06:56:00.030543+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
fdf0f592-fcc1-410d-9218-6dfea16a806d	66	2026-02-19	\N	برگشت چک شماره 12 پرداختنی - بستانکار: دریافت‌کننده - مبلغ ۶۰٬۰۰۰٬۰۰۰ ریال	confirmed	cheque_bounce	\N	\N	2026-02-19 07:13:28.551738+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
bb76ff27-9cec-49a4-aff2-e295d4bff042	67	2026-02-19	\N	پاس شدن چک شماره 12 - برداشت از بانک صادرات - مبلغ ۳۰٬۰۲۰٬۰۰۰ ریال	confirmed	cheque_pass	\N	\N	2026-02-19 07:20:02.220774+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
9a7d1e3e-0c6d-4ead-97a7-7a3b5cedd9ba	68	2026-02-19	\N	دریافت وجه از/به حسینی 666 - جمع: ۴۵٬۰۰۰٬۰۰۰ ریال - چک 654646 - ۴۵٬۰۰۰٬۰۰۰ ریال	confirmed	treasury	\N	\N	2026-02-19 07:29:20.259807+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
f6c314fc-e606-4ce7-80f8-d56aee7fa82f	69	2026-02-19	\N	خرج چک شماره 654646 به محمدی - مبلغ ۴۵٬۰۰۰٬۰۰۰ ریال	confirmed	cheque_spend	\N	\N	2026-02-19 07:57:58.514213+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
ef4cb366-79d3-444d-877e-a1891bd3a013	70	2026-02-20	\N	پرداخت توسط انبار بابت رسید 1027 (کرایه حمل، کرایه برگشت)	confirmed	auto_receipt	\N	\N	2026-02-20 10:05:39.142553+00	9a5fbd2f-79a0-4f11-a352-b64f5a43514a	receipt	dc66ad9a-8bc5-4556-9860-aeab96211fa3
c296e97b-6e62-48bc-b965-32358452c63f	71	2026-02-20	\N	پرداخت توسط انبار بابت رسید 1028 (کرایه برگشت)	confirmed	auto_receipt	\N	\N	2026-02-20 10:21:06.263245+00	e345955f-2c20-485d-aef1-9f6aac413284	receipt	dc66ad9a-8bc5-4556-9860-aeab96211fa3
f1307de3-3cfc-4b2b-af7e-4e507603acd9	72	2026-02-20	\N	پرداخت توسط انبار بابت رسید 1029 (کرایه برگشت)	confirmed	auto_receipt	\N	\N	2026-02-20 10:36:24.109847+00	05bf3439-cdfa-43c9-9768-32d1aba46130	receipt	dc66ad9a-8bc5-4556-9860-aeab96211fa3
a28700df-c2b4-4714-b58f-ccb68e264f79	1	2026-02-21	\N	پرداخت توسط انبار بابت رسید 1030 (پسکرایه)	confirmed	auto_receipt	\N	\N	2026-02-21 08:33:30.622052+00	34dd857c-84d8-479f-b997-58b46e9d67e2	receipt	f04fb725-d8b4-43f1-811d-8267e8761430
c927574d-7476-4494-a301-1d2e3ee7f8b0	2	2026-02-22	\N	بابت خدمات خروج شماره 9001 - حسینی	confirmed	auto	\N	\N	2026-02-22 06:00:39.872166+00	\N	\N	f04fb725-d8b4-43f1-811d-8267e8761430
2c05d18c-f848-491b-b605-1643cf3aaeab	73	2026-02-23	\N	پرداخت توسط انبار بابت رسید 1030 (تخلیه، پسکرایه)	confirmed	auto_receipt	\N	\N	2026-02-23 12:14:34.546331+00	3f3a9111-12c1-40c4-8450-03de23e03923	receipt	dc66ad9a-8bc5-4556-9860-aeab96211fa3
\.


--
-- Data for Name: financial_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.financial_entries (id, doc_id, moein_id, tafsili_id, bed, bes, description, created_at, moin_id, member_id) FROM stdin;
75d26a31-e3da-c3f7-e090-cf4f78925481	cfae99a1-2009-e638-325b-8e7a00e71808	181f9b0c-a36e-62fa-02ea-ec8609e92176	ba91c962-39ed-24db-eb08-5e208b6799aa	200000	0	فیش/حواله - 	2025-12-20 08:12:43.545335+00	d72397c5-c30b-fb2e-9418-c17628c42dc1	d6941afb-9e0e-29b5-751b-a8cb7816c38f
346784f4-eaf3-a6be-f101-36f038113b32	2c5efd70-ae84-e4b9-2f3d-74f490a6fbdf	6516f70d-2eff-460d-c088-5988c2ec6e51	7b896b32-d6f5-8a42-b885-f3cfdbabf291	50000	0	فیش/حواله - 	2025-12-20 08:12:43.545335+00	c9d6c06a-50de-cc15-f8bc-78421d66880b	245261f6-475c-a24e-e6c4-050572016654
77f94f42-9fba-289f-e91e-6e59f2318934	cc7ea0fe-2f12-f042-749a-0af821235cde	59978f7d-b5c8-5388-b959-bbf4502eb547	7f70404f-71b9-8942-c7ce-adca06a80b8a	7000000	0	فیش/حواله - 	2025-12-20 08:12:43.545335+00	ea980538-7429-d1f9-5f86-7b1d1565dfba	4b1159ad-34dc-a63f-bfc9-bce7ee214135
5c1699f3-0149-9260-ac39-984e41e34760	d9e3979f-23f1-6909-3878-758cafa58ded	dc3706b1-e853-bdc6-3260-1db8c9f6fb8f	26d9e28f-0f1d-cac0-8a1b-2e6cbc01642e	23000000	0	چک صیادی 123123123 - بانک ملت	2025-12-20 10:00:27.597873+00	7f63e444-91de-14b9-7818-521d8cdeb804	76389d2d-5ef1-92b5-2484-1e257b1a8aa0
ccb211f9-d0c9-174d-16fd-bc36e91f3762	c99cedbd-983f-7ca6-4eea-cdaae71442cc	bbb69de2-aaef-714b-db49-ef8d6d4e88b8	6b86c9e4-dd9a-d397-91d1-e88dd7a15733	0	23000000	خروج چک 123123 جهت واگذاری	2025-12-20 10:00:48.685238+00	6b959eed-e33e-539d-38dc-4e554b79954d	b401123c-ce42-3870-154d-9f9af6af125c
d39ba3c2-0ec0-07c6-e74d-fad3780e53a6	fa203265-acea-71b7-d020-c87275de9bb9	1066c1a6-12bd-8988-f3f2-8ee7eed9242f	cb9aa547-ed44-9bd7-1408-7913da2e8c51	23000000	0	واگذاری به بانک بانک ملی ایران	2025-12-20 10:00:48.685238+00	861ecb40-f51e-4704-b326-0fed175a4750	56e1aa3d-fa7a-e1a6-772b-0d0d4a3933f0
d31ec7b5-e2eb-55c4-891c-cd9dd6f741ba	3c248bbe-03e0-4d29-0194-02bd801a8665	3c69e2d6-5ac1-83c1-0044-1cf287cf9c59	35befa69-365d-4774-a3ad-653d864dc984	0	23000000	وصول چک 123123	2025-12-20 10:01:04.572417+00	a25f3920-c77e-d17a-202f-e9d65e6a15e4	c6e22085-399e-5b4a-28c5-9ffa91670f2b
0f3b56d1-8239-3d85-b24b-3e46d0298c07	a6232c3e-60a6-f5f5-bdb6-48371ccf1c2c	4c43c191-b993-48f4-ae7c-8c110bbd5ef4	74c6aab8-3729-64c8-f79c-4d52975b6100	23000000	0	واریز وجه چک به حساب	2025-12-20 10:01:04.572417+00	2ec68af7-d060-7c55-9067-16b27cee9abe	8b0e110b-5bf7-5f40-521f-8a9a5072e045
1cff8af2-2267-22d8-f49d-6a56e56ea9c7	5eeb17d9-d7ad-12cf-5feb-cccf140e1870	490f87f2-2833-ce2e-3bd8-0dbb61520201	d97103ca-b421-03e1-dfd2-7638ea8f946d	40000000	0	چک صیادی 2312 - بانک صادرات	2025-12-20 10:03:38.283266+00	95206ac5-8d83-6acd-282b-54054d6731d3	179c4920-80f3-8e33-33be-f7b8a8c08f16
48cd7e53-aa62-d76a-93ab-5d83b870b285	3619cd6f-dc04-6e47-3a69-43ba4a5cc27d	f3912d43-3296-31f7-5e28-29caf07783d3	7f8ba2c7-460f-959e-1516-e0dc86d3a64b	0	40000000	خروج چک 232 جهت واگذاری	2025-12-20 10:03:53.790139+00	a0c6ce2a-6ac1-ebb9-414f-442bb3dd9cce	06015ffa-3bfd-0a6f-8f31-43887a0ccda8
098ece2d-7169-6008-85bf-3272a07c0a73	0bd2a01e-b22d-f47d-32d7-4c4f747f2f4b	65d91c1d-f140-ec7c-f72e-1cf8fda67f7a	20fc070b-6b57-5975-1f47-f85395f6720e	40000000	0	واگذاری به بانک بانک ملی ایران	2025-12-20 10:03:53.790139+00	1718ca94-0b15-07f7-eded-8bc000089453	0fdc460a-ba76-b14b-fa42-947ed4810fe2
a73b120d-6782-5fe0-805a-829f78a4332a	4d3b28ab-3e9b-89be-c165-b9f7a2b0a633	479e10a6-bd85-756d-7aec-ff68b1329b5f	1315dfa8-9fc7-c124-1791-0edcaf59e17c	0	40000000	برگشت چک 232	2025-12-20 10:04:15.99366+00	2e469b0f-b2a2-7825-81ea-86d3a139742a	824cf939-4ce0-5eda-2d34-75e865dbce85
c83b4c6a-c539-9880-ec97-0de0f32ecf83	72f91dca-f2da-c5f2-2de8-807375a28574	657ecd03-593b-55a9-d79d-1dc602907c58	611f40cf-00c5-c563-3d75-44c817e1d821	23000000	0	چک صیادی 123123 - بانک ملت	2025-12-20 10:08:27.635667+00	e505e721-8f5f-3f6c-61d6-e2747c2c6117	61b978b1-18a8-b0fc-6d18-2023cdf665a3
916a5efc-9544-4531-5ac9-e5142bf6a86e	3e485916-bd0b-c03d-596d-998cdb722666	b78578be-9ed2-bc6e-c23d-b97e4b9b1b63	597efd65-bf75-ed1c-10a3-2416abef42e9	0	238482322	فیش/حواله - 	2025-12-20 10:10:29.562576+00	84821a40-cb50-f698-bf77-31b931bc6796	c9ce5071-ced7-7c94-1f5c-f408386ed338
b2df2f5a-1938-5102-fa87-f47219b26008	6977e2bf-483d-7585-fe36-be1e73d4baa8	cb936ef5-9ed9-764a-549c-802f5611369b	6379335b-e396-b491-cfcb-f8e5cd9786ac	0	12000000	صدور چک 39285 - بانک ملی ایران - سررسید 2025-12-14	2025-12-20 12:20:54.17504+00	f2bec91b-d837-8f20-2596-4369da33f6de	db98450b-377f-4322-d0f7-28082028ed07
c4cf106e-e10d-513f-1a38-b6c2d7e24a59	95b01651-7617-052f-ac85-96e5e6cbfe0a	d0db3211-fca6-770f-8acd-76a41f73f418	ce388d91-6b4c-9b56-2bd9-69381a0d41e3	0	12000000	پاس شدن چک صادره 39285	2025-12-20 12:23:36.37846+00	b9fa582e-bbf8-0182-b12b-137d8a418851	157fbaf5-c048-ff07-e60c-b22605c5adb7
ad2c8939-ff8d-369b-5368-e349c30cfbd0	3d5b00ec-687f-af05-c665-d272d389de05	75779523-6461-2fd7-e6b7-47d3f9f37319	1e175641-81b5-c1ab-0f82-a3645df3863e	12000000	0	وصول اسناد پرداختنی	2025-12-20 12:23:36.37846+00	c2f0976a-b637-c2c9-4dd7-3926297c905b	f3b72bd6-eaaf-8f6d-84d1-884a823b5142
a8d5a1eb-476b-ecfc-0fa4-596d8fa0434a	bd709120-1258-bdaf-2859-e7b5f7dc6e08	61735983-bba0-531c-0b20-0551ea9bbfce	c67b1313-0e5f-ecc4-e138-b60d772fe0ff	0	200000000	پاس شدن چک صادره 39297	2025-12-20 12:32:18.832579+00	f4b6cd05-0655-b903-9bfd-ca1e7445de6b	34427b1a-3e14-1c37-9374-a9f85747e684
fa627952-eee8-13a1-f8bf-b9ea6a77f783	4323f361-1339-4a72-11c3-3bed2f1f92b8	943cd734-9d60-bc71-f748-0266a832f419	60760347-a0fb-8670-6d4b-bca022cdb88a	200000000	0	وصول اسناد پرداختنی	2025-12-20 12:32:18.832579+00	0e5a2221-ba53-0554-810b-e84f15bf5edd	115027e3-ca1b-9c9b-ad56-7e0a2dcd30a8
d355927b-c618-bb55-356b-79504d1897fa	6b6af563-951d-7994-bd53-5e8a41fffd35	c092d59a-6dca-fce7-86c7-4027617a6731	2ba79665-5cc4-75d3-2442-91bf896ef4bc	0	300000000	فیش/حواله - 	2025-12-20 12:32:50.556516+00	9ea42894-82f3-d341-0110-e785e48549c6	20e0fa7a-0433-6a9e-b3f1-7485f1c643b0
3f6e8c8b-5316-b7d2-d303-2ada1d4c4059	9a955b43-b30a-5278-4905-133106c3a9d1	6bc09813-659b-eed5-3da0-e2c954edb014	ebae1d50-b1ec-96e6-a8a9-935a74df431c	2000000	0	نقد (صندوق)	2025-12-20 12:33:50.195343+00	f35ba8c6-b7b1-0a9c-364d-f1e2202a2365	d2e5a152-2472-c1af-97f0-577d4bca4246
38bae054-9fa2-80c1-2554-a57851e34e45	4acfa6b7-69d0-19cf-b8ec-db93031ab404	0ceea55e-1e21-0c6d-206f-2382dd5c0efd	5959fcf5-a62b-0092-a94b-0014f6cae4e6	40000000	0	کارتخوان - 	2025-12-20 12:33:50.195343+00	de8f957a-35c3-3c65-4257-8c68636d2f85	46c12286-1ba0-f91e-fba6-ee7b3602ee40
dbb73e90-495e-5b8a-2253-bc50ee722c5b	bab93921-5de6-3128-1373-17252dcdd19a	17af7d50-959e-7094-6671-40af8264a2e9	8735e970-72a5-474f-b8cf-2e898ba2c2d2	200000000	0	نقد (صندوق)	2025-12-20 13:29:58.562006+00	8e60bb57-d31f-adb7-5a0d-cea11b5c8e8b	99ee6146-c8d7-30fe-9ef0-049830d5bb39
3b74c514-b645-eec1-7d5e-ea995e767aa4	906805f0-baae-b330-c65b-6bf3ef36759c	48aac223-ded5-a842-6816-bf3ef5c85556	31951883-30d2-ddf2-9609-b9efa5a240f4	0	23000000	صدور چک 12 - بانک ملت - سررسید 2026-01-06	2025-12-21 13:46:46.647181+00	d86ca262-c462-c2a8-2868-9ba0ccccc7a8	20c54761-0289-19dd-eb18-650d2f1ae7c9
59f032d7-c3e7-94aa-2473-fb293f55fcd6	184d8f47-a062-a8d6-293a-4457f0a4e126	8cd8bbbe-7615-3a9e-6b3b-1f7fb75dcaa2	df7a407b-6ef1-116a-e861-95bca35d1054	0	23000000	خرج چک 12312	2025-12-21 13:55:52.886273+00	9cedb619-faa6-d497-f8b2-d12a3f581b22	39d3e471-bfef-dd37-699e-9872e4e060d0
854d080a-713c-7975-a3ee-8b89a5e5a25c	d07e1236-0bbb-4a2a-c806-52d31603db78	84e813d0-4492-d61e-8005-059a1d983490	c63074c0-5c28-5cd8-3056-eaa638d8e0ac	0	5700000	پرداخت بابت رسید 1006	2025-12-22 19:39:56.155882+00	3f75e108-7afc-d8b1-2a47-f5613390623f	bdb8a0c4-afc3-46ea-f269-721def12f3fd
01a7c8e0-296d-4a15-88f3-90831a72d7f4	165f975f-adda-6ce5-f174-e39ce48b6511	fa78e311-5851-048b-b345-94b468c088c9	ecfbe8e1-10f3-e11d-9f99-ac2d2f8b9430	0	8900000	پرداخت بابت رسید 1008	2025-12-23 11:14:27.312594+00	db029e3e-7e80-2aa9-01fe-70d5dd141171	ece0f7e4-80a0-805b-b150-99bfce431e2a
8a570f42-078a-104c-c6a4-56dc33523cfa	de8716ee-3e18-fca0-dc75-e38c5c991173	2777ad3a-35c3-13c7-7d6c-a07c50c4655e	37ceb765-5a00-41b5-2fbf-8e245868d05b	0	3740000	درآمد تخلیه و بارگیری - رسید 1009	2025-12-23 20:59:45.12721+00	12ea5fb8-6876-504c-365e-422a9734fecd	30d3ed1e-b64c-e038-19d5-f395b3f87348
d6195304-2ba5-37b1-f36a-41a136d57db8	74975809-c58e-43e4-78e1-667b156a2616	32c08158-9f57-b45d-f9d1-00d0e8a3812b	87486abb-6217-100c-57aa-637f05818a70	0	340000	درآمد انبارداری - رسید 1009	2025-12-23 20:59:45.12721+00	f53af461-1497-66a8-f830-c35a0354c8d7	6d9f6d5e-32d9-125b-ce33-71b99853cfe4
becbc8d9-f1ac-ba18-0a32-c0b64cb0fa39	406530f1-7740-1de6-2021-a101d6ac246e	cabc8562-9c58-5a45-7d45-9320967aab42	0fdddc7e-ec09-426f-9c3b-3c6b041fa2ef	0	3080000	درآمد بارچینی - رسید 1009	2025-12-23 20:59:45.12721+00	aec7437a-537a-717a-01e0-014a9ccf1ec8	52d57367-efcd-674a-4bd1-a20b399d3357
e8d14e65-bdfb-d6b7-1399-c18161331a7e	46164527-3c03-73da-6f12-acae6385380a	32f48202-87dc-8eda-7a58-298fddf98981	0afecbf3-5920-082b-6e17-f4b4c9750a5d	0	3450000	سایر خدمات/متفرقه - رسید 1009	2025-12-23 20:59:45.12721+00	bc69e33c-de88-1890-46d8-30c4bc6e2128	91832b9a-a4db-6afc-687c-6a6841d711ee
6a0e1b66-facb-8d26-f341-52b128aa5f41	3957f8f3-2af8-d4f4-2032-d285265ba7a1	c90958e9-4d6c-c0c7-33ff-775984523fef	b071163e-717b-e898-d87f-d6becf384bb0	0	12300000	پرداخت پس‌کرایه/هزینه جانبی رسید 1009	2025-12-23 20:59:45.12721+00	b2488d36-9dca-cb36-334c-7f78cfaea1d2	88fa64a2-32d3-4a1d-26fd-368c7d97c5a1
6b7372c0-1005-ba0f-0026-fdce3f234793	3d5180bc-b289-ba79-1a43-697fc8109f51	00ead625-0410-37f4-bd93-ffef82e7cba8	af1fce06-17fb-288a-f5b8-dcef7eb4edf6	0	3	درآمد تخلیه و بارگیری - رسید 1015	2025-12-24 15:45:30.808787+00	e36f5ba7-d6a2-f215-9aad-3f1f3fd458b3	43cedaa2-9ca4-49fe-dad6-348ffbfc248f
58da5923-3f14-2573-41be-1d5157b67e13	51cd25f6-7c38-9741-3d69-3969da17dea4	8e9ae564-a73b-00ea-de44-2cd4cca02314	3a39d3ec-66e5-4301-d7dc-59223956c6a5	0	3	درآمد انبارداری - رسید 1015	2025-12-24 15:45:30.808787+00	acbc57db-b75c-a476-d493-85a454347988	bdceefa7-f034-467f-b717-faac1b96954a
06eabbe8-bb2d-2cac-0283-348a9d087b2b	24acfa57-f723-a64b-88a0-1c6482fe94a6	dcfa16f3-a1bc-7e26-f05c-492507f888f2	8e2158ce-5ac4-80e2-bd4e-29f4be043ffa	0	6	درآمد بارچینی - رسید 1015	2025-12-24 15:45:30.808787+00	d5f6bd19-c3d7-f58b-ab35-df1fc1b1b878	1fd98c74-267f-808b-e7f9-9af17ab4492c
00ed4c6e-1733-8f22-b305-863fe35a232c	4c77e5c6-2066-1d58-62cc-44c7b2fd4c66	58b9a2ef-e51a-90e4-10c8-d8b38b5b6268	d8c87203-9004-ea12-e88d-4e92869a44c8	0	11	سایر خدمات/متفرقه - رسید 1015	2025-12-24 15:45:30.808787+00	8c89d305-6a0b-a7ea-3ce0-af371eb90b96	37734cee-eda0-30b1-4e1a-a2bcea290243
15a45581-d99c-0cf8-d64c-f31310419514	d8616cc0-59ae-a6c6-4296-7d3a052db12c	e6a25b9c-c56e-0b9c-1d8a-e70904b11907	7f355cfc-5fe4-fd14-290d-44b1031728da	0	8	پرداخت پس‌کرایه/هزینه جانبی رسید 1015	2025-12-24 15:45:30.808787+00	c887b5f2-2e24-1b91-6352-2b3ea56fdb4d	f612fdc6-166c-096d-aa59-62bc34dbec2a
cebff1be-2fc5-8742-9f3e-a5cf34d9513e	8573ac84-dfe9-bb7a-14b4-36aa22b3c364	acd326ea-074f-e83c-bbce-03f4cee8618b	cfe52fe3-95d4-b46b-f1c8-8635ab9fc974	0	600000	درآمد انبارداری	2025-12-27 16:19:57.166336+00	f2b2d1bc-b794-488a-bc0a-ebc85454c807	ec6add79-4ab4-463b-62cf-ba4e53937a2d
203e8ec3-450a-aefb-8c87-90eefc526c76	705fe27f-718d-4caa-ca7c-c659f4614cc6	eb9ae2b9-ba10-b816-6059-68f709a8ee58	d858d28b-2d59-bc34-cd43-2465fd7218b6	0	1050000	درآمد بارگیری	2025-12-27 16:19:57.166336+00	3ba80e0b-03ff-bf21-ac53-595a2ad9c853	13846c62-e1a7-7361-dd7a-bd9c6f203971
aa8d9881-4565-812d-c8a2-727b263bf79f	d729b8d7-dc5a-6ec4-26fa-e0ab9e873d12	e9afe766-c6b6-f96f-44b7-6a9dceb720a9	76da03f7-7c4b-0f5f-1159-7858d25d6481	0	165000	مالیات بر ارزش افزوده	2025-12-27 16:19:57.166336+00	62e7d97e-fb1d-6c45-23d2-15af0f3e2a08	eaa03792-1718-fe46-8d76-bc4a93e0547d
4e75f6ed-6687-8a72-e861-03954b8bdb80	8ca1abbe-fc55-1049-7337-5c9f6edd8d83	e4155c81-8cf8-cdaf-4935-5496963e81a3	32315604-8a97-3e77-19d0-adf4bddd6c24	0	8642000	درآمد انبارداری	2025-12-27 20:02:09.281889+00	5c978158-e464-bbd9-2fac-cdab07367e5a	878b8dcf-166e-06b0-30bb-abc61109d8a2
8e586c95-25c9-6470-7027-5eb919933364	f145dbc5-470c-6519-b88e-bd4342836ae1	4ce74c52-a55a-df8f-6fcd-d7d963a8600c	2421dceb-3e8a-4db0-2ef4-4e2c39d6dd43	0	15123500	درآمد بارگیری	2025-12-27 20:02:09.281889+00	96958c6d-bd42-65e2-2cfc-645cd9f54364	0daac36e-5cdf-3ec4-bf5a-89fb5d1fd2ab
1582ed56-aeef-f27c-0ffa-c04e08b528f3	a27ece58-928d-b0e0-73eb-265a65a54d6d	02e4f07b-b49d-5e86-9739-25b4d5483f5f	2f87a05c-863f-8a69-c553-e265ab8ce22f	0	2376550	مالیات بر ارزش افزوده	2025-12-27 20:02:09.281889+00	d62c154a-9853-7d5f-c7f7-4607b3842ae4	22b0f3a4-6f68-e697-d4d1-617a7d2d5910
027b8e14-286b-ea34-a72a-31906e20ffb2	95484fab-52a8-6e77-14ee-ecbb7571f633	02f7e04c-58eb-737f-60bb-8900e6506d2d	82f5f604-ba19-1ebc-0e37-dbb40cdcec94	0	6806000	درآمد انبارداری	2025-12-27 20:50:08.779751+00	a4b4f114-5fb8-8cbe-95f5-c898c7bb7bc9	277560b0-bcef-2969-53ce-011456d412c3
80f89185-e56f-deb6-13ba-852b4255e27e	77b17ab9-2558-d5a0-1b1a-78e2eafc96ef	84583d8e-0c99-cb09-73c7-772e1999588a	3c67d7a9-5316-cd95-6728-e1351af85c60	0	11910500	درآمد بارگیری	2025-12-27 20:50:08.779751+00	c4f5e01c-7915-ef0e-5b75-59d61fab63ac	a08ea453-1b71-639b-5492-aa568e596760
084573c4-ecf3-4b63-1572-e0e4570fe0fc	2ad1bb64-6ebb-9bde-88a2-b76597df5c23	be0ffe08-50a5-4356-f676-d0ce2da5fecc	d01170b8-ce31-236a-f0ed-cd35ba11beb3	0	2200000	درآمد باسکول	2025-12-27 20:50:08.779751+00	3bdd10f6-e4e8-c24d-f66e-d1a1e8b4b2a8	273f8aca-e760-36da-ee2a-83f4e2b4ae68
b5cd31fa-160f-2de8-2658-e9834c385765	2ec1f678-dcb5-89cb-638d-4bad09d17f63	fa54a8f8-366f-0448-9a54-d8f920d2bc30	5ba69078-34af-a78e-cbe5-3b79887b5d32	0	5000000	سایر درآمدهای عملیاتی	2025-12-27 20:50:08.779751+00	eecb1613-e58b-b2f8-6850-3a9b150636e1	17584479-cb6d-c11a-8f30-9227574fe60e
f9ab0236-fbb6-a3ba-cf48-05a2590d8e42	4ac37ee0-1941-c556-a829-66d49ccf71d2	0ab0ba23-1f5e-2e71-0280-a35fc4ba1366	83939ea8-312e-72de-0dcc-84cc444c9243	0	2591650	مالیات بر ارزش افزوده	2025-12-27 20:50:08.779751+00	7a72864d-b7f8-2d21-7eae-b6bb2e4d7fa5	53a08e8a-c37c-f909-46cc-582187a9c064
0f3ec5c8-27b7-b673-f0dc-5c3b911073f6	9428378e-582c-55d9-154d-8f93188e8f84	45753aa6-ed92-1724-767e-8d0dc8a49e11	2885a7c7-3c6c-0c34-40ce-7516bc197920	0	6860000	درآمد انبارداری	2025-12-27 20:57:52.896537+00	037d8c78-bfe6-118f-945d-c825a82eb777	bdc43293-006f-3f93-146a-8735cec436bf
f68e524d-c2f7-f5db-a8c0-f928d1c2f172	d6ec8bd1-a85e-6fa5-737b-0728aab8af86	7e45f084-f5e7-50a6-5079-1ed5bd404ee3	36a89410-57f9-8511-dbc5-80ee1be60258	0	12005000	درآمد بارگیری	2025-12-27 20:57:52.896537+00	c8e71bb5-d656-f6a2-2ff9-f6658cea70d6	6d21b49a-d3e1-1d93-696c-d0d531bedb1f
5c9415b1-4ab1-8ece-f33a-17e769bca127	53573775-3cf2-acec-022f-4af321da7c61	3f1d54c4-0080-dff4-3225-cb0ccb69bee6	9efeaf9a-3ff6-4f91-c447-35b41612607e	0	3400000	درآمد باسکول	2025-12-27 20:57:52.896537+00	957e6293-c6d0-80d9-c133-754a1190941d	6c479622-7ab9-f680-7789-43813337b42e
126b6fde-90f0-3ae5-407d-efe96a33488c	9547ff33-bf26-75cb-7a0b-fcdfa5b8841b	c4174067-da72-50d3-4fe7-69591d15e76c	dcfd8f47-2270-71f3-d532-40ef286d1673	0	20000000	سایر درآمدهای عملیاتی	2025-12-27 20:57:52.896537+00	5fffa183-3773-d9eb-1c93-fce20ec30d5b	c3af74c5-1f71-ba9f-7fc0-f638271f0fa6
318ec7b9-1fb7-7cf6-8a73-41dd5ad87be0	6a66e18e-b2d2-eec7-ec0d-c47e09c61afd	3e40c348-05bd-84ef-19d1-b99ba090cf1d	740f9d68-de20-035d-914f-cf9708ddd9d4	0	4226500	مالیات بر ارزش افزوده	2025-12-27 20:57:52.896537+00	f94f6b43-0e9f-adb9-1c91-91610aed5652	5494e4e1-ab12-d966-512c-a5099101f6c1
fe0e3498-6f8d-e35b-0c6b-439b703600b9	0f30243c-fd53-0272-5026-2e13faaa2ea5	14adc7ed-e128-cd3c-3caf-169659acddfb	82afb1a1-d518-dc5e-8717-0f2382cb8e29	0	5616000	درآمد انبارداری	2025-12-27 21:00:05.120197+00	1872ac74-4ae2-540c-eadf-8b42143b55f1	e67ef2ff-4b8a-48d9-ce89-b1d1c60e44a1
1473741d-f7ec-70ef-1fae-110f18d39fd8	de44d121-1cb5-5829-c410-ceb9b42f28ed	bc5fb751-0e19-5312-2171-70875717f0a4	e2fba19c-8cb2-3207-e764-f0d2545bc890	0	9828000	درآمد بارگیری	2025-12-27 21:00:05.120197+00	ce0b756f-e521-29b4-d6e4-f72ebdad0845	7e611bbe-3dd0-fd23-9afa-e4762e493a50
69418986-e5b6-f76d-41f3-2ef98b95c091	835ccee6-f3a1-d45f-bf40-311265414d71	63f4d2f4-84c1-378c-cc4d-5bf172be0c35	6ad6e5f5-8fd2-1026-a172-42624d32c76e	0	45000000	درآمد باسکول	2025-12-27 21:00:05.120197+00	8af44e6d-b694-ac91-eaf5-094b7a3a48a5	6cf279eb-1e79-fdc5-d5bd-f725a07d45e0
ae676fd5-8252-803f-d213-42155489f490	2af916a3-f422-9c34-c8fd-406955e31f89	28bf220b-3c85-c90a-c054-a3e2c66879b4	7df38e28-dcae-6392-8051-26023180e540	0	230000000	سایر درآمدهای عملیاتی	2025-12-27 21:00:05.120197+00	bb1293b9-d872-df29-f1a2-206a59931cf9	b59fd038-d5c4-697c-c82a-077643cd63ac
a718db43-a711-80af-91a0-14affb8b3799	1f3ff32d-a91d-fe3f-1c30-5d0ee809757c	c7aa9b66-af19-c173-b41b-e37d7cfddd96	2545aa83-5919-3003-9fd5-5ea6da233478	0	29044400	مالیات بر ارزش افزوده	2025-12-27 21:00:05.120197+00	47fb8cdd-917b-c10e-9cea-39c82f04b0b1	b5134f3a-e01f-79f9-a380-43a5922f5927
66cd27c9-6639-88b8-6710-139a525f516e	7632ed10-0d0f-8d99-e6f2-c7de1d4cbe41	7cfb2290-2f6a-e38d-9292-70c86219faff	7f334677-fb46-5c95-af20-a2cc85d7d5d1	0	4836000	درآمد انبارداری	2025-12-27 21:09:17.353731+00	b402bfe5-47d8-3a91-d358-0f1c88cd3058	ce4f9411-efae-acee-07fe-09bbabf3bfbb
1c572f42-fcb4-70b6-4561-f16c94ceeff4	8925b028-699b-6d5c-f299-89461aab28d6	2bfdf5f6-e74c-947a-0988-2ef239620109	16fc7598-9160-66db-2ec5-4ededbb0f054	0	8463000	درآمد بارگیری	2025-12-27 21:09:17.353731+00	e6d2e557-61d9-e5f8-e97d-1d0874d62c1b	0cd99586-1a4f-07e2-3859-4be38fd164fc
b6ccceca-c833-84e4-e49a-2c1bcc410927	22854837-1eed-0166-f443-baa626140c38	18175852-ef7a-032b-6dc2-1e153a63b5f4	440c430b-c909-ef4d-fe18-dc7226403f66	0	22000000	درآمد باسکول	2025-12-27 21:09:17.353731+00	7b6ac29a-cadc-8565-c98e-768c62329d17	a9c98512-8170-3b43-73b8-83ead7678cf0
cc7e994e-7c38-e3de-0e07-81b2bad53d38	2474c59f-0139-e1dc-badf-a257435948d6	58b64546-fb4a-c542-f920-d158bc9610db	426f13f3-d64c-92bb-01f1-f37c99f56737	0	449997	سایر درآمدهای عملیاتی	2025-12-27 21:09:17.353731+00	ef265cf3-7a02-2b3a-979a-ab83a4edcbb1	e1bdc04b-aa92-c00e-b113-beb6a837461c
4b953739-ee96-e689-296b-fd377e78660c	1404eec6-8a28-7d9c-d949-c50b04c0940d	77da5ee3-4fd1-72db-c815-ab1453d5d9a5	c5380003-c6f3-d105-8269-0304c41a638c	0	3574900	مالیات بر ارزش افزوده	2025-12-27 21:09:17.353731+00	87e27d73-803f-925b-f131-ec8b47d08c7d	f8314c41-3f91-c7fe-e8c3-ebbfea7f36b7
32086e65-e359-b873-2464-940e564c447c	2d481fb2-edc0-1230-8635-b12fd46c9772	5508cc5b-ed16-f2ee-1895-49ec75356687	25b8145a-fe8e-849a-f09d-e02b70da346c	0	5416000	درآمد انبارداری	2025-12-27 21:11:22.9459+00	b99f56bb-66f2-4eb3-3338-95d65fc68e09	54278132-c526-f258-8f1f-60aeb764fb0a
7bc59110-82f2-de7b-2990-88ce394481fb	0271c47e-adf7-2ac4-7b15-ef2168424101	315526f2-88e1-9d47-286c-a5286280ba60	6f96d3f9-33a6-090d-8907-a0eef5f85fdd	0	9478000	درآمد بارگیری	2025-12-27 21:11:22.9459+00	afe8c964-996b-a7d5-b561-6a87361bb3a4	73dbe372-fa7c-65f7-78b3-6e6ed0a75fc7
2d3189d4-8311-3b38-17c0-ecac618c5bbd	144556fc-8da3-e919-4562-12814b15420f	ab84ce89-5341-366d-cbe6-8af2859f3666	6ba6940a-145a-7c56-6849-72fdee01dd6e	0	2	درآمد باسکول	2025-12-27 21:11:22.9459+00	282848cd-abc4-be2f-7c63-1d9a1cafebda	ea39a9c9-0dfc-5518-b3d3-f851d0249e20
3109dd53-2975-a91e-ad30-6a2e8aaa4e0b	ea501e91-fd12-d90b-f79c-81040a14275c	c0ac9102-fbbc-07f4-b572-687a304a674f	225f86e6-f0c4-e42c-337b-59acad02b5ab	0	1	سایر درآمدهای عملیاتی	2025-12-27 21:11:22.9459+00	0a4b16fe-7460-d816-58cc-8ee732c4ec0c	8696d633-ca56-ef6b-753c-8347efc883f0
12867850-6a1a-8829-b5f1-951d0d5309fb	ccce0e45-13bf-4fae-3b76-3b38022f09e7	14aa1ae0-73cf-7978-af3b-7c722f84f60a	1ab74a42-dcf5-acdb-ade1-8f5d67ffb30c	0	1489400	مالیات بر ارزش افزوده	2025-12-27 21:11:22.9459+00	31a87107-9829-866c-41c0-774420e34f61	a0db8531-301d-aad6-04b1-6c431f1b6145
dcfd7d27-1446-031e-a33a-d7683cca3129	8393239e-0762-b820-83fd-00ef060f027e	8588aef3-d271-5f7f-b50e-aed5d4b02d56	338250a9-4fbf-bbcc-0e25-884c89170f5c	0	304000	درآمد انبارداری	2025-12-27 21:16:02.148816+00	1e6ac4ae-239e-05f5-26b3-108c32576807	c65479f3-837a-385d-b89e-b0052c4d13bd
82074265-fef8-81c2-a84a-bd99d33ca97e	089bc922-1082-cc70-adbe-c2cbb55ac93f	85791f4e-66f7-5520-b273-3eb8cba02d27	86c2fa07-4ef9-9e8b-c71f-e290ffe9adc4	0	532000	درآمد بارگیری	2025-12-27 21:16:02.148816+00	505bf116-171d-47b3-a35e-7436576a3578	a5bc7c69-b4e3-6114-eb09-0cc7170e1e4e
7337374a-3bd7-abf1-8dc0-60c66a9463dd	e5725429-02fe-ba21-f636-ec42dbea2f25	f2a5e697-86b4-024b-0ce2-76b21d9499e0	b6747364-dddc-74f3-5f88-716f3e277163	0	56000000	درآمد باسکول	2025-12-27 21:16:02.148816+00	c4637968-1acc-f3c7-981b-e82ae55a47f3	35227faf-5b2b-6336-0b69-2b0a42410ea8
481679f5-7796-85b8-1dd8-d707a93d64d3	eeb88f2f-0430-f005-2165-24fd274e5d3f	5c9127db-7c78-b920-ee31-242d8fe1cc5c	d69f1584-67d1-212f-0411-911ac0bdaf92	0	5683600	مالیات بر ارزش افزوده	2025-12-27 21:16:02.148816+00	fc0c0261-899d-6087-504a-b57442cf4387	43a8be9f-d228-54a6-66ab-2fab1024f682
9ef7a247-0ae7-64e2-e544-3e56540e2e29	6a21cc2b-fcd4-4516-4c32-9d1c8312a338	b5684350-2365-4dcc-3837-d891afed3d7e	f6ed1fa3-c528-66e8-58d3-85668717dfdd	0	5170000	درآمد انبارداری	2025-12-27 21:56:07.37021+00	68684de4-309d-bfc3-6704-e8773a5bd3ef	87eec317-ab22-1f03-ba55-1bf638055c8a
8ad432c4-a7f7-4722-dba3-c7e7e29a498a	15855c8f-d2e3-a044-3f24-4602cf2ce150	a4db49a9-ff2d-940a-f0f1-158f5dd3a865	54a563d6-0dc8-f076-dcdd-04a1301df4b8	0	9047500	درآمد بارگیری	2025-12-27 21:56:07.37021+00	3f337184-60cf-81b2-df15-f786abca7518	57ac2327-3abe-7197-1bdc-a980518448b1
b86a054f-9829-b491-1117-53c7fe685538	38aeff97-6924-ae79-08a5-fbf47c5d4e85	b8f9e043-19c4-c30c-0200-7e570fbd2277	698fe719-a66b-67ee-1dc9-17fe65c869aa	0	22000000	درآمد باسکول	2025-12-27 21:56:07.37021+00	deb839b8-d8f9-4efc-8fc3-d33d308575b9	00cc7782-4684-7206-17e2-288c5d5c5ce7
2268bbfd-c1e6-3723-511a-35b1c306507a	9cfe8b48-a58f-48a0-4eb1-4d639b89b5aa	96aead47-ab4b-b41e-ab71-6e606c71375a	dd6864ec-7804-8024-4b7e-9995c9b6d8f6	0	2299998	سایر درآمدهای عملیاتی	2025-12-27 21:56:07.37021+00	c18d5ea2-3452-ff2e-a3f7-57e47dabe3b1	72d9dfb2-aa77-0c42-4741-459079d26e50
9621fe13-0881-602c-b66f-dfe06b3a3296	63503343-0bc9-4fbf-7432-93e311cba17e	a2630a48-333b-ad3c-d145-046cdbf909db	b9213db3-ad94-863c-1dd2-394c401fc05d	0	3851750	مالیات بر ارزش افزوده	2025-12-27 21:56:07.37021+00	6b30880d-a72b-1530-57e7-641a08ad77cb	60873790-383f-9663-bbe1-a0da44149c24
5ed9d73e-9153-82f3-4d32-69597bf1407f	3543e861-d780-773c-3dba-723464d81547	9bdcdb0e-f460-1641-a112-60bc733f9d26	6e6472ca-df68-639f-a234-fa3e8d79a3f9	0	344000	درآمد انبارداری	2025-12-28 15:31:43.190097+00	2586392f-5889-4d54-e84f-f078ca832628	c2e6e6b9-1706-9c23-b0fa-05899f9a2fb9
af268cfd-7388-9cf5-de50-09289211d024	ce46ab69-2889-bf18-9a2d-5c5c29ad0c80	bc1f1def-8cf7-1bce-c2bf-9c951967df95	771168c8-3709-0c44-9b7c-d53732d45089	0	602000	درآمد بارگیری	2025-12-28 15:31:43.190097+00	59f049b0-a1c7-d0be-a6b7-96388c609e6b	96cda256-4b26-5687-137e-fd6ef7cd94ab
0847b897-fd0c-841a-1276-be0c2fdc48e3	cb57005d-bc3e-d5c2-6a87-5d21ad71dc05	cc769762-3d1e-2bbc-8c19-f7ab323fd2a3	2fd5b993-2216-99e1-477e-3b538f8d39ac	0	560000	درآمد باسکول	2025-12-28 15:31:43.190097+00	b61554b1-5522-bc20-2632-d23a88c853d0	7bdb8972-f447-1527-ffd9-cfdf3c862df5
30867949-38ed-9a5b-3f9e-999af91e78b1	ba1ae312-71c3-cd3e-7642-4fb372b12cf0	4c262daa-65be-b9ac-063b-93105959243c	6af024cc-6151-e03a-8245-933d8b91562c	0	2300000	سایر درآمدهای عملیاتی	2025-12-28 15:31:43.190097+00	5d20974e-c28f-9bd7-454e-24264445b6e2	9d9ac108-a456-104e-7fe1-81b83b36d92d
303d44f7-45e3-aeed-4a1b-040d416b6636	d4ebba37-9185-feda-9165-2cbf896ab10b	9f6762f3-9acf-4e5a-cbcd-76056dbbdcfe	1244ba33-822e-2af8-aaa4-b12652fc3dfb	0	380600	مالیات بر ارزش افزوده	2025-12-28 15:31:43.190097+00	a291d8f9-148b-8c77-8bef-f4ed9cf36dbf	c4b7aec4-90de-a35b-5473-5d0be9df6099
a55bf1d1-eb52-eb49-4fba-1cb466e452dc	e0a75051-3e5f-1724-e262-5d8fd112efee	38484103-ef9c-bac9-9058-0ac5931f5436	054f6b7f-3220-1885-6a0b-f1b1ce75349d	0	20000000	درآمد انبارداری	2025-12-28 15:44:20.574366+00	bd560bb7-53a9-dcc2-8580-28c37cc3bc71	7f2faf06-19d2-22d8-edc4-033c2fa6a411
72b19f8f-ea43-803f-762f-24d6b94d2f0d	59e5d5b0-4c84-d312-f0e3-2517b05ed07e	3f434035-074c-358a-8df1-9b41f1c327c1	952bf918-2c7e-b676-5e9f-adde2ccd79d6	0	35000000	درآمد بارگیری	2025-12-28 15:44:20.574366+00	ead5b432-9afb-c05a-eca1-dd239e9bb65c	a8c33f34-b541-6b20-33ab-49b553f2a1f2
a1abbd60-84de-d867-25d2-772aa5ad5355	6faf942e-bd85-97da-48ea-491fb72f9e6c	72691512-029b-a58d-e60f-8ed665d0f35b	bbb8e6f1-fc97-0803-0c57-7a0d63b2b703	0	5600000	درآمد باسکول	2025-12-28 15:44:20.574366+00	140797bb-98e6-4685-8a29-2bec82acb9a3	0cc90c92-04a1-32ab-a6d7-7b977b8c87b6
73ec231c-0b23-8b44-a52a-c7164139fa7d	7d6be075-76bd-a378-8c9e-014d5c48eeb4	67bcf5de-da5c-aa95-52ad-6991a69df986	0f5942dc-16d6-738b-3f21-0a3ff28365b7	0	1200000	سایر درآمدهای عملیاتی	2025-12-28 15:44:20.574366+00	d1c9482d-a5f6-a0a8-eb28-fe6a589e4ac7	42e34633-24e6-a616-3009-77c8e3b675fe
26457365-5268-5dcf-6f97-97f99406f4f2	9c3d4950-c3af-f322-0800-463c2b4341b4	4ce8b7fd-f4cc-26cc-f6ec-58ed59234dd2	7926e798-426a-6ba2-7371-f58b382db991	0	6180000	مالیات بر ارزش افزوده	2025-12-28 15:44:20.574366+00	66212b10-5bc7-b83f-1aae-d8116239c11d	4cb71c0d-37d9-e860-44e9-e116bcf5b013
176ba83a-5521-6a69-1f61-404e6724afb3	cbbde7fc-8616-503d-7977-8fa4c13da77b	46c3bee5-2e3d-72d7-84db-ab960546c6ed	bff99c0b-d195-4057-f119-e604bfec97ec	0	1724000	درآمد انبارداری	2025-12-28 15:59:46.57648+00	3f9c9761-2b9a-6829-019c-360f58e81522	126ac8a6-ec7e-6df5-553f-6332c4bf820f
a11d0f57-7b1b-1a27-3630-68ed3397fc7c	e6564873-e3dc-7253-fcf5-1b8c7e324313	050fced0-bf3c-fd3c-7000-1b1c1afe8a9d	2e21be75-45a6-5617-6ebe-bb96c57da787	0	3017000	درآمد بارگیری	2025-12-28 15:59:46.57648+00	3a1f9667-24f6-38aa-1863-34e1696b63a9	3f9e55a7-7a53-c58b-af66-7907b8d8948e
3d288e35-3c01-018d-d4e7-a24549c5ef06	20c79a1f-0193-2b7e-9e55-8f3a7478738d	e89b46d4-bfb7-33f8-d846-37ff536ee939	4e3075a1-313f-f62e-1487-95ceba90fcdb	0	7600000	درآمد باسکول	2025-12-28 15:59:46.57648+00	7c799c6b-117f-fe96-d701-f0e0de295878	6658aa8d-7bc4-8962-19ca-3d16cf3cc509
bd75b526-d7ac-b27a-9da2-d537a3bac9d2	34338cdc-0ed9-e384-8238-475246a1078d	a0b3b5ca-3303-2e37-1076-6be486fda0cd	f90f8a42-1c2e-bd54-b876-ab19d0dbd284	0	1200000	سایر درآمدهای عملیاتی	2025-12-28 15:59:46.57648+00	84e629a9-05c2-047e-0ebf-98dc6d5f0e36	49ee7ac4-c3ed-a3fa-cb92-cb8dd2801a6c
04e03441-e7e5-a6a3-ea87-0391b48c93fd	d9113ad6-e3a8-2662-def0-818aa5c885c8	380a4420-2cfa-c73f-6921-7324bca48a2b	18f6c001-2636-f3f7-0244-b4c7bbe9ad98	0	1354100	مالیات بر ارزش افزوده	2025-12-28 15:59:46.57648+00	0c3497aa-f2ea-ed9a-c0e6-843d484bab3e	672ddbd8-58ab-4071-5a13-e2fad394b4e8
35561240-5b6f-e2a0-0a8c-cb4e44aa8a5a	899f63a0-4c43-eb8d-59cf-7dc633c5c136	a4f8c33a-2905-7e72-6047-872fdb8aa99e	f1f8623d-3d62-14b3-96ef-37b796890b98	14895100	0	بابت خروج کالا و خدمات	2025-12-28 16:07:16.859684+00	7d0c5511-b8ef-ad0b-22f0-392273d6b8bd	f70e4e3c-45cc-9b59-59ee-ea77cdf75148
c5a7d968-2a16-18ac-6942-66dcdee26496	29d60d6f-9f77-646b-77f5-74be13cc3593	7dc62d37-c6fa-a77a-6aea-02ee008d284f	9b413670-ac09-03cb-e0fd-6f0a922cf2ce	0	1724000	درآمد انبارداری	2025-12-28 16:07:16.859684+00	7fbc42b8-6333-0477-9cfc-073804590ffd	11501e74-40eb-beb4-e48a-6a6e70f0a214
542491e7-d811-7614-b02b-d66a930d8b3c	edc27cc8-bb50-3c8d-48a0-62e852433c63	52ea7e23-5b15-4e00-783f-eee19232e481	bb2d9b94-7d39-9466-32c0-042a376f1577	0	3017000	درآمد بارگیری	2025-12-28 16:07:16.859684+00	91af9df6-2fba-52fa-3317-0c8bc19d4dec	da7f193e-7aa9-4bfd-4fff-4e0ee6c78978
80bd12f8-6406-587a-b79a-1238c762e9f1	9f9bc20d-8d61-7d45-b37b-f218199682a0	95a16411-fb91-923d-a2c8-115ebb7f0466	fdbc59eb-3f85-4a0d-290e-64acac7f1bdb	0	7600000	درآمد باسکول	2025-12-28 16:07:16.859684+00	2228ef25-99b7-3f83-0f2a-c0f1c074ada3	18eb5003-51ad-739f-225c-d2e6b40dd2fa
c53ae9e6-8782-6aa8-2bfb-ff666ac59a5c	05fd5de4-3fc4-6e4d-0368-9f8ba2db0d95	5f9ecf6c-0dca-920d-620b-990742308d96	1af4acb6-4ec7-e015-b1da-eba84add70e3	0	1200000	سایر درآمدها	2025-12-28 16:07:16.859684+00	b43e99a3-0f06-7505-053c-9598bb8d661f	27ed5ecb-8b8d-4f18-801b-90e48cc39731
b5e59a19-6b38-bd61-4e0c-4590a295fabb	e942c9da-a5b0-1b00-b531-07a6b20565aa	7558d0f6-9b01-a78f-9ce2-ee4367d9e9d4	35ffc830-261f-9ac2-bd5e-cb06f504d51a	0	1354100	مالیات ارزش افزوده	2025-12-28 16:07:16.859684+00	ffb40bcc-d805-ace2-63ea-1557c69d94cf	d7a037a8-4962-3be5-4a88-d21f72a236ba
b37c36e4-a3f2-64ab-8385-8baf74f2ea83	bf6648b7-d741-4992-9def-1cb57adc64a2	8dec1a0a-2019-5b46-d3c8-60232ebe7566	f7aead58-1210-5ace-e7a3-e6d747b12f32	14895100	0	بابت خروج کالا و خدمات	2025-12-28 16:07:26.283904+00	37c4ced1-d78f-36aa-2606-67dee3c13a33	53bfbda1-ebb5-9749-a7db-9cebc58d4a93
e271ecfc-d15f-d186-0df2-eb8757a2ac00	dd710483-2a8c-68ab-c8ce-91a8b116fdf1	cfe99644-cc0c-5145-454d-fe7a4a023ad6	1cf58ec9-0de5-2ab8-d0b1-4e81b3c867ff	0	1724000	درآمد انبارداری	2025-12-28 16:07:26.283904+00	a93ac133-8c41-8d2d-ad5f-2b29cb92c045	4c22eafa-9869-7b6b-7930-bed57b9099ca
0fdcfcc8-0b52-ce8d-e40c-b885556e81ac	e887ba3f-5793-76c3-078b-7ea0a855f09e	ac01dbe5-93e8-f9fd-3f37-be3fa5689a83	9caed12a-8489-7b5f-a783-396e4d6d96d0	0	3017000	درآمد بارگیری	2025-12-28 16:07:26.283904+00	2f7f1c42-cc4a-86e1-19fe-e6cfb2014adb	2efe2d70-332d-813a-9d62-96d478ae3fd6
eaf7e652-c578-2a49-cb8b-348859e57a62	3153a410-0820-6a5d-c082-9d0a2014ffb0	1fddfec6-3332-89f1-ecfb-0b5f1f2cf848	36702e63-919a-a421-d2ca-df0cabd680b4	0	7600000	درآمد باسکول	2025-12-28 16:07:26.283904+00	c10ac580-b93e-9492-ace5-86a306169881	38a65a1d-a433-1413-b170-919970c2d741
d062d3a6-d291-45b3-fa4b-d900aa04fe36	26c9dba2-c5ac-784b-f943-5a3a921f2200	59f56b0d-3249-2606-73a7-c566e5472404	cf8b3dfd-2efd-3b93-333d-1d7e2552bc06	0	1200000	سایر درآمدها	2025-12-28 16:07:26.283904+00	c6d6f144-64e6-c775-4472-c9e36999a768	d26b3ff7-f2ff-8b30-7866-d2b52cf82bb8
e0de7f0d-ac94-2583-1145-8cbff5e98a8f	1be4ff09-e5a2-2b79-166a-9a1c13ec284b	2f9425a7-39a1-5c0d-3657-4d83bf0bbf31	f1e77d05-4926-733c-c791-9fe0b93b1f82	0	1354100	مالیات ارزش افزوده	2025-12-28 16:07:26.283904+00	8695f937-8be7-833f-dbf2-d6114648a189	007f2bf2-d2fe-bee2-97ca-07e17894fe0e
a462148f-88c9-4eff-f60b-d4bc8e5ec452	4895c82e-1579-a095-9649-42a8b4dd4840	a4552a68-1786-8fa7-f336-a05a0a0b291d	f9e38e65-acf2-6b33-90c3-1f7dbbd8ccff	14895100	0	بابت خروج کالا و خدمات	2025-12-28 16:07:37.191541+00	e5002330-e1f7-7cce-21fa-a992f456bf66	049fe044-99cc-4b8c-67f7-4270ea03d375
92856b67-bddf-e599-286f-e9b3e9f0c308	c9d80561-e897-25ea-9635-47c01c2748b6	1711d7ca-d226-e038-8443-0d597daf427a	29966c35-7c62-a101-460c-5a3e487a3cce	0	1724000	درآمد انبارداری	2025-12-28 16:07:37.191541+00	aca4c7d4-de31-351a-17f5-211f7475cf5a	6420491f-1b77-58dc-bdde-c3984a961d9a
27dcbed5-6bdd-194b-3207-f288bf2ae530	a60db9c5-5002-ee99-4b9a-d737945c892a	b7e11e8a-7b93-7bf4-a060-38c3c2992e70	3741fb34-1ec5-5555-4f30-bf2203cde34a	0	3017000	درآمد بارگیری	2025-12-28 16:07:37.191541+00	47f78b47-4873-d7c0-6b60-c23c310a80c0	21b8e6ff-7093-6634-93e1-9b59e6b5b16c
ed9c20bc-c3be-14e8-a839-24bdb39111bf	32bd371e-1539-4a45-aa42-64afb61161fa	ec8a7b77-4f30-473f-e36c-5925184cf1d6	aa9999fb-218d-bcd4-a365-8221fa005079	0	7600000	درآمد باسکول	2025-12-28 16:07:37.191541+00	7dbdc8af-320c-1feb-e04c-3a9e4519acd7	b4239f68-eb8a-6d8e-aeec-2c37b5b847e3
51b14195-b064-f6c3-1597-767da38eb968	e856a345-5782-c181-422e-50127a4e3c57	674b1fb9-fb98-92e9-3f57-65241f1cf816	9f92494f-6a51-549b-ff75-49081deb3984	0	1200000	سایر درآمدها	2025-12-28 16:07:37.191541+00	7580be8b-de07-c806-0bc0-f7a0bb3a9cee	c2ac716d-435d-6f01-2fcf-3e60f2f45bbf
c843d0f4-23cf-e2e0-da7c-2a5c1920c65e	2f32fb88-463a-d9a3-3884-3a88dba01350	08814341-3c28-a24d-7188-ba6455c37bbd	b51c5aee-a4f0-9ac5-3200-b6f3953998ab	0	1354100	مالیات ارزش افزوده	2025-12-28 16:07:37.191541+00	7251b195-e154-a8b6-80ce-e61ad0e81e2f	0d227a9d-c9f7-2264-af79-af7256ce65e9
ecd560b0-81a3-a02c-6781-916f5f4e6994	cc0fadad-0303-4995-9b0e-306003765756	798047a0-ab96-376c-05d6-4728289e463c	c01db056-27ff-6023-c0c9-7a805bb66869	14895100	0	بابت خروج کالا و خدمات	2025-12-28 16:07:44.890568+00	dbbd3194-bed6-c8ea-19c5-066b7524f865	341667cc-13ee-7136-f1d7-5cbec5e20307
5723091e-6216-68f2-b1c5-bd0ede7f2b1e	0fd770f3-f231-05b3-bd9c-84b04d2fff5f	a97b16e9-aeae-74e7-2db2-6d4de43d3be6	a5bbd2ca-e64f-390d-9648-ad9333310224	0	1724000	درآمد انبارداری	2025-12-28 16:07:44.890568+00	19d3afe6-9c6c-1a5c-64ed-c3f9e7a97ca4	634b0251-bc04-87a4-ee80-d353685c8ec2
306640de-01bd-ffb7-0da0-d351c4c32ddf	50a680ec-c227-0e90-e69c-9d8c56b16dfd	dc1e5fb0-0d94-ac90-8e9a-2c0f14f73769	16bfc03e-0a38-7da2-ab65-628691daf128	0	3017000	درآمد بارگیری	2025-12-28 16:07:44.890568+00	04e10b02-536f-e079-5b0e-9a40de55a1b5	f0fe9dee-711e-7afe-6173-d95557f85c6d
5c1367de-a263-233d-153f-329ee1a807e6	6eccf455-a060-96e6-deda-57e455475e32	1aab965b-0528-2f39-8e81-57908e10c707	048696fe-764e-3444-e2d2-7a60fd18fa7f	0	7600000	درآمد باسکول	2025-12-28 16:07:44.890568+00	82dc93ff-73d8-24d9-dc64-804456754b82	dc9a5048-b394-d8eb-68f7-ab02b3afde60
67bea232-1446-bcde-dfdc-79b2e39b1834	0c993649-1c15-022f-921c-e86bfd5a05fe	00a33dce-076e-b5e6-5b3f-0083435683fd	59b64d9e-cb42-b4c0-4a8d-2000b4345568	0	1200000	سایر درآمدها	2025-12-28 16:07:44.890568+00	ba5300ee-e4cd-9fc1-2b32-c89407480291	020c92b5-2679-006a-7476-268d7a5c2012
738df5c0-9533-948f-2258-09e6678e8fce	124522db-c10b-0397-c88b-d83a3aaac3af	703eed23-8784-361c-7444-968b8cacfeb6	63357c81-acd7-f8e2-dab8-2af053d4db4b	0	1354100	مالیات ارزش افزوده	2025-12-28 16:07:44.890568+00	3b1de0fe-5a0b-5d26-66da-f0b993dd1e2c	e48994a2-d155-2541-df74-93bdf5d92237
906bd285-6f2d-3b52-6138-e840bf4bfd9d	3ea41dcd-9308-aa26-1186-a2b5561eabe2	82dde322-8cfb-9318-bcb9-668af204f523	045cd317-9a58-d24f-9d09-1a109f609c22	0	1620000	درآمد انبارداری	2025-12-28 16:20:15.12193+00	65ead68b-0317-24bf-ad1d-387737312f7b	eaa2ca34-4bd2-e4b2-c7eb-7d63c4015174
0c77b266-950a-9ccd-41cd-c03e90cf77eb	81b85a47-420b-66f9-c0ab-5ce35d04db98	1652a1ad-daf8-1e57-c730-a9be89afb2cd	3de47c78-e359-6a27-9717-f5e5e21ef968	0	2835000	درآمد بارگیری	2025-12-28 16:20:15.12193+00	289fafb0-d8d8-cf10-2cee-dc6304688434	abe441a3-0c17-8032-a607-29a42cab6995
626f493a-affc-b0fc-49b4-f83f818f7bb2	d7c83997-e7c1-df35-4972-5760225b21f9	3f270188-af35-cc14-787f-aeb5cefa4889	4b6408c9-796b-51f9-1150-409d6a57027e	0	76000000	درآمد باسکول	2025-12-28 16:20:15.12193+00	5b7048a6-a9db-a958-bc3e-bbdd7ff13f23	b127bb3a-69c0-1589-7c69-baf60a0abb2f
21e69de8-f8f9-b5df-586e-d8374e8ddb8e	ab22dbf6-d391-94e5-c13f-3440d62db468	6e1519c6-cc94-63c7-92a8-2d2f179b73b5	bd059ef4-2629-bba9-9b87-f401e29d293c	0	7900000	سایر درآمدهای عملیاتی	2025-12-28 16:20:15.12193+00	58e75bb0-9542-fc19-f75c-66b99fc82320	ff6caef4-23a3-b45f-919d-bc87307172c5
edae978c-5a68-0f00-6139-418fd614e695	8679c5ef-1fb6-e950-4d71-7154ed456807	3bedc58c-108b-fa6e-044a-29559e0df3d5	2866fb70-1d83-e481-53ad-7078b1c54857	0	8835500	مالیات بر ارزش افزوده	2025-12-28 16:20:15.12193+00	c4008ad4-77a8-ba01-0cac-66b9a66d6a49	a30e51ea-f8d9-ff29-8550-8b366f61f29d
5f02a8ab-97da-de15-9eb2-813281e537ff	26b2e562-63d5-c474-b726-0d4f3b6d29d3	31dda38a-7065-5bf4-d3ea-c1db784a9ed9	f636ec46-33ee-029c-9fbb-5cbc59f91790	0	12060000	درآمد انبارداری	2025-12-28 19:47:09.822811+00	5ca80ffb-3120-51aa-3b4e-1cdecac3d6f6	191149f4-110b-4132-db70-0b467575e6bb
fbe2b89f-561e-b781-43e2-28118bf447ae	c6f5bb96-2de4-d5d7-2b07-0086176d823b	b94f3155-5400-845e-5dcb-bccb44cdac82	f8878804-acad-a659-f704-afc7e18fc9c7	0	21105000	درآمد بارگیری	2025-12-28 19:47:09.822811+00	6898e0c0-4c5a-9f9a-360b-ab4a3fe95a76	0102f376-75d8-5372-bd87-ce52119176b0
0a6b0f37-b228-aa04-1d6f-accda68dc786	dd15b889-7f84-5c10-f6ee-4d3f3083c4d6	6d56ac26-5d7f-d270-1559-9ceb610edb68	b9e5525d-35e3-ecf7-3cb1-cb105ae320ce	0	7000000	درآمد باسکول	2025-12-28 19:47:09.822811+00	8edb26b5-b026-9cd3-4cf9-e4bfcb6a2739	c98d9e02-5388-f9b8-12db-9a2650b9033a
1003c1dd-1a27-1d88-6edf-7dc7671908fc	3c56c8a1-3065-ccfe-9f9b-d47027c350dd	c1251e94-e06d-bcd6-bf11-3027e1f6f6e6	28012eba-d110-bdfd-abc8-a8162e7df1e5	0	4016500	مالیات بر ارزش افزوده	2025-12-28 19:47:09.822811+00	e0c0b982-b162-0f10-34b4-c651605c5fcb	866ecef6-e9c1-6840-7b53-25a5f8878cdf
21634ffe-3930-29a2-bf87-10d653f07817	cc5d7ed2-dd88-7580-4a05-7e108aabab25	3371e0eb-3f19-6f9e-8fe0-ac766a82d558	a69a0dca-8eca-85b4-51b5-aa8cff9bdbd9	44391486	0	بابت تسویه فاکتور	2025-12-28 19:52:51.29236+00	b41557f6-86fc-4333-0ea6-9046d771f39b	50b4acae-813f-6464-fffb-d9e80a25884a
39efbe2a-202b-5810-4dfc-46842bce27f9	0c60ff04-4a09-264c-3e36-1e49eb6426ef	4994c35a-cda0-272f-5d65-08a9fc0b302a	4827d945-b007-97be-0de6-4cc01506fcef	0	1824000	انبارداری	2025-12-28 19:52:51.29236+00	6aaedea5-da34-cb2c-5438-a79a22468c94	f51dccbf-36d7-ed9d-8d99-68a6bf1497bb
2f319d99-72ce-1de1-6db8-44a645a20f57	9ab8e9ca-1407-687e-34f7-ef48c92ea511	6f7adb1b-77f3-0249-544c-62b85e93b0fc	16b50142-4ab7-127c-3f9e-9896fcea0204	0	3192000	بارگیری	2025-12-28 19:52:51.29236+00	41954dc1-bff9-ecf7-0505-cba26aefe87e	d07ddb7a-b626-dc7f-3f5f-610371306743
872bdfed-4bd5-7cc2-4c6c-2b13a0bbc660	cec27f09-2ca6-6f79-5299-54a6667f0631	61af848b-eac0-c834-225e-6294783daee8	3839dbca-0975-4e08-e106-b3e06af13bbf	0	340000	باسکول	2025-12-28 19:52:51.29236+00	337f40bc-164d-4a0e-83ad-2f8be07bee31	322062de-2955-8c04-4f53-092a489274d5
96e5b15a-2bdc-4fe7-d7df-d093d6195ad7	1b7cb371-4ffc-81c0-a2e1-1b9367c63a2a	ec88f15c-cc12-b73d-e528-d438ac6becc7	5fc60dda-223a-5692-b9cf-4cd262a72708	0	34999896	سایر	2025-12-28 19:52:51.29236+00	22968c18-6d6d-7d49-6056-87795303324a	dbee54b4-49b1-4aa1-fc81-06678352a09f
33d539bb-8ad5-1cc4-ffa5-61d0eaa96f56	45933668-de48-7d49-6c4a-aacf03f68e9c	6ea2c820-18f8-c221-a615-1c94e856271e	77b4c195-4511-e672-09a8-9567a0334641	0	4035590	ارزش افزوده	2025-12-28 19:52:51.29236+00	f4060a06-cfde-9b6f-6b96-3cf8a1374912	4d462774-3f0b-14a3-3974-9cd9f48db0ee
6b24360f-f340-282d-3029-66168858a614	a148411a-5f65-da50-e05a-fd79a054fcc5	39c67509-4ab6-80fe-0a2f-1323707b34d1	efa1860c-83dd-02c3-36d6-2afc73259523	4561700	0	دریافت از کارتخوان - خروج 57	2025-12-28 21:40:43.277362+00	81db94df-2da0-918a-4aba-2621799829f9	f4babc55-7e9f-2c85-0cd1-db25c781ff93
eacea02d-1d12-d92d-ab5d-47231f67d966	d33f546b-1147-161c-7081-aced017d2960	3e977c6e-8b67-25df-1a2d-5bee4ab36805	f875f07b-049b-0963-ac61-7e38b28b1f42	0	1508000	درآمد انبارداری	2025-12-28 21:40:43.277362+00	3cbb2b35-6ffc-cace-e24c-d8a39e1050a5	49695002-ad80-ece2-c2f7-c2ee0f8706b5
f5a1bbd9-2501-70d1-3a0d-e520f563787d	424f7b13-92d5-8cb6-1ff9-b008599e8fdf	a7dd0e40-2a38-5ad2-6608-1b963e2f739e	d306bbbd-a0d5-753a-4e91-4c55f5b4a8aa	0	2639000	درآمد بارگیری	2025-12-28 21:40:43.277362+00	8228d5fb-ec49-5f86-80b7-7df8e6f03081	c42a09c6-1b6b-6181-77d9-5baa47137ea8
da40c4ec-1710-34a5-f692-c4cc776b03d1	3fecc753-11c7-ad74-2024-2f7aa462ee86	b98e5fc2-dd81-83d3-c1fa-400c06583a2d	1c7448f0-e3e4-2fc8-db3b-95518a3a9393	0	414700	مالیات	2025-12-28 21:40:43.277362+00	3eab07fa-a84a-26ea-da8b-2654755583b2	5df73cd7-6aa6-fdff-c4f3-61c57559b615
e439a732-41a2-2248-8fbb-63634df3057a	6a167c37-54ea-d7d3-7c3a-1cbbbd2f2a93	4a6763c0-4227-521f-bd90-778714f45388	8f475b7f-6081-a2f4-1707-872c1afe7653	0	150000	بستانکار بابت درآمد اجاره	2025-12-30 19:39:19.041517+00	f56206a0-f8a4-7ba3-ac39-49f1753975e5	e6dde246-ce9c-3922-c0c4-edda09a2952e
e90f8bba-5579-f28e-e164-d8ec3e92a139	ebaf74c3-d039-8dbc-4d8d-4fffd32998ea	2dea3b34-913d-c514-fe0c-6e37d2ee0051	7ab1300c-609a-6860-fa89-ccf1737e8bff	0	25080000	بابت درآمد اجاره انبار اصغری نامشخص از تاریخ ۱۴۰۴/۰۷/۰۱ تا تاریخ ۱۴۰۴/۱۰/۰۹	2025-12-30 20:12:00.556485+00	bf8f9d6e-83be-7e71-0b8c-7fdcef569ca0	dd17c71e-70bf-9624-8e43-123f875434a8
d392c0df-77ef-f07f-f20f-f1af53f6cd2f	f4ea566a-6665-b2c0-701a-bb1050f3513e	6b81368d-f748-b9fb-f998-a5f0cbb43f51	96161c69-d65a-44c7-7669-9d6c4f35350f	0	3170000	درآمد تخلیه و بارگیری - رسید 2102	2026-01-03 09:40:39.018713+00	c16619d9-169a-061b-45c8-f5ac6ca5c4f8	10eaaf53-05d9-1bd5-7629-a77b992feb23
c134985f-2e90-9269-c10c-b0400a1472d0	3d9cf12a-74d4-62f2-8ecc-b7c05be3e01d	523786d5-001d-0722-fcf8-0d83c104f5e6	15a70351-33ee-4850-84fd-b03703ea82b0	0	200000	درآمد انبارداری - رسید 2102	2026-01-03 09:40:39.018713+00	ee60773c-000e-ff42-f674-403d230d38a4	749435cd-e6d4-0b23-7639-a4a852840e1e
8561df0c-d027-540c-78d6-d47611059461	6435fc3d-a7fa-d92e-ae8d-ab00844c181e	4538d27c-076a-934a-8b59-3332c94354d7	0e3e70b9-08ef-a9a0-9766-8d2b4ca019dd	0	23000000	پرداخت پس‌کرایه/هزینه جانبی رسید 2102	2026-01-03 09:40:39.018713+00	52c82839-e709-0c6f-973d-3f645ad9bbab	7c69f3a8-0f3c-43b8-43ce-05eeead0ef62
edf2c99b-b9db-c519-6127-11dcb206637e	86bd6664-867c-1f6e-d344-09d017aad29b	c8e3d991-746f-b49e-e9b2-1c154a266165	ae477202-b3a8-7a53-7862-282c594e8c9d	0	20000000	درآمد تخلیه و بارگیری - رسید 2103	2026-01-03 22:59:53.212173+00	cc5e251d-a508-c65f-7f01-868ce20c278c	fa9c36f3-e68a-a7eb-7bdb-8f74efc2d7a6
71184388-ef04-9557-5f11-4af6010247a6	97d70d91-52fc-2ca6-fc9b-8f03e5b0e1ce	7fb903e9-e120-c477-112f-54de3a0807ce	667060bc-64f8-d149-ee96-b31d0f40faee	0	360000000	پرداخت پس‌کرایه/هزینه جانبی رسید 2103	2026-01-03 22:59:53.212173+00	5949e78f-e0cd-8068-5db5-65c5ae245143	febcee90-837d-e895-cab3-b90f90f92ea7
5dc9501b-080a-24be-ab1d-8cf0d90cbc78	fc9937ce-a047-27be-d703-628438c23a93	6cbe9aa7-4853-1d8e-8f93-d453fe21ef26	bfeef961-7cef-da3b-b69a-3ee2cb37e131	23320000	0	دریافت وجه بابت خروج 11004	2026-01-05 12:39:51.434878+00	0629400b-0dee-84f6-c057-a2d7fc21af48	00c047c6-ae12-f212-eeab-c0e1271e2ba8
80e968db-3986-2b15-3121-57789a49e054	6fcb4289-5573-1496-4d72-8173935a9287	fd1c8b49-0bdc-2ca7-55a9-9593cf24c7a6	2df87550-26fb-93d8-00a1-a91f4b18cbc4	0	8900000	درآمد باسکول	2026-01-05 12:39:51.434878+00	aeab2a64-a268-7d16-3219-dd1a7778e104	d6e1d280-c870-04bf-f2e6-1c82e229f5e3
d409ec64-15d4-5887-359a-dee5be339579	73e504de-e5ac-474c-83ae-4c1d3ce67f8d	59ec83cf-317c-39ec-f426-77562e289e1f	5a499304-a0b4-1df5-5c83-547c4728f5b8	0	12300000	سایر درآمدهای عملیاتی	2026-01-05 12:39:51.434878+00	45ed5ec4-74cd-7748-a4bf-8c7464dd84d8	03fc3b9e-1a0b-e489-eaf6-8451535cd4ca
b03e59bc-9bcf-966a-be0b-25eb4b6bbf0d	b2b1a7d0-35c2-f98d-c24b-ff968d8e5cb8	8ff182cd-9b51-e8aa-e8ad-e03096e24d20	f09b8fb7-7047-32a2-2763-cb5f0e4b749f	0	2120000	مالیات بر ارزش افزوده	2026-01-05 12:39:51.434878+00	825fffd7-932a-7ba8-3353-2ece555c9101	ae8a7d1c-6457-1178-8c8d-c99ca6b3fe14
45355f40-4c3a-4b2b-99ad-d3224338bd0b	298fc944-d979-40cd-bc99-3323b2bddc2e	55b25abe-a385-fcea-5f4f-951293860337	b3724c7e-e598-1355-b1e5-5803d9fc9cb4	340000	0	\N	2026-02-01 19:46:52.900571+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
6b3e1734-e59b-463c-aa7e-644248cfa5b0	298fc944-d979-40cd-bc99-3323b2bddc2e	ad6c0bc6-4890-0d0d-6eed-9a86cd5a122b	1c6062f3-3853-5e60-7255-b8849fc400bf	0	340000	\N	2026-02-01 19:46:52.900571+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
dad426ab-a30e-451c-a219-db876a03f3ce	da51ea09-15b4-47a4-9cfb-0cd234e3ab9c	ad0efd2f-fe61-2f49-688a-aa86b1166f99	\N	0	20000	انبارداری - رسید 1014	2026-02-07 10:51:48.665069+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
540cbfe3-fc0b-419f-b8d5-51a607ae8676	da51ea09-15b4-47a4-9cfb-0cd234e3ab9c	8da3a452-1d4c-ca83-4fcd-029ed3843231	\N	0	35000	بارگیری + تخلیه - رسید 1014	2026-02-07 10:51:48.665069+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
de4e2a29-3111-4369-b536-e69421d1b2f4	da51ea09-15b4-47a4-9cfb-0cd234e3ab9c	e7f9461b-61c5-1b99-a7fb-e477ad801de6	\N	0	11000	کرایه حمل + سایر - رسید 1014	2026-02-07 10:51:48.665069+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
48e27829-91e4-460c-ad19-ab2a656817cd	da51ea09-15b4-47a4-9cfb-0cd234e3ab9c	6bbf21a7-f4aa-949f-a0dd-033e50e7dada	\N	0	6000	مالیات - رسید 1014	2026-02-07 10:51:48.665069+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
95ab7370-8613-4171-8382-e1f5690b25d2	da51ea09-15b4-47a4-9cfb-0cd234e3ab9c	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	153810e3-6d65-d46f-f2f5-c775d5430aed	72000	0	پرداخت نقدی - رسید 1014	2026-02-07 10:51:48.665069+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
c8fb8c1d-df83-436a-b01c-5c4723eac1ff	32a038bd-4857-44ca-851d-8d7db115dcf5	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	200000	0	بدهکاری بابت انبارداری - رسید 1016	2026-02-07 11:38:51.46177+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
ae75a838-b9a6-45e8-92ee-865d6e808ed9	32a038bd-4857-44ca-851d-8d7db115dcf5	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	900000	0	بدهکاری بابت بارگیری - رسید 1016	2026-02-07 11:38:51.46177+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
40c13f5a-e55b-4539-9852-e06db7f12900	32a038bd-4857-44ca-851d-8d7db115dcf5	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	788999	0	بدهکاری بابت تخلیه - رسید 1016	2026-02-07 11:38:51.46177+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
810fc573-1730-4419-8694-15b107fbfd77	32a038bd-4857-44ca-851d-8d7db115dcf5	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	999990	0	بدهکاری بابت کرایه حمل - رسید 1016	2026-02-07 11:38:51.46177+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
54395b0e-8f33-4415-a5eb-f70d7b98d9d7	32a038bd-4857-44ca-851d-8d7db115dcf5	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	340000	0	بدهکاری بابت مالیات - رسید 1016	2026-02-07 11:38:51.46177+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
6359e328-414c-4905-8429-694497ac64b0	32a038bd-4857-44ca-851d-8d7db115dcf5	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	876999	0	بدهکاری بابت سایر - رسید 1016	2026-02-07 11:38:51.46177+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
97c48aa4-7b16-428a-bb9b-6262157d8056	32a038bd-4857-44ca-851d-8d7db115dcf5	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	5ee414e5-1c66-7ec8-2823-8015d622e1a6	0	4105988	خروج وجه بابت رسید 1016 - طرف حساب: محمدی	2026-02-07 11:38:51.46177+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
329a4442-2dfe-4bcb-b64f-b2e9697e9ebf	c0016b7e-4526-4f40-9c02-83affabee146	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	3400000	0	بدهکاری بابت انبارداری - رسید 1017	2026-02-07 12:47:52.125367+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
8dae67ea-a96c-4257-852c-c5afaa2cde30	c0016b7e-4526-4f40-9c02-83affabee146	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	9830000	0	بدهکاری بابت بارگیری - رسید 1017	2026-02-07 12:47:52.125367+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
039be0c0-48a8-46dc-aae8-b0a84a3aa305	c0016b7e-4526-4f40-9c02-83affabee146	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	98377000	0	بدهکاری بابت تخلیه - رسید 1017	2026-02-07 12:47:52.125367+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
0799bec4-a1c6-4161-93e8-5dde3306e597	c0016b7e-4526-4f40-9c02-83affabee146	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	1200000	0	بدهکاری بابت کرایه حمل - رسید 1017	2026-02-07 12:47:52.125367+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
36796fc7-cc76-480b-9725-323f354f6439	c0016b7e-4526-4f40-9c02-83affabee146	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	7289999	0	بدهکاری بابت مالیات - رسید 1017	2026-02-07 12:47:52.125367+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
233daec2-68e3-47bf-93b9-8df1c8c4404a	c0016b7e-4526-4f40-9c02-83affabee146	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	72888883	0	بدهکاری بابت سایر - رسید 1017	2026-02-07 12:47:52.125367+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
90437a48-c7d2-4e63-856f-8fdae052e23d	c0016b7e-4526-4f40-9c02-83affabee146	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	153810e3-6d65-d46f-f2f5-c775d5430aed	0	192985882	خروج وجه بابت رسید 1017 - طرف حساب: محمدی	2026-02-07 12:47:52.125367+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
da96e72f-243b-4835-8a23-79e98919cbd9	6257e7dd-c345-492c-b123-a630821c3c7f	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	90000000	0	بدهکاری بابت انبارداری - رسید 1018	2026-02-07 18:26:48.188699+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
8cd1e270-ef97-4908-9d4a-3f51ec662432	6257e7dd-c345-492c-b123-a630821c3c7f	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	34000000	0	بدهکاری بابت بارگیری - رسید 1018	2026-02-07 18:26:48.188699+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
df27f2ea-3e97-452a-9df9-3222117efb4b	6257e7dd-c345-492c-b123-a630821c3c7f	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	3890000	0	بدهکاری بابت تخلیه - رسید 1018	2026-02-07 18:26:48.188699+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
04c5b207-1eb5-4004-b6b6-5e608bf22e0f	6257e7dd-c345-492c-b123-a630821c3c7f	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	23450000	0	بدهکاری بابت کرایه حمل - رسید 1018	2026-02-07 18:26:48.188699+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
528c9b1f-57c9-472e-a79f-f7d3c9d5c2ba	6257e7dd-c345-492c-b123-a630821c3c7f	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	98560000	0	بدهکاری بابت مالیات - رسید 1018	2026-02-07 18:26:48.188699+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
207eaa55-dbf8-4df6-807e-ce9ec5340e9a	6257e7dd-c345-492c-b123-a630821c3c7f	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	12300000	0	بدهکاری بابت سایر - رسید 1018	2026-02-07 18:26:48.188699+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
f82c057d-78c6-4ebf-8f0e-5c684ece7359	6257e7dd-c345-492c-b123-a630821c3c7f	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	153810e3-6d65-d46f-f2f5-c775d5430aed	0	262200000	خروج وجه بابت رسید 1018 - طرف حساب: محمدی	2026-02-07 18:26:48.188699+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
8c48bbe5-7181-4730-b00e-c06bd6fb431a	0a37b376-522f-41c9-b06e-805afbd77552	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	9999999	0	بدهکاری بابت انبارداری - رسید 1019	2026-02-07 18:33:50.957934+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
1599f9f4-46c7-42ff-ae8e-57696bb734e5	0a37b376-522f-41c9-b06e-805afbd77552	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	1111111	0	بدهکاری بابت بارگیری - رسید 1019	2026-02-07 18:33:50.957934+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
7e3d5bd4-691b-4c84-b100-8dc2ba56b4e9	0a37b376-522f-41c9-b06e-805afbd77552	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	77777777	0	بدهکاری بابت تخلیه - رسید 1019	2026-02-07 18:33:50.957934+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
a23b17b8-b7dd-4305-8ffc-1564ea27be31	0a37b376-522f-41c9-b06e-805afbd77552	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	22222	0	بدهکاری بابت کرایه حمل - رسید 1019	2026-02-07 18:33:50.957934+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
2f869013-3477-453a-aa52-e2c475b8fc32	0a37b376-522f-41c9-b06e-805afbd77552	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	89000000	0	بدهکاری بابت مالیات - رسید 1019	2026-02-07 18:33:50.957934+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
637bb913-9cd2-4d78-8094-ab2ed53bc2f6	0a37b376-522f-41c9-b06e-805afbd77552	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	560000	0	بدهکاری بابت سایر - رسید 1019	2026-02-07 18:33:50.957934+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
63ee4345-959e-457e-819a-57a6e4c544fa	0a37b376-522f-41c9-b06e-805afbd77552	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	153810e3-6d65-d46f-f2f5-c775d5430aed	0	178471109	خروج وجه بابت رسید 1019 - طرف حساب: محمدی	2026-02-07 18:33:50.957934+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
846a1438-4267-4a71-b305-0f93f8a7f337	a47bc809-ea9b-4f76-a025-21135394c0e3	55b25abe-a385-fcea-5f4f-951293860337	c0d34ee7-9211-bc5b-9f74-56569d751cee	25217500	0	بابت خدمات خروج شماره 9001	2026-02-16 11:51:22.872622+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
6d9fe091-8d8e-4cea-a0d5-f729d36c8e14	a47bc809-ea9b-4f76-a025-21135394c0e3	ad0efd2f-fe61-2f49-688a-aa86b1166f99	\N	0	5500000	درآمد انبارداری	2026-02-16 11:51:22.872622+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
8d16996b-d7a2-4573-8a4a-9847ddf5ff78	a47bc809-ea9b-4f76-a025-21135394c0e3	8da3a452-1d4c-ca83-4fcd-029ed3843231	\N	0	9625000	درآمد بارگیری	2026-02-16 11:51:22.872622+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
86b61d6b-c823-442c-ba01-36dd96a5a6d9	a47bc809-ea9b-4f76-a025-21135394c0e3	3845ade2-4ddc-07a2-df80-afba3f93ff5c	\N	0	7800000	درآمد باسکول	2026-02-16 11:51:22.872622+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
799862e2-c1b3-48a7-954a-c48bab7356dd	a47bc809-ea9b-4f76-a025-21135394c0e3	6bbf21a7-f4aa-949f-a0dd-033e50e7dada	\N	0	2292500	مالیات بر ارزش افزوده	2026-02-16 11:51:22.872622+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
0996a838-7abb-4c1c-b960-e36cd01c4aa1	0dd10ad6-dece-4790-b9cd-af2a0bf0c6dc	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	153810e3-6d65-d46f-f2f5-c775d5430aed	230000000	0	واریز بانکی از حسینی 666	2026-02-16 12:57:40.207619+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
5e445d14-0fae-4906-86b6-7585ac6998e7	0dd10ad6-dece-4790-b9cd-af2a0bf0c6dc	55b25abe-a385-fcea-5f4f-951293860337	c0d34ee7-9211-bc5b-9f74-56569d751cee	0	230000000	واریز بانکی از حسینی 666	2026-02-16 12:57:40.207619+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
5bd78b09-da71-4e22-b010-6c833c881078	69a1b217-ce41-41af-8729-7bd07d6bd68a	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	153810e3-6d65-d46f-f2f5-c775d5430aed	400000000	0	واریز بانکی از حسینی 666	2026-02-16 13:02:45.782584+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
477306ad-8493-48a1-84b9-6ebaa2a47381	69a1b217-ce41-41af-8729-7bd07d6bd68a	55b25abe-a385-fcea-5f4f-951293860337	c0d34ee7-9211-bc5b-9f74-56569d751cee	0	400000000	واریز بانکی از حسینی 666	2026-02-16 13:02:45.782584+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
b631f82e-ac1f-4cf1-9a3f-2d82e9667ce2	72238009-aa6b-4094-8a8c-54c592e8afac	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	70000000	0	حواله بانکی به محمدی	2026-02-18 21:55:37.804336+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
aa4a8128-dfde-4754-8723-517527f989b5	72238009-aa6b-4094-8a8c-54c592e8afac	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	db32264d-c759-1996-37f0-fd1800522a54	0	70000000	حواله بانکی به محمدی	2026-02-18 21:55:37.804336+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
d0639a7f-713e-449c-a59a-eab342ea5602	e1d2368e-a907-499b-ab63-e1b2fd8b0923	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	60000000	0	صدور چک شماره 12 به محمدی	2026-02-19 06:47:29.771927+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
14185576-74dc-40e3-97da-06ef61a6f9dd	e1d2368e-a907-499b-ab63-e1b2fd8b0923	a06283c9-4300-508e-b8ae-6bbef4c9d159	\N	0	60000000	صدور چک شماره 12 به محمدی	2026-02-19 06:47:29.771927+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
b40fddee-3c78-4fd9-a43e-46c1e4df32b9	4e370683-c6c3-4c73-9a60-adb587a503e7	55b25abe-a385-fcea-5f4f-951293860337	c0d34ee7-9211-bc5b-9f74-56569d751cee	30020000	0	حسینی 666 بابت صدور چک شماره چک: 12 - مبلغ ۳۰٬۰۲۰٬۰۰۰ ریال	2026-02-19 06:56:00.030543+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
f65f1ce6-5077-43f7-853e-44c6775ac448	4e370683-c6c3-4c73-9a60-adb587a503e7	a06283c9-4300-508e-b8ae-6bbef4c9d159	\N	0	30020000	صدور چک به حسینی 666 - شماره چک: 12 - بانک: صادرات - مبلغ ۳۰٬۰۲۰٬۰۰۰ ریال	2026-02-19 06:56:00.030543+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
27b19449-d893-47e6-aa22-1aff3c8f9f99	fdf0f592-fcc1-410d-9218-6dfea16a806d	a06283c9-4300-508e-b8ae-6bbef4c9d159	\N	60000000	0	تسویه چک شماره 12 پرداختنی (برگشتی) - مبلغ ۶۰٬۰۰۰٬۰۰۰ ریال	2026-02-19 07:13:28.551738+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
e0426a04-70d6-44f1-b049-0934a17544ea	fdf0f592-fcc1-410d-9218-6dfea16a806d	55b25abe-a385-fcea-5f4f-951293860337	\N	0	60000000	دریافت‌کننده بابت برگشت چک شماره 12 پرداختنی - مبلغ ۶۰٬۰۰۰٬۰۰۰ ریال	2026-02-19 07:13:28.551738+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
52d1f95e-3c2f-4b96-85f4-40f8dab86817	bb76ff27-9cec-49a4-aff2-e295d4bff042	a06283c9-4300-508e-b8ae-6bbef4c9d159	\N	30020000	0	تسویه چک شماره 12 - مبلغ ۳۰٬۰۲۰٬۰۰۰ ریال	2026-02-19 07:20:02.220774+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
bc952734-fd0e-4e6e-a699-4bb99754caa9	bb76ff27-9cec-49a4-aff2-e295d4bff042	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	b4d28845-9115-a129-2235-aaf260bb2787	0	30020000	برداشت از بانک صادرات بابت پاس شدن چک شماره 12 - مبلغ ۳۰٬۰۲۰٬۰۰۰ ریال	2026-02-19 07:20:02.220774+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
606ff8e9-f720-4dcc-a68d-9edabeb22272	9a7d1e3e-0c6d-4ead-97a7-7a3b5cedd9ba	7393d9ee-ccb2-cfb4-49e1-d57e65d9d7d5	\N	45000000	0	دریافت چک از حسینی 666 - شماره چک: 654646 - بانک: ملی - مبلغ ۴۵٬۰۰۰٬۰۰۰ ریال	2026-02-19 07:29:20.259807+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
533d33fd-8fbe-47f4-b6b0-48a0e2a6e48e	9a7d1e3e-0c6d-4ead-97a7-7a3b5cedd9ba	55b25abe-a385-fcea-5f4f-951293860337	c0d34ee7-9211-bc5b-9f74-56569d751cee	0	45000000	حسینی 666 بابت صدور چک شماره چک: 654646 - مبلغ ۴۵٬۰۰۰٬۰۰۰ ریال	2026-02-19 07:29:20.259807+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
b7549b44-5a44-444d-b989-b69d7ee84f44	f6c314fc-e606-4ce7-80f8-d56aee7fa82f	55b25abe-a385-fcea-5f4f-951293860337	e041f769-4ea6-4a91-b246-73f1d8574f9f	45000000	0	محمدی بابت دریافت چک شماره 654646 - ۴۵٬۰۰۰٬۰۰۰ ریال	2026-02-19 07:57:58.514213+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
12590780-45cc-451d-ac49-8fb730660b61	f6c314fc-e606-4ce7-80f8-d56aee7fa82f	7393d9ee-ccb2-cfb4-49e1-d57e65d9d7d5	\N	0	45000000	خرج چک شماره 654646 به محمدی - ۴۵٬۰۰۰٬۰۰۰ ریال	2026-02-19 07:57:58.514213+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
3d56311b-5a86-4df2-90c9-0e95f213e5fc	ef4cb366-79d3-444d-877e-a1891bd3a013	55b25abe-a385-fcea-5f4f-951293860337	c0d34ee7-9211-bc5b-9f74-56569d751cee	34000000	0	بدهکاری بابت کرایه حمل - رسید 1027	2026-02-20 10:05:39.142553+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
0f8f1ffa-a0b5-4f97-83fa-0097e543f726	ef4cb366-79d3-444d-877e-a1891bd3a013	55b25abe-a385-fcea-5f4f-951293860337	c0d34ee7-9211-bc5b-9f74-56569d751cee	760000000	0	بدهکاری بابت کرایه برگشت - رسید 1027	2026-02-20 10:05:39.142553+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
a20071be-af67-4288-aabb-132aa7857814	ef4cb366-79d3-444d-877e-a1891bd3a013	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	153810e3-6d65-d46f-f2f5-c775d5430aed	0	794000000	خروج وجه بابت رسید 1027 - طرف حساب: حسینی 666	2026-02-20 10:05:39.142553+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
f6828b4f-296c-4785-9d7b-9e9c542990fc	c296e97b-6e62-48bc-b965-32358452c63f	55b25abe-a385-fcea-5f4f-951293860337	c0d34ee7-9211-bc5b-9f74-56569d751cee	780000000	0	بدهکاری بابت کرایه برگشت - رسید 1028	2026-02-20 10:21:06.263245+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
9f0824fc-a930-42f0-8f1c-d3085a48cbf3	c296e97b-6e62-48bc-b965-32358452c63f	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	db32264d-c759-1996-37f0-fd1800522a54	0	780000000	خروج وجه بابت رسید 1028 - طرف حساب: حسینی 666	2026-02-20 10:21:06.263245+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
bdeb92fc-8de4-459e-96ac-299041553b94	f1307de3-3cfc-4b2b-af7e-4e507603acd9	55b25abe-a385-fcea-5f4f-951293860337	c0d34ee7-9211-bc5b-9f74-56569d751cee	78000000	0	بدهکاری بابت کرایه برگشت - رسید 1029	2026-02-20 10:36:24.109847+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
31a165e2-9071-45fa-8835-b8c8f6ad2309	f1307de3-3cfc-4b2b-af7e-4e507603acd9	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	db32264d-c759-1996-37f0-fd1800522a54	0	78000000	خروج وجه بابت رسید 1029 - طرف حساب: حسینی 666	2026-02-20 10:36:24.109847+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
a4f0b058-b7ea-4cbf-b9fb-431c8cb8930d	a28700df-c2b4-4714-b58f-ccb68e264f79	55b25abe-a385-fcea-5f4f-951293860337	96f5f3e7-3dcf-ff73-7c68-ee54dca70d33	453000000	0	بدهکاری بابت پسکرایه - رسید 1030	2026-02-21 08:33:30.622052+00	\N	f04fb725-d8b4-43f1-811d-8267e8761430
f84a2589-c29d-44e5-93fe-92a67c4ed577	a28700df-c2b4-4714-b58f-ccb68e264f79	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	e7033a0e-dbc0-e33e-21b9-93484e7a92a1	0	453000000	خروج وجه بابت رسید 1030 - طرف حساب: علی رضایی	2026-02-21 08:33:30.622052+00	\N	f04fb725-d8b4-43f1-811d-8267e8761430
ed7962ef-21b9-4b3e-a54d-441717b177d2	c927574d-7476-4494-a301-1d2e3ee7f8b0	55b25abe-a385-fcea-5f4f-951293860337	96f5f3e7-3dcf-ff73-7c68-ee54dca70d33	16984000	0	بابت خدمات خروج شماره 9001	2026-02-22 06:00:39.872166+00	\N	f04fb725-d8b4-43f1-811d-8267e8761430
2f5579c1-6b81-4d32-86f3-b64cbe897b58	c927574d-7476-4494-a301-1d2e3ee7f8b0	ad0efd2f-fe61-2f49-688a-aa86b1166f99	\N	0	4160000	درآمد انبارداری	2026-02-22 06:00:39.872166+00	\N	f04fb725-d8b4-43f1-811d-8267e8761430
016c7a85-2a60-4206-8c48-3c6237646a48	c927574d-7476-4494-a301-1d2e3ee7f8b0	8da3a452-1d4c-ca83-4fcd-029ed3843231	\N	0	7280000	درآمد بارگیری	2026-02-22 06:00:39.872166+00	\N	f04fb725-d8b4-43f1-811d-8267e8761430
cd2b9106-8c33-4096-8630-bffd5cf1fbec	c927574d-7476-4494-a301-1d2e3ee7f8b0	3845ade2-4ddc-07a2-df80-afba3f93ff5c	\N	0	4000000	درآمد باسکول	2026-02-22 06:00:39.872166+00	\N	f04fb725-d8b4-43f1-811d-8267e8761430
4e009017-9fe5-43ac-a6da-2c6fb332aac6	c927574d-7476-4494-a301-1d2e3ee7f8b0	6bbf21a7-f4aa-949f-a0dd-033e50e7dada	\N	0	1544000	مالیات بر ارزش افزوده	2026-02-22 06:00:39.872166+00	\N	f04fb725-d8b4-43f1-811d-8267e8761430
4f881d88-6833-444c-848c-5ed8755fb21d	2c05d18c-f848-491b-b605-1643cf3aaeab	55b25abe-a385-fcea-5f4f-951293860337	c0d34ee7-9211-bc5b-9f74-56569d751cee	1200000	0	بدهکاری بابت تخلیه - رسید 1030	2026-02-23 12:14:34.546331+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
af09d6da-3c30-4ad4-872b-380088463adc	2c05d18c-f848-491b-b605-1643cf3aaeab	55b25abe-a385-fcea-5f4f-951293860337	c0d34ee7-9211-bc5b-9f74-56569d751cee	670000000	0	بدهکاری بابت پسکرایه - رسید 1030	2026-02-23 12:14:34.546331+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
f46709cb-6846-4f68-83eb-0fbd097a0f45	2c05d18c-f848-491b-b605-1643cf3aaeab	26fd8975-3b2a-02c9-e574-7c1cbb871f0b	153810e3-6d65-d46f-f2f5-c775d5430aed	0	671200000	خروج وجه بابت رسید 1030 - طرف حساب: حسینی 666	2026-02-23 12:14:34.546331+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
\.


--
-- Data for Name: inventory_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_transactions (id, ref_receipt_id, product_id, owner_id, member_id, unit_id, type, qty, weight, qty_real, weight_real, qty_available, weight_available, snapshot_qty_before, snapshot_qty_after, batch_no, parent_batch_no, description, receiver_name, receiver_national_id, ref_clearance_id, ref_exit_id, reference_id, transaction_type, transaction_date, created_at, updated_at) FROM stdin;
0c425752-f026-4bc5-ab92-d4d1f311a42a	e9652b00-572d-430b-841f-ae6ce0569f02	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	87a73478-b42b-4e0a-9079-430c290190ae	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	9000	0	9000	0	9000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-04 21:15:10.402437+00	2026-02-04 21:15:10.402437+00	2026-02-04 21:15:10.402437+00
1eb40840-9219-449a-8fda-dc36448b5b66	5633c67d-b64b-4e31-a2e5-42e101871075	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	5000	0	5000	0	5000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-05 16:47:26.172448+00	2026-02-05 16:47:26.172448+00	2026-02-05 16:47:26.172448+00
16547a60-071f-4221-b45d-3e421da30309	717cf9a1-f02a-49d2-9c9c-58b37b5611ef	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	9000	0	9000	0	9000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-05 16:56:29.396555+00	2026-02-05 16:56:29.396555+00	2026-02-05 16:56:29.396555+00
5b7b266e-bd70-4358-b7e0-daec3e366ca7	da7f571a-944d-4ecc-aec2-0e019a0ff86e	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	37400	0	37400	0	37400	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-05 17:02:49.721898+00	2026-02-05 17:02:49.721898+00	2026-02-05 17:02:49.721898+00
ce8eac9e-9bdf-41aa-994e-6a20c2f91200	0a70b5fd-712e-4951-be05-9ff9f11a2c50	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	90000	0	90000	0	90000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-06 11:09:01.709743+00	2026-02-06 11:09:01.709743+00	2026-02-06 11:09:01.709743+00
03150273-ced6-4d3d-a8a4-0afa7a735754	85cb12a4-2b5d-47c6-8e09-e403d8b95ed3	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	7800	0	7800	0	7800	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-06 21:11:10.992392+00	2026-02-06 21:11:10.992392+00	2026-02-06 21:11:10.992392+00
fe5804c7-0e8a-4252-b740-4598453c8f34	b5bbe9a9-f9c8-4db8-b38e-b704f2e7dcd6	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	900	7100	900	7100	900	7100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-06 21:12:53.022927+00	2026-02-06 21:12:53.022927+00	2026-02-06 21:12:53.022927+00
fc7212c1-cc79-41f7-9a17-ac0196380dc1	d660fc83-19bd-4aaf-86f9-4631c98cbe83	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	87a73478-b42b-4e0a-9079-430c290190ae	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-06 21:16:31.599854+00	2026-02-06 21:16:31.599854+00	2026-02-06 21:16:31.599854+00
618924c9-ea8a-44ca-b9ae-08b9b69015bd	bb2b98c5-52d7-4f08-a9fd-eb469330406d	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	87a73478-b42b-4e0a-9079-430c290190ae	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	78000	0	78000	0	78000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-06 21:28:20.776679+00	2026-02-06 21:28:20.776679+00	2026-02-06 21:28:20.776679+00
2a82e370-a68a-4c47-af98-2d2e591a44f5	8052c1e1-7298-4aa1-9c67-84e530db811f	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	230000	0	230000	0	230000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-07 09:03:45.734652+00	2026-02-07 09:03:45.734652+00	2026-02-07 09:03:45.734652+00
7cebdba5-7145-44d2-a2b4-dafd0262cb66	a28e05d6-5125-410d-806e-78727a13a79a	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	12300	0	12300	0	12300	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-07 10:12:36.184392+00	2026-02-07 10:12:36.184392+00	2026-02-07 10:12:36.184392+00
27f1c3e3-b912-4be9-af6c-fac1e4f7d9e0	f6648e63-9e53-47c5-8956-fb0bdff2619c	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	87a73478-b42b-4e0a-9079-430c290190ae	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	32000	0	32000	0	32000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-07 10:37:27.038797+00	2026-02-07 10:37:27.038797+00	2026-02-07 10:37:27.038797+00
af466b8e-8a85-4931-87f4-43b3bd182abf	6db5da15-8c1b-44ae-a3d3-d841bdf059e0	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	87a73478-b42b-4e0a-9079-430c290190ae	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	23000	0	23000	0	23000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-07 10:40:46.533062+00	2026-02-07 10:40:46.533062+00	2026-02-07 10:40:46.533062+00
a34fdefa-a0eb-4bee-b935-4e7173db6919	953c17ac-6674-4b37-a916-204f37e58b0a	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	87a73478-b42b-4e0a-9079-430c290190ae	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	34000	0	34000	0	34000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-07 10:51:48.665069+00	2026-02-07 10:51:48.665069+00	2026-02-07 10:51:48.665069+00
0832898b-e058-421e-9a69-44896309a0e0	911a1cc7-ee34-4158-aa53-d030d2d795c9	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	20000	0	20000	0	20000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-07 11:31:20.222831+00	2026-02-07 11:31:20.222831+00	2026-02-07 11:31:20.222831+00
9f78ff45-db9a-4fb7-8768-ce56540cadde	244cc114-fe74-41df-ae16-1d6dd8e6bf37	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	87a73478-b42b-4e0a-9079-430c290190ae	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	8000	0	8000	0	8000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-07 11:38:51.46177+00	2026-02-07 11:38:51.46177+00	2026-02-07 11:38:51.46177+00
036add03-d967-4fcd-92cd-39a24c4cc367	b5f1409a-7275-401d-8d06-36dfa0e3a924	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	87a73478-b42b-4e0a-9079-430c290190ae	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	9000	0	9000	0	9000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-07 12:47:52.125367+00	2026-02-07 12:47:52.125367+00	2026-02-07 12:47:52.125367+00
21dd13a6-d8fa-48d2-9f0f-ccd43d5503c6	d21b45bc-c54f-4849-bfaa-699892a3c828	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	87a73478-b42b-4e0a-9079-430c290190ae	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	8900	0	8900	0	8900	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-07 18:26:48.188699+00	2026-02-07 18:26:48.188699+00	2026-02-07 18:26:48.188699+00
5d90f830-f8dd-4c67-92b7-d719c3576660	d3902200-1b65-4dd8-a2e0-c2a177264009	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	87a73478-b42b-4e0a-9079-430c290190ae	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	67000	0	67000	0	67000	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	havaleh	2026-02-07 18:33:50.957934+00	2026-02-07 18:33:50.957934+00	2026-02-07 18:33:50.957934+00
76bed9d2-37c3-458f-be9a-f473a0ed983f	399918ce-112c-4664-99a2-286bef2ad968	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	20	0	20	0	20	0	\N	\N		\N	\N	\N	\N	\N	\N	bfe9ce22-b86d-40cc-87ef-01f9d026160e	havaleh	2026-02-15 00:00:00+00	2026-02-15 11:32:55.602428+00	2026-02-15 11:32:55.602428+00
70584add-9282-4441-bbca-0d19aa6fc416	ab7555ba-4d00-4c33-bca0-521ed5dac84a	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	40	22500	40	22500	40	22500	\N	\N	100	\N	\N	\N	\N	\N	\N	44c7e283-fcbd-4583-a79b-c07186aa32ae	havaleh	2026-02-15 00:00:00+00	2026-02-15 13:29:36.725438+00	2026-02-15 13:29:36.725438+00
5f7e2ce7-b4d5-4695-8051-f2c1e75d2b96	\N	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	out	-500	-100	-500	-100	-500	-100	\N	\N	بدون ردیف	بدون ردیف	Clearance: 10001 / Batch: بدون ردیف	\N	\N	62e43a78-7ff7-44b2-87ae-4adbf4ad20ed	\N	\N	clearance	2026-02-13 00:00:00+00	2026-02-16 11:52:00.699943+00	2026-02-16 11:52:00.699943+00
30e25350-4c61-4410-87a0-eece14ade905	\N	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	out	-2400	-6500	-2400	-6500	-2400	-6500	\N	\N	بدون ردیف	بدون ردیف	Clearance: 10002 / Batch: بدون ردیف	\N	\N	eeb30a8f-fdfb-483b-bc43-cc5e5d487fea	\N	\N	clearance	2026-02-13 00:00:00+00	2026-02-16 11:52:00.699943+00	2026-02-16 11:52:00.699943+00
ad6d00a2-fd56-4de5-86ba-aa43bf780637	\N	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	out	-2400	-100	-2400	-100	-2400	-100	\N	\N	بدون ردیف	بدون ردیف	Clearance: 10003 / Batch: بدون ردیف	\N	\N	3b1c9b66-1bd1-4678-aecb-997569feff8f	\N	\N	clearance	2026-02-14 00:00:00+00	2026-02-16 11:52:00.699943+00	2026-02-16 11:52:00.699943+00
1c61fa06-7149-4f82-add0-b5d060f74137	\N	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	out	-30	-20000	-30	-20000	-30	-20000	\N	\N	100/1	100	Clearance: 10004 / Batch: 100/1	\N	\N	e4eadb5b-0c90-4478-86d2-feed0dea98b6	\N	\N	clearance	2026-02-15 00:00:00+00	2026-02-16 11:52:00.699943+00	2026-02-16 11:52:00.699943+00
3db7ca06-8bce-45db-8ea6-2f9129d3c074	\N	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	out	-4	-500	-4	-500	-4	-500	\N	\N	100/1	100	Clearance: 10005 / Batch: 100/1	\N	\N	900c8787-5912-4126-94d4-e57644b06cd9	\N	\N	clearance	2026-02-15 00:00:00+00	2026-02-16 11:52:00.699943+00	2026-02-16 11:52:00.699943+00
37c7179a-7384-4276-b9c7-cd5b9786e685	\N	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	out	-4	-2000	-4	-2000	-4	-2000	\N	\N	100/2	100	Clearance: 10006 / Batch: 100/2	\N	\N	abb4c468-1959-49b2-a6d7-683b92e2d34e	\N	\N	clearance	2026-02-16 00:00:00+00	2026-02-16 11:52:00.699943+00	2026-02-16 11:52:00.699943+00
fe15f15b-41b1-4781-9a05-44353b7bbce3	\N	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	out	-2	-200	-2	-200	-2	-200	\N	\N	100/2/1	100/2	Clearance: 10007 / Batch: 100/2/1	\N	\N	3aecde6f-bbc6-44bf-a1b3-82df6c8b64ee	\N	\N	clearance	2026-02-16 00:00:00+00	2026-02-16 11:52:00.699943+00	2026-02-16 11:52:00.699943+00
ab9cb198-2061-4b8f-a8de-3df11a2f75cc	\N	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	out	-2	-1800	-2	-1800	-2	-1800	\N	\N	100/2/2	100/2	Clearance: 10008 / Batch: 100/2/2	\N	\N	d85a00bb-2dbd-48a0-8916-0c70c976e929	\N	\N	clearance	2026-02-16 00:00:00+00	2026-02-16 11:52:00.699943+00	2026-02-16 11:52:00.699943+00
464d0542-3916-4894-b34f-019c517c049e	\N	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	out	2	1800	0	0	0	0	\N	\N	100/2/2	\N	\N	\N	\N	\N	\N	9d51a432-69d9-4d6b-bde4-d44b34990743	loading	2026-02-16 07:44:06.556+00	2026-02-16 07:44:17.69332+00	2026-02-16 07:44:17.69332+00
f7d4b3a7-9724-407e-a038-f1f5fc4baab1	\N	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	exit	2	2750	0	0	0	0	\N	\N	100/2/2	\N	خروج سیستمی (باسکول) - اصلاح شده	\N	\N	\N	14029359-20ee-46ad-a00a-1eba4f4befad	\N	\N	2026-02-16 11:48:20.750589+00	2026-02-16 11:48:20.750589+00	2026-02-16 11:48:20.750589+00
5ce45b4a-f1ba-4c9e-9c10-72524be9c2c4	8f12a96b-f10d-4006-a32f-44a142e243d6	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	300	13500	300	13500	300	13500	\N	\N		\N	\N	\N	\N	\N	\N	2926dc6a-dff3-4c71-b012-7a0ba4500988	havaleh	2026-02-20 00:00:00+00	2026-02-20 09:33:28.110634+00	2026-02-20 09:33:28.110634+00
ce6072bb-4c22-4783-886f-a1928789788c	9a5fbd2f-79a0-4f11-a352-b64f5a43514a	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	6000	11000	6000	11000	6000	11000	\N	\N	110/14	\N	\N	\N	\N	\N	\N	84197ba0-d1e4-477c-99fd-b954f8129177	havaleh	2026-02-20 00:00:00+00	2026-02-20 10:05:39.142553+00	2026-02-20 10:05:39.142553+00
f416c574-4931-43b0-9941-972b908cab65	e345955f-2c20-485d-aef1-9f6aac413284	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	40	13100	40	13100	40	13100	\N	\N	110/11	\N	\N	\N	\N	\N	\N	2b278408-9076-4426-a679-12854a10f1f0	havaleh	2026-02-20 00:00:00+00	2026-02-20 10:21:06.263245+00	2026-02-20 10:21:06.263245+00
da955b70-94b9-4ded-9fba-d088232b1c69	05bf3439-cdfa-43c9-9768-32d1aba46130	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	6000	44000	6000	44000	6000	44000	\N	\N	110/11	\N	\N	\N	\N	\N	\N	866a67c6-9096-41a8-a10a-39a40a9cc9a4	havaleh	2026-02-20 00:00:00+00	2026-02-20 10:36:24.109847+00	2026-02-20 10:36:24.109847+00
cbee3f4a-2022-4abb-a348-8be783fe706a	34dd857c-84d8-479f-b997-58b46e9d67e2	55cd5b7a-2898-4588-90b5-c8de22219328	2db3438c-0865-4cf1-955e-d9197e63061f	f04fb725-d8b4-43f1-811d-8267e8761430	\N	in	12	25200	12	25200	12	25200	\N	\N	110/14	\N	\N	\N	\N	\N	\N	fefbc62e-dfd8-422f-8b96-e8ff3aafedc5	havaleh	2026-02-21 00:00:00+00	2026-02-21 08:33:30.622052+00	2026-02-21 08:33:30.622052+00
5062c2be-864b-4755-9623-7120664bbfde	\N	55cd5b7a-2898-4588-90b5-c8de22219328	2db3438c-0865-4cf1-955e-d9197e63061f	f04fb725-d8b4-43f1-811d-8267e8761430	\N	out	1	2000	1	2000	1	2000	\N	\N	110/14	\N	\N	\N	\N	fb294c39-1050-490d-a5c8-38eb4a0d3146	\N	7a25f7a3-cbe0-404f-9144-966fcf7370c9	clearance	2026-02-22 05:55:40.522+00	2026-02-22 05:57:02.888909+00	2026-02-22 05:57:02.888909+00
680e844b-7656-401d-9067-fca9f5da2657	\N	55cd5b7a-2898-4588-90b5-c8de22219328	2db3438c-0865-4cf1-955e-d9197e63061f	f04fb725-d8b4-43f1-811d-8267e8761430	\N	in	1	2000	1	2000	1	2000	\N	\N	110/14/1	\N	\N	\N	\N	fb294c39-1050-490d-a5c8-38eb4a0d3146	\N	7a25f7a3-cbe0-404f-9144-966fcf7370c9	clearance	2026-02-22 05:55:40.522+00	2026-02-22 05:57:02.888909+00	2026-02-22 05:57:02.888909+00
f2559d5d-81d8-409c-979b-9615264ca736	\N	55cd5b7a-2898-4588-90b5-c8de22219328	2db3438c-0865-4cf1-955e-d9197e63061f	f04fb725-d8b4-43f1-811d-8267e8761430	\N	out	1	2000	0	0	0	0	\N	\N	110/14/1	\N	\N	\N	\N	\N	\N	0276dcb6-9304-447b-b70c-dcfe4c4691c9	loading	2026-02-22 05:57:22.256+00	2026-02-22 05:57:44.164585+00	2026-02-22 05:57:44.164585+00
63331384-48dd-4834-a9a5-55523d9ac772	\N	55cd5b7a-2898-4588-90b5-c8de22219328	2db3438c-0865-4cf1-955e-d9197e63061f	f04fb725-d8b4-43f1-811d-8267e8761430	\N	exit	1	2080	0	0	0	0	\N	\N	110/14/1	\N	خروج سیستمی (باسکول) - اصلاح شده	\N	\N	\N	f3fa56ae-e458-4ad5-8e50-616776caf769	\N	\N	2026-02-22 06:00:38.630915+00	2026-02-22 06:00:38.630915+00	2026-02-22 06:00:38.630915+00
e491a9a4-6a7d-4cc2-91d1-6d7775325a9a	3f3a9111-12c1-40c4-8450-03de23e03923	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	d300ce05-8008-4bb0-95f1-2eb231fb4346	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	in	23	20000	23	20000	23	20000	\N	\N	110/11	\N	\N	\N	\N	\N	\N	88d4fc2b-dee1-42ab-adac-e815fe4d6065	havaleh	2026-02-23 00:00:00+00	2026-02-23 12:14:34.546331+00	2026-02-23 12:14:34.546331+00
\.


--
-- Data for Name: loading_order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loading_order_items (id, loading_order_id, clearance_item_id, product_id, batch_no, qty, weight) FROM stdin;
88a266e8-5369-4c9a-b11b-9d045237f307	9d51a432-69d9-4d6b-bde4-d44b34990743	6b2f4ed6-3101-4474-906b-5f156b333703	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	100/2/2	2	1800
819695e9-9286-4944-af1d-b0e21fa43900	0276dcb6-9304-447b-b70c-dcfe4c4691c9	7a25f7a3-cbe0-404f-9144-966fcf7370c9	55cd5b7a-2898-4588-90b5-c8de22219328	110/14/1	1	2000
\.


--
-- Data for Name: loading_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.loading_orders (id, order_no, clearance_id, loading_date, driver_name, plate_number, warehouse_keeper_id, status, description, created_at, updated_at, member_id) FROM stdin;
9d51a432-69d9-4d6b-bde4-d44b34990743	5003	d85a00bb-2dbd-48a0-8916-0c70c976e929	2026-02-16 07:44:06.556	راننده	88-999-پ-66	45004958-852d-4b19-9de9-80c1d47e6292	exited	\N	2026-02-16 07:44:17.69332	2026-02-16 07:44:17.69332	dc66ad9a-8bc5-4556-9860-aeab96211fa3
0276dcb6-9304-447b-b70c-dcfe4c4691c9	5001	fb294c39-1050-490d-a5c8-38eb4a0d3146	2026-02-22 05:57:22.256	حسینی	88-999-ب-11	f04fb725-d8b4-43f1-811d-8267e8761430	exited	\N	2026-02-22 05:57:44.164585	2026-02-22 05:57:44.164585	f04fb725-d8b4-43f1-811d-8267e8761430
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media (id, filepath, filename, mimetype, size, width, height, created_at, updated_at, related_id, related_table, description, member_id) FROM stdin;
4586df64-f852-7f72-da55-4501222877ba	treasury-documents/treasury_1766237389342.png	Screenshot 2025-12-17 160128.png	image/png	278835	2880	1824	2025-12-20 13:29:58.836031+00	2025-12-20 13:29:58.836031+00	630de309-32f3-6689-f508-aa0b9828a98c	\N	\N	7c4e35e7-65f9-8dfa-73ec-23b46516edc6
d0e52ade-1c80-474e-839a-947673aaf570	uploads/media/dc66ad9a-8bc5-4556-9860-aeab96211fa3/1771484132890-25db243aa935a-_2026-02-14_111032.png	ØªØµÙÛØ± ØµÙØ­Ù 2026-02-14 111032.png	image/png	479081	\N	\N	2026-02-19 06:55:32.894667+00	2026-02-19 06:55:32.894667+00	\N	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
7c4fe764-f01b-4a05-8ad2-5a8ee2c34946	uploads/media/dc66ad9a-8bc5-4556-9860-aeab96211fa3/1771486155674-c1e85a125ee88-_2026-02-14_111032.png	ØªØµÙÛØ± ØµÙØ­Ù 2026-02-14 111032.png	image/png	479081	\N	\N	2026-02-19 07:29:15.677901+00	2026-02-19 07:29:15.677901+00	\N	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
f61d3ca5-9aa2-4157-8c31-5fab43454f6e	uploads/media/dc66ad9a-8bc5-4556-9860-aeab96211fa3/1771497725148-24551b62345f2-default-logo.png	default-logo.png	image/png	38901	\N	\N	2026-02-19 10:42:05.151603+00	2026-02-19 10:42:05.151603+00	\N	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
07ce35e4-3dd3-4a7d-9f39-a8ed6653ee24	uploads/media/dc66ad9a-8bc5-4556-9860-aeab96211fa3/1771497730199-3730a53e45aa-logo.png	logo.png	image/png	3585	\N	\N	2026-02-19 10:42:10.201704+00	2026-02-19 10:42:10.201704+00	\N	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
f3541929-862f-4379-b5b9-d7e60b408ae3	uploads/media/dc66ad9a-8bc5-4556-9860-aeab96211fa3/1771609843821-96c5b07617f7e-logo.svg	logo.svg	image/svg+xml	3193	\N	\N	2026-02-20 17:50:43.823624+00	2026-02-20 17:50:43.823624+00	\N	ticket_messages	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
95585ec0-3d0a-487b-bdaa-06262ba3ffbd	uploads/media/f04fb725-d8b4-43f1-811d-8267e8761430/1771622791160-f86743082678f-logo.svg	logo.svg	image/svg+xml	3193	\N	\N	2026-02-20 21:26:31.164171+00	2026-02-20 21:26:31.164171+00	\N	ticket_messages	\N	f04fb725-d8b4-43f1-811d-8267e8761430
b4778893-0c7f-4393-b981-132821f88dc9	uploads/media/f04fb725-d8b4-43f1-811d-8267e8761430/1771702627206-f7c71338cb469-logo.png	logo.png	image/png	3585	\N	\N	2026-02-21 19:37:07.209048+00	2026-02-21 19:37:07.209048+00	\N	\N	\N	f04fb725-d8b4-43f1-811d-8267e8761430
09f0fdc7-8c33-4ae1-b626-c5cbdff89ba0	uploads/media/f04fb725-d8b4-43f1-811d-8267e8761430/1771703130512-4ea9bf3f58c7c-logo.svg	logo.svg	image/svg+xml	3193	\N	\N	2026-02-21 19:45:30.514856+00	2026-02-21 19:45:30.514856+00	\N	\N	\N	f04fb725-d8b4-43f1-811d-8267e8761430
61539ee7-d7f0-45df-b8ea-403d8f2ab520	uploads/media/f04fb725-d8b4-43f1-811d-8267e8761430/1771703168552-3c8bf344037ad-logo.png	logo.png	image/png	3585	\N	\N	2026-02-21 19:46:08.554352+00	2026-02-21 19:46:08.554352+00	\N	\N	\N	f04fb725-d8b4-43f1-811d-8267e8761430
1656f135-83e2-44bd-aa14-9146f07fd91e	uploads/media/f04fb725-d8b4-43f1-811d-8267e8761430/1771703845284-5aca9b71023b7-logo.png	logo.png	image/png	3585	\N	\N	2026-02-21 19:57:25.287394+00	2026-02-21 19:57:25.287394+00	\N	\N	\N	f04fb725-d8b4-43f1-811d-8267e8761430
b2c29c8c-8921-4d16-9157-3f71a6aeb007	uploads/media/f04fb725-d8b4-43f1-811d-8267e8761430/1771703906838-485c766adb1ee-logo.png	logo.png	image/png	3585	\N	\N	2026-02-21 19:58:26.839633+00	2026-02-21 19:58:26.839633+00	\N	\N	\N	f04fb725-d8b4-43f1-811d-8267e8761430
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.members (role, email, member_code, full_name, father_name, national_id, mobile, phone, address, birth_date, business_name, category, member_status, otp_code, otp_expires, license_number, license_issue_date, license_expire_date, license_image, national_card_image, id_card_image, company_license_image, member_image, company_name, registration_number, created_at, updated_at, auth_user_id, owner_id, permissions, id) FROM stdin;
warehouse-manager	\N	1010	مجتبی توکلی	\N	\N	09121213906	\N	\N	\N	حامد ۱۱۰	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-22 14:46:20.098394+00	2026-02-22 14:46:20.098394+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	062577bc-23b6-4c0f-9641-0b5d1e7d4cbe
warehouse-manager	\N	1011	پرویز جولایی	\N	\N	09123035645	\N	\N	\N	\N	warehouse	active	862129	2026-02-23 16:28:23.710456+00	\N	\N	\N	\N	\N	\N	\N	\N	جولایی	\N	2026-02-22 14:47:22.261483+00	2026-02-23 16:26:23.710456+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	4a8e5835-42cc-4d7c-b1f7-37e9ca76867d
warehouse-manager	\N	1003	تست انبار	\N	\N	09121137675	\N	\N	\N	تهران فلز	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-20 18:44:15.204403+00	2026-02-22 13:49:28.267779+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	f04fb725-d8b4-43f1-811d-8267e8761430
warehouse-manager	\N	1004	ابراهیمی	\N	\N	09121214476	\N	\N	\N	آریان	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-22 10:22:45.329327+00	2026-02-22 12:21:15.583661+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	154dd939-db03-477b-9cbb-64fc7f3ab632
warehouse-manager	\N	1012	آیدین اعتماد مقدم	\N	\N	09120618479	\N	\N	\N	انبار دلتا	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-22 14:57:38.204612+00	2026-02-23 08:09:28.096001+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	b5021974-30e8-41d3-acec-126d65f18aef
warehouse-manager	\N	1013	قنقره	\N	\N	09126806131	\N	\N	\N	انبار نور ۲	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-22 15:15:13.983039+00	2026-02-22 15:20:20.810167+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	0eea2ebb-1509-4c6c-bf5c-700059af00ee
warehouse-manager	\N	1005	محمد رضا نصراله زاده	\N	\N	09123786606	\N	\N	\N	110 رضا	warehouse	active	467459	2026-02-22 10:39:10.439447+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-22 10:24:26.879001+00	2026-02-22 12:21:15.589686+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	59887725-ed67-4e9d-a9ef-a58643927dba
warehouse-manager	\N	1014	احمد اکبری	\N	\N	09121154572	\N	\N	\N	انبار اکبری 2	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-22 17:10:53.814219+00	2026-02-22 17:10:53.814219+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	6db94b4c-c2ba-4b1f-a0b5-cbcab397fb0b
warehouse-manager	\N	1006	رضا ابراهیمی	\N	\N	09121893071	\N	\N	\N	\N	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-22 10:27:53.720191+00	2026-02-23 11:11:05.216065+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	8aac9fa5-23f9-42a8-a993-1c6d3a13e9e3
warehouse-manager	\N	1015	علی فتحی	\N	\N	09133010124	\N	\N	\N	انبار فتحی	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-23 18:49:07.866227+00	2026-02-24 03:28:10.767498+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	e29c3318-c198-46ef-9d9c-1d163b90f05e
warehouse-manager	\N	1007	علی اصغر باقری	\N	\N	09122241940	\N	\N	\N	کربلایی	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-22 10:30:25.521548+00	2026-02-22 12:21:15.601433+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	73edc288-9fc5-4533-9a44-573d8885ee54
warehouse-manager	\N	1016	یزدان موسوی	\N	\N	09124894001	\N	\N	\N	نوین کالا	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-23 19:01:48.936686+00	2026-02-23 19:50:50.976406+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	656ecd50-d476-489c-936c-3b36f501fc84
warehouse-manager	\N	1008	میرداداشی امیر	\N	\N	09196028300	\N	\N	\N	انبار شرکا	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-22 10:31:36.247003+00	2026-02-22 12:21:15.608038+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	b4a5c9e2-9ef2-4157-a512-7bb2f082ee6c
warehouse-manager	\N	1009	کمالی	\N	\N	09032225755	\N	\N	\N	انبار بین الملل	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-22 10:48:07.714532+00	2026-02-22 12:21:15.614138+00	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{}	9959c0fe-fa21-477b-a2cf-8c88480e2594
owner	\N	1001	مدیر سیستم	\N	98979879434	09123456789	\N	\N	\N	\N	warehouse	active	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-30 18:43:36.738135+00	2026-02-24 16:59:56.093701+00	296d96ed-280c-4fd3-b4cf-062c0771d34a	\N	{}	dc66ad9a-8bc5-4556-9860-aeab96211fa3
\.


--
-- Data for Name: opening_balance_banks; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.opening_balance_banks (id, opening_balance_id, bank_id, amount, description, created_at) FROM stdin;
\.


--
-- Data for Name: opening_balance_cashes; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.opening_balance_cashes (id, opening_balance_id, cash_id, amount, description, created_at) FROM stdin;
\.


--
-- Data for Name: opening_balance_customers; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.opening_balance_customers (id, opening_balance_id, customer_id, balance_type, amount, description, created_at) FROM stdin;
\.


--
-- Data for Name: opening_balance_items; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.opening_balance_items (id, opening_balance_id, product_id, owner_id, qty, weight, batch_no, description, created_at) FROM stdin;
\.


--
-- Data for Name: opening_balances; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.opening_balances (id, member_id, description, created_by, is_locked, created_at, section) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (id, code, module, action, title, created_at) FROM stdin;
c43c2429-2131-4b34-8fba-af951d48fb75	dashboard.view	dashboard	view	مشاهده داشبورد	2026-02-07 19:27:41.663604+00
46601e93-c28c-4488-b65c-252bdf9e92fc	clearance.print	clearance	print	چاپ حواله خروج	2026-02-07 19:27:41.663604+00
21c5d345-00c5-4a98-ab21-fefc75f813c8	product.view	product	view	مشاهده کالا	2026-02-07 19:27:41.663604+00
f2fd3178-a8bc-4be2-8385-03f511456730	product.create	product	create	ایجاد کالا	2026-02-07 19:27:41.663604+00
b427d55f-e672-49e6-b834-30c62645f4bb	product.edit	product	edit	ویرایش کالا	2026-02-07 19:27:41.663604+00
4ccd9a83-45a0-4d41-8743-279df9de9c3c	product.delete	product	delete	حذف کالا	2026-02-07 19:27:41.663604+00
0083d40b-de0d-4448-8ea5-c6023f393366	inventory.adjust	inventory	edit	اصلاح موجودی	2026-02-07 19:27:41.663604+00
36b544a4-f50a-42fe-b36f-4c9aa1126f5f	financial_doc.view	financial	view	مشاهده اسناد مالی	2026-02-07 19:27:41.663604+00
efaf88a4-b32f-40b8-9652-bb0f19e11eee	financial_doc.create	financial	create	ثبت سند مالی	2026-02-07 19:27:41.663604+00
01da3b3c-8022-4f2b-b0ce-080643af7e1e	member.view	member	view	مشاهده اعضا	2026-02-09 09:15:54.110582+00
2ec8863d-1ff1-4018-adf1-2ab1c618e0c5	member.create	member	create	ایجاد عضو جدید	2026-02-09 09:15:54.110582+00
aeae1ece-6b72-4e96-aff4-b4ea7bc994b1	member.edit	member	edit	ویرایش اعضا	2026-02-09 09:15:54.110582+00
6ee9db8e-6dbf-4892-b009-9d23efe410d8	member.delete	member	delete	حذف اعضا	2026-02-09 09:15:54.110582+00
1e8686a7-3fb4-446b-a266-bea3a5d66935	member.manage	member	manage	مدیریت پرسنل	2026-02-09 09:15:54.110582+00
86ae6499-1a91-4336-aff9-f535b16241e8	customer.view	customer	view	مشاهده مشتریان	2026-02-09 09:15:54.110582+00
9b551a7f-e222-47d6-94d5-d89047c50cf0	customer.create	customer	create	ایجاد مشتری جدید	2026-02-09 09:15:54.110582+00
541b0257-de61-4e30-916e-f7d03f4e7541	customer.edit	customer	edit	ویرایش مشتریان	2026-02-09 09:15:54.110582+00
d636e730-3a86-438d-aacd-06b8c94db9b3	customer.delete	customer	delete	حذف مشتریان	2026-02-09 09:15:54.110582+00
8baa4517-76fd-42f6-b3d8-8359d804de82	customer.export	customer	export	خروجی مشتریان	2026-02-09 09:15:54.110582+00
bf43cd27-51cc-4ce4-85c6-a5e2b5682cb0	inventory.view	inventory	view	مشاهده کالاها	2026-02-07 19:27:41.663604+00
49483f8b-00fa-43eb-816d-a9ccb2ffad84	inventory.create	inventory	create	ایجاد کالا	2026-02-09 09:15:54.110582+00
7929245b-f195-4ce6-a5a7-d244a12d3cfe	inventory.edit	inventory	edit	ویرایش کالا	2026-02-09 09:15:54.110582+00
f7aa82b6-7313-4020-9cb8-25456d550634	inventory.delete	inventory	delete	حذف کالا	2026-02-09 09:15:54.110582+00
1af4fa9d-c1e4-41e3-8d02-3c81bf97bd96	inventory.export	inventory	export	خروجی کالاها	2026-02-09 09:15:54.110582+00
afb85844-0f71-4041-8914-db0700409691	receipt.view	receipt	view	مشاهده رسیدها	2026-02-07 19:27:41.663604+00
0b286a7b-b307-44c1-ad35-d1f7feb699f5	receipt.create	receipt	create	ثبت رسید جدید	2026-02-07 19:27:41.663604+00
ac61565d-02c0-494d-9c87-7bc317bc1351	receipt.edit	receipt	edit	ویرایش رسید	2026-02-07 19:27:41.663604+00
1c5950c1-0307-47fa-861b-e2e0413b43f2	receipt.delete	receipt	delete	حذف رسید	2026-02-07 19:27:41.663604+00
76f1034c-e8a3-4a9b-9aa7-ec6aab9ac28a	receipt.approve	receipt	approve	تایید رسید	2026-02-09 09:15:54.110582+00
4daa2a00-a265-46a6-89bf-58bfb5586a59	receipt.print	receipt	print	چاپ رسید	2026-02-07 19:27:41.663604+00
e73d80d7-e6aa-4d90-a375-74198a915dab	loading.view	loading	view	مشاهده بارگیری	2026-02-09 09:15:54.110582+00
431a08bd-b8f7-40b6-9f3a-5211caf6df35	loading.create	loading	create	ثبت بارگیری	2026-02-09 09:15:54.110582+00
53f731d2-b433-4f8f-85a8-bf435d35517b	loading.edit	loading	edit	ویرایش بارگیری	2026-02-09 09:15:54.110582+00
8f708164-8b45-4b65-9d6c-96b8f3281b35	loading.delete	loading	delete	حذف بارگیری	2026-02-09 09:15:54.110582+00
89b55114-cd36-4022-aebf-6858974e5e7e	loading.approve	loading	approve	تایید بارگیری	2026-02-09 09:15:54.110582+00
6f885087-27ae-4bea-b039-284bc2c4485b	exit.view	exit	view	مشاهده خروج	2026-02-09 09:15:54.110582+00
92ec0bbb-891a-4371-9e7a-d847e634f34e	exit.create	exit	create	ثبت خروج	2026-02-09 09:15:54.110582+00
f179c009-11fa-46df-9106-4723aba54e89	exit.edit	exit	edit	ویرایش خروج	2026-02-09 09:15:54.110582+00
4afbdaa3-f760-4e41-a907-225a597b595a	exit.delete	exit	delete	حذف خروج	2026-02-09 09:15:54.110582+00
58573c2b-75a9-4eb4-8306-d0f72cdd50d7	exit.approve	exit	approve	تایید خروج	2026-02-09 09:15:54.110582+00
805d7f41-29ed-45b5-9d34-e53b7a102c11	clearance.view	clearance	view	مشاهده ترخیص	2026-02-07 19:27:41.663604+00
9aebdf5c-dfab-4253-9022-e0b526360fc2	clearance.create	clearance	create	ثبت ترخیص	2026-02-07 19:27:41.663604+00
096016a4-fa6d-47d5-9ad6-a1c88470adf4	clearance.edit	clearance	edit	ویرایش ترخیص	2026-02-07 19:27:41.663604+00
5c94fdce-7eb0-4527-ba02-21322ece115e	clearance.delete	clearance	delete	حذف ترخیص	2026-02-09 09:15:54.110582+00
724b9ccb-0077-4c04-bafc-1bcf57b08497	clearance.approve	clearance	approve	تایید ترخیص	2026-02-07 19:27:41.663604+00
131404e6-3cd1-4f34-ba23-2a35a131edda	accounting.view	accounting	view	مشاهده حسابداری	2026-02-09 09:15:54.110582+00
db21141a-73d3-4333-88a9-e565c6f3daf9	accounting.create	accounting	create	ثبت سند حسابداری	2026-02-09 09:15:54.110582+00
e306e30f-0af9-4e4e-abb5-44f60b8f2914	accounting.edit	accounting	edit	ویرایش سند	2026-02-09 09:15:54.110582+00
cb4d42de-3790-43eb-a728-1707cf3d3be1	accounting.delete	accounting	delete	حذف سند	2026-02-09 09:15:54.110582+00
0b182b05-3319-4f43-8a85-8d6a4e26aec1	accounting.approve	accounting	approve	تایید سند	2026-02-09 09:15:54.110582+00
bb39c233-0cad-4b7a-bbc8-e947d9fae0f1	accounting.reports	accounting	reports	گزارشات مالی	2026-02-09 09:15:54.110582+00
6e813294-a0d0-4900-a760-ddbd491ee71c	accounting.treasury	accounting	treasury	خزانه‌داری	2026-02-09 09:15:54.110582+00
29049644-0de4-4e80-b381-a458f2d90c88	rent.list	rent	list	لیست قراردادها	2026-02-09 09:15:54.110582+00
af7e3226-5c78-4b8f-a3e4-c5b98944ec08	rent.create	rent	create	ثبت قرارداد	2026-02-09 09:15:54.110582+00
02789f19-af19-41ec-b97e-ad446312e76a	rent.edit	rent	edit	ویرایش قرارداد	2026-02-09 09:15:54.110582+00
b36d89c6-a2e8-41af-8df8-1fdae2200b60	rent.delete	rent	delete	حذف قرارداد	2026-02-09 09:15:54.110582+00
12906eb5-a032-4700-abe3-aab5a179097a	client.portal	client	portal	دسترسی به پرتال مشتری	2026-02-09 09:15:54.110582+00
957726fb-613f-4339-9977-025083bbb924	settings.roles.view	settings.roles	view	مشاهده نقش‌ها	2026-02-09 09:15:54.110582+00
ccb21799-1581-431c-8156-bd00df1e9ffd	settings.roles.create	settings.roles	create	ایجاد نقش	2026-02-09 09:15:54.110582+00
1b32b6d5-abd9-4c35-ace7-0028a1eda243	settings.roles.edit	settings.roles	edit	ویرایش نقش	2026-02-09 09:15:54.110582+00
62f56f66-5ac6-4f08-9009-6063c0be2e50	settings.roles.delete	settings.roles	delete	حذف نقش	2026-02-09 09:15:54.110582+00
384ef955-7a75-4352-a303-e0c562cddd34	settings.permissions.view	settings.permissions	view	مشاهده مجوزها	2026-02-09 09:15:54.110582+00
c50d40f9-950d-4688-8bc6-25477ea34fcf	settings.permissions.create	settings.permissions	create	ایجاد مجوز	2026-02-09 09:15:54.110582+00
52bd01a5-c556-4469-94d0-dd8d132004a0	settings.user-roles.view	settings.user-roles	view	مشاهده نقش کاربران	2026-02-09 09:15:54.110582+00
50408ef2-686f-469c-906e-2a3389b945f8	settings.user-roles.create	settings.user-roles	create	تخصیص نقش	2026-02-09 09:15:54.110582+00
fa0133d6-0ad1-4e03-9a04-c8b1014c7a8c	settings.user-roles.delete	settings.user-roles	delete	حذف نقش کاربر	2026-02-09 09:15:54.110582+00
9a620b94-7c29-4965-9949-900ad39b29b6	settings.ui-forms.view	settings.ui-forms	view	مشاهده فرم‌ها	2026-02-09 09:15:54.110582+00
277e8d68-e5e0-4f80-8bdf-055d9437cbeb	settings.ui-forms.create	settings.ui-forms	create	ایجاد فرم	2026-02-09 09:15:54.110582+00
95859a6f-e928-4cec-99be-595a593afc76	settings.ui-forms.edit	settings.ui-forms	edit	ویرایش فرم	2026-02-09 09:15:54.110582+00
9fc9a646-1d8f-4b86-ab0f-a58ce4fa870c	unit.view	unit	view	مشاهده واحدها	2026-02-10 05:21:23.823764+00
d2bd6033-8796-4875-b337-772bd92ec0ec	category.view	category	view	مشاهده دسته‌بندی	2026-02-10 05:21:23.823764+00
22260a49-7b09-49dc-b102-6d419dbdb769	treasury.view	treasury	view	مشاهده خزانه	2026-02-10 05:21:23.823764+00
de28accd-8c2f-4f1b-959b-0e7bc08b82f1	calendar.view	calendar	view	مشاهده تقویم	2026-02-20 19:38:23.646895+00
5fb152f0-9b40-4b79-bf05-39efdf3b573e	calendar.create	calendar	create	ثبت رویداد تقویم	2026-02-20 19:38:23.653789+00
da3cb40b-568c-4da3-9ffd-19038be61f49	settings.warehouse	settings	manage	تنظیمات انبار	2026-02-20 19:38:23.660655+00
e227a9fc-e968-44a3-9b53-c1cc0cb8e3bb	support.view	support	view	مشاهده تیکت‌ها	2026-02-20 19:38:23.666631+00
448fa895-1b3c-4a07-a64b-b32bb3fc703d	support.create	support	create	ثبت تیکت جدید	2026-02-20 19:38:23.673199+00
\.


--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_categories (id, name, slug, parent_id, description, image_id, is_active, sort_order, storage_cost, loading_cost, created_at, updated_at, fee_type, fee_amount, calc_method, member_id) FROM stdin;
55d4d060-40fa-24f8-f9c3-2543030df928	میلگرد	rebar	\N		\N	t	0	2000	3500	2025-12-08 19:52:49.534558+00	2026-02-16 09:42:04.591617+00	weight	0	weight	\N
be227a08-b801-491a-80fd-1a3da4afec0b	میلگرد آجدار	-	55d4d060-40fa-24f8-f9c3-2543030df928		\N	t	0	2000	3500	2026-02-20 20:49:23.338067+00	2026-02-20 20:49:23.338067+00	weight	0	weight	f04fb725-d8b4-43f1-811d-8267e8761430
\.


--
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_images (id, product_id, media_id, created_at) FROM stdin;
\.


--
-- Data for Name: product_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_units (id, name, symbol, code, description, is_active, created_at, updated_at) FROM stdin;
45cc542c-5ab3-4c63-a8f8-97886d909b76	کیلوگرم	kg	\N		t	2026-02-20 20:36:37.12085+00	2026-02-20 20:36:37.12085+00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, sku, category_id, unit_id, min_stock, max_stock, location, price, cost_price, description, specifications, barcode, batch_number, expire_date, member_id, is_active, notes, created_at, updated_at, national_id, national_title, owner_id, image_url, quantity, nwms_good_id, nwms_measurement_unit, nwms_production_type) FROM stdin;
4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	hvav	666	55d4d060-40fa-24f8-f9c3-2543030df928	45cc542c-5ab3-4c63-a8f8-97886d909b76	0	\N	\N	0	0	\N	\N	\N	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	t	\N	2026-01-29 21:01:15.346988+00	2026-02-20 20:38:23.353882+00	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	0	\N	\N	1
55cd5b7a-2898-4588-90b5-c8de22219328	میلگرد 14 نیشابور	7656	be227a08-b801-491a-80fd-1a3da4afec0b	45cc542c-5ab3-4c63-a8f8-97886d909b76	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	f04fb725-d8b4-43f1-811d-8267e8761430	t	\N	2026-02-20 20:54:58.285904+00	2026-02-20 20:54:58.285904+00	\N	\N	f04fb725-d8b4-43f1-811d-8267e8761430	\N	0	\N	\N	1
fe1bc505-0155-49cb-ab48-3471beddc36c	بلبیرینگ	3543535	55d4d060-40fa-24f8-f9c3-2543030df928	45cc542c-5ab3-4c63-a8f8-97886d909b76	1277	\N	\N	\N	\N	\N	\N	\N	\N	\N	b5021974-30e8-41d3-acec-126d65f18aef	t	\N	2026-02-23 08:11:44.208508+00	2026-02-23 08:11:44.208508+00	\N	\N	b5021974-30e8-41d3-acec-126d65f18aef	\N	0	\N	\N	2
\.


--
-- Data for Name: receipt_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.receipt_items (id, receipt_id, owner_id, is_parent, parent_id, parent_row, row_code, national_product_id, product_description, count, production_type, is_used, is_defective, weights_full, weights_empty, weights_net, weights_origin, weights_diff, dim_length, dim_width, dim_thickness, heat_number, bundle_no, brand, order_no, depo_location, description_notes, created_at, updated_at, product_id, member_id) FROM stdin;
b8966671-78f1-40f2-adb2-089e918ff2f2	e9652b00-572d-430b-841f-ae6ce0569f02	87a73478-b42b-4e0a-9079-430c290190ae	f	\N	\N	\N	\N	\N	9000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	2026-02-04 21:15:10.402437+00	2026-02-04 21:15:10.402437+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
e69754ea-7e68-47e4-b7b2-371097ec34b3	5633c67d-b64b-4e31-a2e5-42e101871075	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	\N	\N	\N	\N	5000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N			2026-02-05 16:47:26.172448+00	2026-02-05 16:47:26.172448+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
10cf08de-faac-484f-8706-6b9836b15772	717cf9a1-f02a-49d2-9c9c-58b37b5611ef	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	\N	\N	\N	\N	9000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N			2026-02-05 16:56:29.396555+00	2026-02-05 16:56:29.396555+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
d629cbcc-3c75-4cf1-b391-61529c6aea18	da7f571a-944d-4ecc-aec2-0e019a0ff86e	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	\N	\N	\N	\N	37400	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N			2026-02-05 17:02:49.721898+00	2026-02-05 17:02:49.721898+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
48bb20e1-7520-4061-afa9-c760f3f7aa7c	0a70b5fd-712e-4951-be05-9ff9f11a2c50	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	\N	\N	\N	\N	90000	domestic	f	f	0	0	0	0	0	0	0	0							2026-02-06 11:09:01.709743+00	2026-02-06 11:09:01.709743+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
e7d46500-bb3a-4a78-b233-2c58a89e8cfe	85cb12a4-2b5d-47c6-8e09-e403d8b95ed3	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	\N	\N	\N	\N	7800	domestic	f	f	0	0	0	0	0	0	0	0							2026-02-06 21:11:10.992392+00	2026-02-06 21:11:10.992392+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
4511e308-323d-4092-ba24-52a80eeb64c8	b5bbe9a9-f9c8-4db8-b38e-b704f2e7dcd6	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	\N	\N	\N	\N	900	domestic	f	f	20000	12900	7100	7200	-100	0	0	0							2026-02-06 21:12:53.022927+00	2026-02-06 21:12:53.022927+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
c1a59798-724e-42e7-83e9-27baa10d0d9b	d660fc83-19bd-4aaf-86f9-4631c98cbe83	87a73478-b42b-4e0a-9079-430c290190ae	f	\N	\N	\N	\N	\N	0	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-06 21:16:31.599854+00	2026-02-06 21:16:31.599854+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
17a83bb5-4e71-4629-b9ca-605f2925b4f7	bb2b98c5-52d7-4f08-a9fd-eb469330406d	87a73478-b42b-4e0a-9079-430c290190ae	f	\N	\N	\N	\N	\N	78000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-06 21:28:20.776679+00	2026-02-06 21:28:20.776679+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
78d129f3-8fd0-4a6c-87f0-aac08aed8c37	8052c1e1-7298-4aa1-9c67-84e530db811f	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	\N	\N	\N	\N	230000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-07 09:03:45.734652+00	2026-02-07 09:03:45.734652+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
7c3c4aec-8ea8-4abb-a735-627d3f4975c0	a28e05d6-5125-410d-806e-78727a13a79a	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	\N	\N	\N	\N	12300	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-07 10:12:36.184392+00	2026-02-07 10:12:36.184392+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
de2d441d-df93-488b-8186-edd3f3d6485d	f6648e63-9e53-47c5-8956-fb0bdff2619c	87a73478-b42b-4e0a-9079-430c290190ae	f	\N	\N	\N	\N	\N	32000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-07 10:37:27.038797+00	2026-02-07 10:37:27.038797+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
e17d9e76-df18-493b-a55a-3aa22b8b7573	6db5da15-8c1b-44ae-a3d3-d841bdf059e0	87a73478-b42b-4e0a-9079-430c290190ae	f	\N	\N	\N	\N	\N	23000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-07 10:40:46.533062+00	2026-02-07 10:40:46.533062+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
b49488d3-608a-45f3-9497-ff2c631d0453	953c17ac-6674-4b37-a916-204f37e58b0a	87a73478-b42b-4e0a-9079-430c290190ae	f	\N	\N	\N	\N	\N	34000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-07 10:51:48.665069+00	2026-02-07 10:51:48.665069+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
64824ce8-fb05-4aec-9721-38e6f3df869f	911a1cc7-ee34-4158-aa53-d030d2d795c9	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	\N	\N	\N	\N	20000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-07 11:31:20.222831+00	2026-02-07 11:31:20.222831+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
3a43e8b6-83d3-42de-aeab-c61bbf3bf27e	244cc114-fe74-41df-ae16-1d6dd8e6bf37	87a73478-b42b-4e0a-9079-430c290190ae	f	\N	\N	\N	\N	\N	8000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-07 11:38:51.46177+00	2026-02-07 11:38:51.46177+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
001655fc-8d7f-41d7-b3d8-8522a1c14167	b5f1409a-7275-401d-8d06-36dfa0e3a924	87a73478-b42b-4e0a-9079-430c290190ae	f	\N	\N	\N	\N	\N	9000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-07 12:47:52.125367+00	2026-02-07 12:47:52.125367+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
47e5fdd1-d1c7-412e-879c-d8b067f37cc3	d21b45bc-c54f-4849-bfaa-699892a3c828	87a73478-b42b-4e0a-9079-430c290190ae	f	\N	\N	\N	\N	\N	8900	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-07 18:26:48.188699+00	2026-02-07 18:26:48.188699+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
c97aef67-1007-4e30-8827-9edb9b88693f	d3902200-1b65-4dd8-a2e0-c2a177264009	87a73478-b42b-4e0a-9079-430c290190ae	f	\N	\N	\N	\N	\N	67000	domestic	f	f	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N		2026-02-07 18:33:50.957934+00	2026-02-07 18:33:50.957934+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
27f20fa1-cdbc-4ab8-b34a-0d5110140ad8	66c2ef00-b14e-475d-8a37-67eeaae7aa2e	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	\N	\N	\N	\N	500	domestic	f	f	0	0	0	0	0	0	0	0							2026-02-14 13:28:14.081727+00	2026-02-14 13:28:14.081727+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
bfe9ce22-b86d-40cc-87ef-01f9d026160e	399918ce-112c-4664-99a2-286bef2ad968	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	\N	\N	\N	\N	20	domestic	f	f	0	0	0	0	0	0	0	0							2026-02-15 11:32:55.602428+00	2026-02-15 11:32:55.602428+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
ad232135-5bfc-42a9-b1d6-bc70c58720c7	5d3697f3-918c-46d4-9878-fbbf91cb38af	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N			\N	\N	200	domestic	f	f	30000	12000	18000	17800	200	0	0	0							2026-02-15 13:17:29.02306+00	2026-02-15 13:17:29.02306+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
44c7e283-fcbd-4583-a79b-c07186aa32ae	ab7555ba-4d00-4c33-bca0-521ed5dac84a	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N		100	\N	\N	40	domestic	f	f	34500	12000	22500	22400	100	0	0	0							2026-02-15 13:29:36.725438+00	2026-02-15 13:29:36.725438+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
2926dc6a-dff3-4c71-b012-7a0ba4500988	8f12a96b-f10d-4006-a32f-44a142e243d6	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N			\N	\N	300	domestic	f	f	24500	11000	13500	13450	50	0	0	0							2026-02-20 09:33:28.110634+00	2026-02-20 09:33:28.110634+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
84197ba0-d1e4-477c-99fd-b954f8129177	9a5fbd2f-79a0-4f11-a352-b64f5a43514a	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	110/14		\N	\N	6000	domestic	f	f	56000	45000	11000	11300	-300	0	0	0							2026-02-20 10:05:39.142553+00	2026-02-20 10:05:39.142553+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
2b278408-9076-4426-a679-12854a10f1f0	e345955f-2c20-485d-aef1-9f6aac413284	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	110/11		\N	\N	40	domestic	f	f	24300	11200	13100	13000	100	0	0	0							2026-02-20 10:21:06.263245+00	2026-02-20 10:21:06.263245+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
866a67c6-9096-41a8-a10a-39a40a9cc9a4	05bf3439-cdfa-43c9-9768-32d1aba46130	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	110/11		\N	\N	6000	domestic	f	f	56000	12000	44000	44100	-100	0	0	0							2026-02-20 10:36:24.109847+00	2026-02-20 10:36:24.109847+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
fefbc62e-dfd8-422f-8b96-e8ff3aafedc5	34dd857c-84d8-479f-b997-58b46e9d67e2	2db3438c-0865-4cf1-955e-d9197e63061f	f	\N	110/14		\N	\N	12	domestic	f	f	36500	11300	25200	25150	50	0	0	0							2026-02-21 08:33:30.622052+00	2026-02-21 08:33:30.622052+00	55cd5b7a-2898-4588-90b5-c8de22219328	f04fb725-d8b4-43f1-811d-8267e8761430
88d4fc2b-dee1-42ab-adac-e815fe4d6065	3f3a9111-12c1-40c4-8450-03de23e03923	d300ce05-8008-4bb0-95f1-2eb231fb4346	f	\N	110/11		\N	\N	23	domestic	f	f	32000	12000	20000	19800	200	0	0	0							2026-02-23 12:14:34.546331+00	2026-02-23 12:14:34.546331+00	4eb1fc4e-c643-2f02-0342-2bcc81cde3b4	dc66ad9a-8bc5-4556-9860-aeab96211fa3
\.


--
-- Data for Name: receipts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.receipts (id, doc_type_id, receipt_no, member_id, status, doc_date, ref_type, ref_barnameh_number, ref_barnameh_date, ref_barnameh_tracking, ref_petteh_number, ref_havale_number, ref_production_number, owner_id, deliverer_id, driver_name, driver_national_id, driver_birth_date, plate_iran_right, plate_mid3, plate_letter, plate_left2, load_cost, unload_cost, warehouse_cost, tax, return_freight, loading_fee, misc_cost, misc_description, payment_by, card_number, account_number, bank_name, payment_owner_name, tracking_code, created_at, updated_at, driver_phone, discharge_date, cost_load, cost_unload, cost_warehouse, cost_tax, cost_return_freight, cost_loading_fee, cost_misc, cost_misc_desc, payment_amount, payment_source_id, payment_source_type, payment_tracking_code, nwms_id, nwms_status) FROM stdin;
e9652b00-572d-430b-841f-ae6ce0569f02	22bdf2b7-75c6-2674-8248-96d26a207d63	1001	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-04	none		\N		\N	\N	\N	87a73478-b42b-4e0a-9079-430c290190ae	\N			\N			ع		0	0	0	0	0	0	0		customer						2026-02-04 21:15:10.402437+00	2026-02-04 21:15:10.402437+00		2026-02-05	0	0	0	0	0	0	0		0	\N	\N		\N	not_sent
5633c67d-b64b-4e31-a2e5-42e101871075	22bdf2b7-75c6-2674-8248-96d26a207d63	1002	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-05	barnameh	67567456	2026-02-05	9889798				d300ce05-8008-4bb0-95f1-2eb231fb4346	\N	اصغری	8767576556	\N	33	666	ط	55	89000000	5600000	0	0	0	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-05 16:47:26.172448+00	2026-02-05 16:47:26.172448+00		2026-02-05	89000000	5600000	0	0	0	0	0	\N	89000000	acf66379-03b0-775c-74df-8297c50bd6fe	cash	\N	\N	not_sent
717cf9a1-f02a-49d2-9c9c-58b37b5611ef	22bdf2b7-75c6-2674-8248-96d26a207d63	1003	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-05	barnameh	990	2026-02-05	54453				d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N	\N	\N	ع	\N	900000	6799999	0	0	0	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-05 16:56:29.396555+00	2026-02-05 16:56:29.396555+00		2026-02-05	900000	6799999	0	0	0	0	0	\N	90000000	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
da7f571a-944d-4ecc-aec2-0e019a0ff86e	22bdf2b7-75c6-2674-8248-96d26a207d63	1004	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-05	barnameh	22	2026-02-05	5555				d300ce05-8008-4bb0-95f1-2eb231fb4346	\N		867867565	\N	22	555	ض	44	3000000	120000000	450000	0	12000000	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-05 17:02:49.721898+00	2026-02-05 17:02:49.721898+00		2026-02-05	3000000	120000000	450000	0	12000000	0	0	\N	76000000	\N	\N	\N	\N	not_sent
0a70b5fd-712e-4951-be05-9ff9f11a2c50	22bdf2b7-75c6-2674-8248-96d26a207d63	1006	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-06	petteh	\N	\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N	66	999	پ	88	0	0	0	0	0	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-06 11:09:01.709743+00	2026-02-06 11:09:01.709743+00		2026-02-06	0	0	0	0	0	0	0	\N	90709999	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
85cb12a4-2b5d-47c6-8e09-e403d8b95ed3	22bdf2b7-75c6-2674-8248-96d26a207d63	1007	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-06	barnameh	\N	\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N	66	888	ث	99	0	0	0	0	0	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-06 21:11:10.992392+00	2026-02-06 21:11:10.992392+00		2026-02-07	0	0	0	0	0	0	0	\N	92400000	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
b5bbe9a9-f9c8-4db8-b38e-b704f2e7dcd6	22bdf2b7-75c6-2674-8248-96d26a207d63	1005	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-06	none	\N	\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N	22	777	پ	22	0	0	0	0	0	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-06 10:58:34.571459+00	2026-02-06 21:12:53.022927+00		2026-02-06	0	0	0	0	0	0	0	\N	0	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
d660fc83-19bd-4aaf-86f9-4631c98cbe83	22bdf2b7-75c6-2674-8248-96d26a207d63	1008	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-06	none	\N	\N	\N	\N	\N	\N	87a73478-b42b-4e0a-9079-430c290190ae	\N			\N	\N	\N	\N	\N	0	0	0	0	0	0	0	\N	customer	\N	\N	\N	\N		2026-02-06 21:16:31.599854+00	2026-02-06 21:16:31.599854+00		2026-02-07	0	0	0	0	0	0	0	\N	0	\N	\N	\N	\N	not_sent
bb2b98c5-52d7-4f08-a9fd-eb469330406d	22bdf2b7-75c6-2674-8248-96d26a207d63	1009	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-06	none	\N	\N	\N	\N	\N	\N	87a73478-b42b-4e0a-9079-430c290190ae	\N			\N	\N	\N	\N	\N	0	0	0	0	0	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-06 21:28:20.776679+00	2026-02-06 21:28:20.776679+00		2026-02-07	0	0	0	0	0	0	0	\N	8030000	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
8052c1e1-7298-4aa1-9c67-84e530db811f	22bdf2b7-75c6-2674-8248-96d26a207d63	1010	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-07	barnameh	\N	\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	87a73478-b42b-4e0a-9079-430c290190ae			\N	11	333	پ	22	0	0	0	0	0	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-07 09:03:45.734652+00	2026-02-07 09:03:45.734652+00		2026-02-07	0	0	0	0	0	0	0	\N	77960000	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
a28e05d6-5125-410d-806e-78727a13a79a	22bdf2b7-75c6-2674-8248-96d26a207d63	1011	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-07	barnameh	\N	\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	87a73478-b42b-4e0a-9079-430c290190ae			\N	11	444	ب	33	0	0	0	0	0	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-07 10:12:36.184392+00	2026-02-07 10:12:36.184392+00		2026-02-07	0	0	0	0	0	0	0	\N	2100	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
f6648e63-9e53-47c5-8956-fb0bdff2619c	22bdf2b7-75c6-2674-8248-96d26a207d63	1012	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-07	none	\N	\N	\N	\N	\N	\N	87a73478-b42b-4e0a-9079-430c290190ae	\N			\N	22	333	ت	44	0	0	0	0	0	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-07 10:37:27.038797+00	2026-02-07 10:37:27.038797+00		2026-02-07	0	0	0	0	0	0	0	\N	21000	\N	\N	\N	\N	not_sent
6db5da15-8c1b-44ae-a3d3-d841bdf059e0	22bdf2b7-75c6-2674-8248-96d26a207d63	1013	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-07	none	\N	\N	\N	\N	\N	\N	87a73478-b42b-4e0a-9079-430c290190ae	\N			\N	11	333	پ	44	0	0	0	0	0	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-07 10:40:46.533062+00	2026-02-07 10:40:46.533062+00		2026-02-07	0	0	0	0	0	0	0	\N	21	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
953c17ac-6674-4b37-a916-204f37e58b0a	22bdf2b7-75c6-2674-8248-96d26a207d63	1014	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-07	none	\N	\N	\N	\N	\N	\N	87a73478-b42b-4e0a-9079-430c290190ae	\N			\N	22	333	ث	33	4000	5000	20000	6000	0	30000	7000	\N	warehouse	\N	\N	\N	\N		2026-02-07 10:51:48.665069+00	2026-02-07 10:51:48.665069+00		2026-02-07	4000	5000	20000	6000	0	30000	7000	\N	72000	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
911a1cc7-ee34-4158-aa53-d030d2d795c9	22bdf2b7-75c6-2674-8248-96d26a207d63	1015	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-07	none	\N	\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N	22	777	پ	88	120000000	3000000	20000000	1200000	0	30000000	12399493	\N	warehouse	\N	\N	\N	\N		2026-02-07 11:31:20.222831+00	2026-02-07 11:31:20.222831+00		2026-02-07	120000000	3000000	20000000	1200000	0	30000000	12399493	\N	186599493	104c14e9-a833-1b7e-308f-00808f71e718	cash	\N	\N	not_sent
244cc114-fe74-41df-ae16-1d6dd8e6bf37	22bdf2b7-75c6-2674-8248-96d26a207d63	1016	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-07	none	\N	\N	\N	\N	\N	\N	87a73478-b42b-4e0a-9079-430c290190ae	\N			\N	22	999	ث	00	999990	788999	200000	340000	0	900000	876999	\N	warehouse	981786278627	\N	\N	\N	1212	2026-02-07 11:38:51.46177+00	2026-02-07 11:38:51.46177+00		2026-02-07	999990	788999	200000	340000	0	900000	876999	\N	4105988	51a89a63-cd63-def6-48ed-c2126854233a	bank	\N	\N	not_sent
b5f1409a-7275-401d-8d06-36dfa0e3a924	22bdf2b7-75c6-2674-8248-96d26a207d63	1017	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-07	none	\N	\N	\N	\N	\N	\N	87a73478-b42b-4e0a-9079-430c290190ae	\N			\N	66	777	ب	66	1200000	98377000	3400000	7289999	0	9830000	72888883	\N	warehouse	\N	\N	\N	\N		2026-02-07 12:47:52.125367+00	2026-02-07 12:47:52.125367+00		2026-02-07	1200000	98377000	3400000	7289999	0	9830000	72888883	\N	192985882	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
d21b45bc-c54f-4849-bfaa-699892a3c828	22bdf2b7-75c6-2674-8248-96d26a207d63	1018	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-07	none	\N	\N	\N	\N	\N	\N	87a73478-b42b-4e0a-9079-430c290190ae	\N			\N	88	555	ب	66	23450000	3890000	90000000	98560000	0	34000000	12300000	\N	warehouse	67567565	\N	\N	\N		2026-02-07 18:26:48.188699+00	2026-02-07 18:26:48.188699+00		2026-02-07	23450000	3890000	90000000	98560000	0	34000000	12300000	\N	262200000	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
d3902200-1b65-4dd8-a2e0-c2a177264009	22bdf2b7-75c6-2674-8248-96d26a207d63	1019	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-07	none	\N	\N	\N	\N	\N	\N	87a73478-b42b-4e0a-9079-430c290190ae	\N			\N	\N	\N	\N	\N	22222	77777777	9999999	89000000	0	1111111	560000	\N	warehouse	\N	\N	\N	\N		2026-02-07 18:33:50.957934+00	2026-02-07 18:33:50.957934+00		2026-02-07	22222	77777777	9999999	89000000	0	1111111	560000	\N	178471109	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
3d4b3880-02fb-4b07-b014-a4510c5fead5	22bdf2b7-75c6-2674-8248-96d26a207d63	1020	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-14	none		\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	d300ce05-8008-4bb0-95f1-2eb231fb4346			\N			ع		0	0	0	0	0	0	0		customer						2026-02-14 12:01:23.536574+00	2026-02-14 12:01:23.536574+00		2026-02-14	0	0	0	0	0	0	0		0	\N	\N		\N	not_sent
ac502f4d-38e3-4da9-82da-4139ef661bd0	22bdf2b7-75c6-2674-8248-96d26a207d63	1021	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-14	none		\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N			ع		0	0	0	0	0	0	0		customer						2026-02-14 12:04:17.386106+00	2026-02-14 12:04:17.386106+00		2026-02-14	0	0	0	0	0	0	0		0	\N	\N		\N	not_sent
66c2ef00-b14e-475d-8a37-67eeaae7aa2e	22bdf2b7-75c6-2674-8248-96d26a207d63	1022	dc66ad9a-8bc5-4556-9860-aeab96211fa3	draft	2026-02-14	none	\N	\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N			ع		0	0	0	0	0	0	0	\N	customer	\N	\N	\N	\N		2026-02-14 13:28:14.081727+00	2026-02-14 13:28:14.081727+00		2026-02-14	0	0	0	0	0	0	0	\N	0	\N	\N	\N	\N	not_sent
399918ce-112c-4664-99a2-286bef2ad968	22bdf2b7-75c6-2674-8248-96d26a207d63	1023	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-15	none	\N	\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N			ع		0	0	0	0	0	0	0	\N	customer	\N	\N	\N	\N		2026-02-15 11:32:55.602428+00	2026-02-15 11:32:55.602428+00		2026-02-15	0	0	0	0	0	0	0	\N	0	\N	\N	\N	\N	not_sent
5d3697f3-918c-46d4-9878-fbbf91cb38af	22bdf2b7-75c6-2674-8248-96d26a207d63	1024	dc66ad9a-8bc5-4556-9860-aeab96211fa3	draft	2026-02-15	none	\N	\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N			ع		0	0	0	0	0	0	0	\N	customer	\N	\N	\N	\N		2026-02-15 13:17:29.02306+00	2026-02-15 13:17:29.02306+00		2026-02-15	0	0	0	0	0	0	0	\N	0	\N	\N	\N	\N	not_sent
ab7555ba-4d00-4c33-bca0-521ed5dac84a	22bdf2b7-75c6-2674-8248-96d26a207d63	1025	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-15	none	\N	\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N			ع		0	0	0	0	0	0	0	\N	customer	\N	\N	\N	\N		2026-02-15 13:29:36.725438+00	2026-02-15 13:29:36.725438+00		2026-02-15	0	0	0	0	0	0	0	\N	0	\N	\N	\N	\N	not_sent
8f12a96b-f10d-4006-a32f-44a142e243d6	22bdf2b7-75c6-2674-8248-96d26a207d63	1026	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-20	none	\N	\N	\N	\N	\N	\N	d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N			ع		0	0	0	0	0	0	0	\N	warehouse	\N	\N	\N	\N		2026-02-20 09:33:28.110634+00	2026-02-20 09:33:28.110634+00		2026-02-20	0	0	0	0	0	0	0	\N	0	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	\N	\N	not_sent
9a5fbd2f-79a0-4f11-a352-b64f5a43514a	22bdf2b7-75c6-2674-8248-96d26a207d63	1027	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-20	barnameh	444343ص3	2026-02-20					d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N	11	555	غ	44	0	0	0	0	0	0	0	\N	warehouse	4343242424324323		ملی	راننده		2026-02-20 10:05:39.142553+00	2026-02-20 10:05:39.142553+00		2026-02-20	34000000	0	0	0	760000000	0	0		0	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank	8888	\N	not_sent
e345955f-2c20-485d-aef1-9f6aac413284	22bdf2b7-75c6-2674-8248-96d26a207d63	1028	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-20	barnameh	765765765	2026-02-20					d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N	55	777	غ	88	0	0	0	0	0	0	0	\N	warehouse						2026-02-20 10:21:06.263245+00	2026-02-20 10:21:06.263245+00		2026-02-20	0	0	0	0	780000000	0	0		0	cb22769d-a989-3a07-6f13-3e490a7d1945	bank		\N	not_sent
05bf3439-cdfa-43c9-9768-32d1aba46130	22bdf2b7-75c6-2674-8248-96d26a207d63	1029	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-20	barnameh	7778883	2026-02-20					d300ce05-8008-4bb0-95f1-2eb231fb4346	\N			\N	33	666	غ	55	0	0	0	0	0	0	0	\N	warehouse						2026-02-20 10:36:24.109847+00	2026-02-20 10:36:24.109847+00		2026-02-20	0	0	0	0	78000000	0	0		0	cb22769d-a989-3a07-6f13-3e490a7d1945	bank	786786	\N	not_sent
34dd857c-84d8-479f-b997-58b46e9d67e2	22bdf2b7-75c6-2674-8248-96d26a207d63	1030	f04fb725-d8b4-43f1-811d-8267e8761430	final	2026-02-21	barnameh	8726376	2026-02-21					2db3438c-0865-4cf1-955e-d9197e63061f	\N		8927389834	2026-02-21	22	333	غ	44	0	0	0	0	0	0	0	\N	warehouse	8726715267576125		ملی	راننده		2026-02-21 08:32:43.503324+00	2026-02-21 08:33:30.622052+00		2026-02-21	0	0	0	0	453000000	0	0		0	32faf08b-bfc3-b5ea-c940-56137e66d2f4	bank	12123	\N	not_sent
3f3a9111-12c1-40c4-8450-03de23e03923	22bdf2b7-75c6-2674-8248-96d26a207d63	1030	dc66ad9a-8bc5-4556-9860-aeab96211fa3	final	2026-02-23	barnameh	111111	2026-02-23					d300ce05-8008-4bb0-95f1-2eb231fb4346	\N		4455333333	\N	66	888	ب	77	0	0	0	0	0	0	0	\N	warehouse						2026-02-23 12:14:34.546331+00	2026-02-23 12:14:34.546331+00		2026-02-23	0	1200000	0	0	670000000	0	0		0	7956e568-dcdd-1e29-1396-acf3f9dbbbc7	bank		\N	not_sent
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permissions (role_id, permission_id, constraints_json, created_at) FROM stdin;
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	c43c2429-2131-4b34-8fba-af951d48fb75	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	afb85844-0f71-4041-8914-db0700409691	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	0b286a7b-b307-44c1-ad35-d1f7feb699f5	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	ac61565d-02c0-494d-9c87-7bc317bc1351	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	1c5950c1-0307-47fa-861b-e2e0413b43f2	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	4daa2a00-a265-46a6-89bf-58bfb5586a59	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	805d7f41-29ed-45b5-9d34-e53b7a102c11	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	9aebdf5c-dfab-4253-9022-e0b526360fc2	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	096016a4-fa6d-47d5-9ad6-a1c88470adf4	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	724b9ccb-0077-4c04-bafc-1bcf57b08497	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	46601e93-c28c-4488-b65c-252bdf9e92fc	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	21c5d345-00c5-4a98-ab21-fefc75f813c8	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	f2fd3178-a8bc-4be2-8385-03f511456730	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	b427d55f-e672-49e6-b834-30c62645f4bb	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	4ccd9a83-45a0-4d41-8743-279df9de9c3c	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	bf43cd27-51cc-4ce4-85c6-a5e2b5682cb0	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	0083d40b-de0d-4448-8ea5-c6023f393366	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	36b544a4-f50a-42fe-b36f-4c9aa1126f5f	\N	2026-02-07 19:28:35.484574+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	efaf88a4-b32f-40b8-9652-bb0f19e11eee	\N	2026-02-07 19:28:35.484574+00
fa92104c-690a-46c1-be6e-205af888d938	c43c2429-2131-4b34-8fba-af951d48fb75	\N	2026-02-07 19:28:35.497986+00
fa92104c-690a-46c1-be6e-205af888d938	afb85844-0f71-4041-8914-db0700409691	\N	2026-02-07 19:28:35.497986+00
fa92104c-690a-46c1-be6e-205af888d938	0b286a7b-b307-44c1-ad35-d1f7feb699f5	\N	2026-02-07 19:28:35.497986+00
fa92104c-690a-46c1-be6e-205af888d938	ac61565d-02c0-494d-9c87-7bc317bc1351	\N	2026-02-07 19:28:35.497986+00
fa92104c-690a-46c1-be6e-205af888d938	4daa2a00-a265-46a6-89bf-58bfb5586a59	\N	2026-02-07 19:28:35.497986+00
fa92104c-690a-46c1-be6e-205af888d938	805d7f41-29ed-45b5-9d34-e53b7a102c11	\N	2026-02-07 19:28:35.497986+00
fa92104c-690a-46c1-be6e-205af888d938	9aebdf5c-dfab-4253-9022-e0b526360fc2	\N	2026-02-07 19:28:35.497986+00
fa92104c-690a-46c1-be6e-205af888d938	096016a4-fa6d-47d5-9ad6-a1c88470adf4	\N	2026-02-07 19:28:35.497986+00
fa92104c-690a-46c1-be6e-205af888d938	46601e93-c28c-4488-b65c-252bdf9e92fc	\N	2026-02-07 19:28:35.497986+00
fa92104c-690a-46c1-be6e-205af888d938	21c5d345-00c5-4a98-ab21-fefc75f813c8	\N	2026-02-07 19:28:35.497986+00
fa92104c-690a-46c1-be6e-205af888d938	bf43cd27-51cc-4ce4-85c6-a5e2b5682cb0	\N	2026-02-07 19:28:35.497986+00
3a48e652-3f82-4dc9-b34a-6d5ef4a84d0c	c43c2429-2131-4b34-8fba-af951d48fb75	\N	2026-02-07 19:28:35.501828+00
3a48e652-3f82-4dc9-b34a-6d5ef4a84d0c	afb85844-0f71-4041-8914-db0700409691	\N	2026-02-07 19:28:35.501828+00
3a48e652-3f82-4dc9-b34a-6d5ef4a84d0c	805d7f41-29ed-45b5-9d34-e53b7a102c11	\N	2026-02-07 19:28:35.501828+00
3a48e652-3f82-4dc9-b34a-6d5ef4a84d0c	bf43cd27-51cc-4ce4-85c6-a5e2b5682cb0	\N	2026-02-07 19:28:35.501828+00
3a48e652-3f82-4dc9-b34a-6d5ef4a84d0c	36b544a4-f50a-42fe-b36f-4c9aa1126f5f	\N	2026-02-07 19:28:35.501828+00
3a48e652-3f82-4dc9-b34a-6d5ef4a84d0c	efaf88a4-b32f-40b8-9652-bb0f19e11eee	\N	2026-02-07 19:28:35.501828+00
26e75f4a-81d5-482c-8004-534ee887820d	c43c2429-2131-4b34-8fba-af951d48fb75	\N	2026-02-07 19:28:35.505111+00
26e75f4a-81d5-482c-8004-534ee887820d	afb85844-0f71-4041-8914-db0700409691	\N	2026-02-07 19:28:35.505111+00
26e75f4a-81d5-482c-8004-534ee887820d	805d7f41-29ed-45b5-9d34-e53b7a102c11	\N	2026-02-07 19:28:35.505111+00
26e75f4a-81d5-482c-8004-534ee887820d	21c5d345-00c5-4a98-ab21-fefc75f813c8	\N	2026-02-07 19:28:35.505111+00
26e75f4a-81d5-482c-8004-534ee887820d	bf43cd27-51cc-4ce4-85c6-a5e2b5682cb0	\N	2026-02-07 19:28:35.505111+00
26e75f4a-81d5-482c-8004-534ee887820d	36b544a4-f50a-42fe-b36f-4c9aa1126f5f	\N	2026-02-07 19:28:35.505111+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	c43c2429-2131-4b34-8fba-af951d48fb75	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	afb85844-0f71-4041-8914-db0700409691	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	0b286a7b-b307-44c1-ad35-d1f7feb699f5	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	ac61565d-02c0-494d-9c87-7bc317bc1351	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	4daa2a00-a265-46a6-89bf-58bfb5586a59	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	805d7f41-29ed-45b5-9d34-e53b7a102c11	\N	2026-02-20 19:42:22.269785+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	6e813294-a0d0-4900-a760-ddbd491ee71c	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	bb39c233-0cad-4b7a-bbc8-e947d9fae0f1	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	d2bd6033-8796-4875-b337-772bd92ec0ec	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	c43c2429-2131-4b34-8fba-af951d48fb75	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	36b544a4-f50a-42fe-b36f-4c9aa1126f5f	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	efaf88a4-b32f-40b8-9652-bb0f19e11eee	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	21c5d345-00c5-4a98-ab21-fefc75f813c8	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	f2fd3178-a8bc-4be2-8385-03f511456730	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	b427d55f-e672-49e6-b834-30c62645f4bb	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	4ccd9a83-45a0-4d41-8743-279df9de9c3c	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	29049644-0de4-4e80-b381-a458f2d90c88	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	af7e3226-5c78-4b8f-a3e4-c5b98944ec08	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	02789f19-af19-41ec-b97e-ad446312e76a	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	b36d89c6-a2e8-41af-8df8-1fdae2200b60	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	22260a49-7b09-49dc-b102-6d419dbdb769	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	de28accd-8c2f-4f1b-959b-0e7bc08b82f1	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	5fb152f0-9b40-4b79-bf05-39efdf3b573e	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	da3cb40b-568c-4da3-9ffd-19038be61f49	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	e227a9fc-e968-44a3-9b53-c1cc0cb8e3bb	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	448fa895-1b3c-4a07-a64b-b32bb3fc703d	\N	2026-02-20 20:07:41.542104+00
7cf59422-66bf-420e-b729-876e0046e974	131404e6-3cd1-4f34-ba23-2a35a131edda	\N	2026-02-09 09:51:04.244278+00
7cf59422-66bf-420e-b729-876e0046e974	db21141a-73d3-4333-88a9-e565c6f3daf9	\N	2026-02-09 09:51:04.244278+00
7cf59422-66bf-420e-b729-876e0046e974	e306e30f-0af9-4e4e-abb5-44f60b8f2914	\N	2026-02-09 09:51:04.244278+00
7cf59422-66bf-420e-b729-876e0046e974	cb4d42de-3790-43eb-a728-1707cf3d3be1	\N	2026-02-09 09:51:04.244278+00
7cf59422-66bf-420e-b729-876e0046e974	0b182b05-3319-4f43-8a85-8d6a4e26aec1	\N	2026-02-09 09:51:04.244278+00
7cf59422-66bf-420e-b729-876e0046e974	bb39c233-0cad-4b7a-bbc8-e947d9fae0f1	\N	2026-02-09 09:51:04.244278+00
7cf59422-66bf-420e-b729-876e0046e974	6e813294-a0d0-4900-a760-ddbd491ee71c	\N	2026-02-09 09:51:04.244278+00
7cf59422-66bf-420e-b729-876e0046e974	29049644-0de4-4e80-b381-a458f2d90c88	\N	2026-02-09 09:51:04.244278+00
7cf59422-66bf-420e-b729-876e0046e974	af7e3226-5c78-4b8f-a3e4-c5b98944ec08	\N	2026-02-09 09:51:04.244278+00
7cf59422-66bf-420e-b729-876e0046e974	02789f19-af19-41ec-b97e-ad446312e76a	\N	2026-02-09 09:51:04.244278+00
7cf59422-66bf-420e-b729-876e0046e974	b36d89c6-a2e8-41af-8df8-1fdae2200b60	\N	2026-02-09 09:51:04.244278+00
18089e5d-b737-4b44-b2fe-f7145ecdf0e5	86ae6499-1a91-4336-aff9-f535b16241e8	\N	2026-02-09 09:51:04.244278+00
18089e5d-b737-4b44-b2fe-f7145ecdf0e5	9b551a7f-e222-47d6-94d5-d89047c50cf0	\N	2026-02-09 09:51:04.244278+00
18089e5d-b737-4b44-b2fe-f7145ecdf0e5	bf43cd27-51cc-4ce4-85c6-a5e2b5682cb0	\N	2026-02-09 09:51:04.244278+00
18089e5d-b737-4b44-b2fe-f7145ecdf0e5	49483f8b-00fa-43eb-816d-a9ccb2ffad84	\N	2026-02-09 09:51:04.244278+00
18089e5d-b737-4b44-b2fe-f7145ecdf0e5	afb85844-0f71-4041-8914-db0700409691	\N	2026-02-09 09:51:04.244278+00
18089e5d-b737-4b44-b2fe-f7145ecdf0e5	0b286a7b-b307-44c1-ad35-d1f7feb699f5	\N	2026-02-09 09:51:04.244278+00
18089e5d-b737-4b44-b2fe-f7145ecdf0e5	e73d80d7-e6aa-4d90-a375-74198a915dab	\N	2026-02-09 09:51:04.244278+00
18089e5d-b737-4b44-b2fe-f7145ecdf0e5	431a08bd-b8f7-40b6-9f3a-5211caf6df35	\N	2026-02-09 09:51:04.244278+00
18089e5d-b737-4b44-b2fe-f7145ecdf0e5	6f885087-27ae-4bea-b039-284bc2c4485b	\N	2026-02-09 09:51:04.244278+00
18089e5d-b737-4b44-b2fe-f7145ecdf0e5	92ec0bbb-891a-4371-9e7a-d847e634f34e	\N	2026-02-09 09:51:04.244278+00
9ad73c84-e7cf-47d1-af1a-5000e8ca78fc	12906eb5-a032-4700-abe3-aab5a179097a	\N	2026-02-09 09:51:04.244278+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	01da3b3c-8022-4f2b-b0ce-080643af7e1e	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	2ec8863d-1ff1-4018-adf1-2ab1c618e0c5	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	aeae1ece-6b72-4e96-aff4-b4ea7bc994b1	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	6ee9db8e-6dbf-4892-b009-9d23efe410d8	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	1e8686a7-3fb4-446b-a266-bea3a5d66935	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	86ae6499-1a91-4336-aff9-f535b16241e8	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	9b551a7f-e222-47d6-94d5-d89047c50cf0	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	541b0257-de61-4e30-916e-f7d03f4e7541	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	d636e730-3a86-438d-aacd-06b8c94db9b3	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	8baa4517-76fd-42f6-b3d8-8359d804de82	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	49483f8b-00fa-43eb-816d-a9ccb2ffad84	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	7929245b-f195-4ce6-a5a7-d244a12d3cfe	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	f7aa82b6-7313-4020-9cb8-25456d550634	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	1af4fa9d-c1e4-41e3-8d02-3c81bf97bd96	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	76f1034c-e8a3-4a9b-9aa7-ec6aab9ac28a	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	e73d80d7-e6aa-4d90-a375-74198a915dab	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	431a08bd-b8f7-40b6-9f3a-5211caf6df35	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	53f731d2-b433-4f8f-85a8-bf435d35517b	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	8f708164-8b45-4b65-9d6c-96b8f3281b35	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	89b55114-cd36-4022-aebf-6858974e5e7e	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	6f885087-27ae-4bea-b039-284bc2c4485b	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	92ec0bbb-891a-4371-9e7a-d847e634f34e	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	f179c009-11fa-46df-9106-4723aba54e89	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	4afbdaa3-f760-4e41-a907-225a597b595a	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	58573c2b-75a9-4eb4-8306-d0f72cdd50d7	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	5c94fdce-7eb0-4527-ba02-21322ece115e	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	131404e6-3cd1-4f34-ba23-2a35a131edda	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	db21141a-73d3-4333-88a9-e565c6f3daf9	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	e306e30f-0af9-4e4e-abb5-44f60b8f2914	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	cb4d42de-3790-43eb-a728-1707cf3d3be1	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	0b182b05-3319-4f43-8a85-8d6a4e26aec1	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	bb39c233-0cad-4b7a-bbc8-e947d9fae0f1	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	6e813294-a0d0-4900-a760-ddbd491ee71c	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	29049644-0de4-4e80-b381-a458f2d90c88	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	af7e3226-5c78-4b8f-a3e4-c5b98944ec08	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	02789f19-af19-41ec-b97e-ad446312e76a	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	b36d89c6-a2e8-41af-8df8-1fdae2200b60	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	12906eb5-a032-4700-abe3-aab5a179097a	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	957726fb-613f-4339-9977-025083bbb924	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	ccb21799-1581-431c-8156-bd00df1e9ffd	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	1b32b6d5-abd9-4c35-ace7-0028a1eda243	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	62f56f66-5ac6-4f08-9009-6063c0be2e50	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	384ef955-7a75-4352-a303-e0c562cddd34	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	c50d40f9-950d-4688-8bc6-25477ea34fcf	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	52bd01a5-c556-4469-94d0-dd8d132004a0	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	50408ef2-686f-469c-906e-2a3389b945f8	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	fa0133d6-0ad1-4e03-9a04-c8b1014c7a8c	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	9a620b94-7c29-4965-9949-900ad39b29b6	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	277e8d68-e5e0-4f80-8bdf-055d9437cbeb	\N	2026-02-09 10:46:16.922218+00
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	95859a6f-e928-4cec-99be-595a593afc76	\N	2026-02-09 10:46:16.922218+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	9aebdf5c-dfab-4253-9022-e0b526360fc2	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	096016a4-fa6d-47d5-9ad6-a1c88470adf4	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	724b9ccb-0077-4c04-bafc-1bcf57b08497	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	46601e93-c28c-4488-b65c-252bdf9e92fc	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	21c5d345-00c5-4a98-ab21-fefc75f813c8	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	f2fd3178-a8bc-4be2-8385-03f511456730	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	b427d55f-e672-49e6-b834-30c62645f4bb	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	bf43cd27-51cc-4ce4-85c6-a5e2b5682cb0	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	0083d40b-de0d-4448-8ea5-c6023f393366	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	131404e6-3cd1-4f34-ba23-2a35a131edda	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	db21141a-73d3-4333-88a9-e565c6f3daf9	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	e306e30f-0af9-4e4e-abb5-44f60b8f2914	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	cb4d42de-3790-43eb-a728-1707cf3d3be1	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	0b182b05-3319-4f43-8a85-8d6a4e26aec1	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	6e813294-a0d0-4900-a760-ddbd491ee71c	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	bb39c233-0cad-4b7a-bbc8-e947d9fae0f1	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	de28accd-8c2f-4f1b-959b-0e7bc08b82f1	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	5fb152f0-9b40-4b79-bf05-39efdf3b573e	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	86ae6499-1a91-4336-aff9-f535b16241e8	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	9b551a7f-e222-47d6-94d5-d89047c50cf0	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	541b0257-de61-4e30-916e-f7d03f4e7541	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	d636e730-3a86-438d-aacd-06b8c94db9b3	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	8baa4517-76fd-42f6-b3d8-8359d804de82	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	6f885087-27ae-4bea-b039-284bc2c4485b	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	92ec0bbb-891a-4371-9e7a-d847e634f34e	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	f179c009-11fa-46df-9106-4723aba54e89	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	4afbdaa3-f760-4e41-a907-225a597b595a	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	58573c2b-75a9-4eb4-8306-d0f72cdd50d7	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	36b544a4-f50a-42fe-b36f-4c9aa1126f5f	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	efaf88a4-b32f-40b8-9652-bb0f19e11eee	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	e73d80d7-e6aa-4d90-a375-74198a915dab	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	431a08bd-b8f7-40b6-9f3a-5211caf6df35	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	53f731d2-b433-4f8f-85a8-bf435d35517b	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	8f708164-8b45-4b65-9d6c-96b8f3281b35	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	89b55114-cd36-4022-aebf-6858974e5e7e	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	49483f8b-00fa-43eb-816d-a9ccb2ffad84	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	7929245b-f195-4ce6-a5a7-d244a12d3cfe	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	f7aa82b6-7313-4020-9cb8-25456d550634	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	1af4fa9d-c1e4-41e3-8d02-3c81bf97bd96	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	29049644-0de4-4e80-b381-a458f2d90c88	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	af7e3226-5c78-4b8f-a3e4-c5b98944ec08	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	02789f19-af19-41ec-b97e-ad446312e76a	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	b36d89c6-a2e8-41af-8df8-1fdae2200b60	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	da3cb40b-568c-4da3-9ffd-19038be61f49	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	448fa895-1b3c-4a07-a64b-b32bb3fc703d	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	e227a9fc-e968-44a3-9b53-c1cc0cb8e3bb	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	22260a49-7b09-49dc-b102-6d419dbdb769	\N	2026-02-20 19:42:22.269785+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	d2bd6033-8796-4875-b337-772bd92ec0ec	\N	2026-02-20 19:42:22.269785+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	0083d40b-de0d-4448-8ea5-c6023f393366	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	096016a4-fa6d-47d5-9ad6-a1c88470adf4	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	0b286a7b-b307-44c1-ad35-d1f7feb699f5	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	1af4fa9d-c1e4-41e3-8d02-3c81bf97bd96	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	1c5950c1-0307-47fa-861b-e2e0413b43f2	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	431a08bd-b8f7-40b6-9f3a-5211caf6df35	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	46601e93-c28c-4488-b65c-252bdf9e92fc	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	49483f8b-00fa-43eb-816d-a9ccb2ffad84	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	4afbdaa3-f760-4e41-a907-225a597b595a	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	4daa2a00-a265-46a6-89bf-58bfb5586a59	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	53f731d2-b433-4f8f-85a8-bf435d35517b	\N	2026-02-20 20:07:41.542104+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	c43c2429-2131-4b34-8fba-af951d48fb75	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	46601e93-c28c-4488-b65c-252bdf9e92fc	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	21c5d345-00c5-4a98-ab21-fefc75f813c8	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	f2fd3178-a8bc-4be2-8385-03f511456730	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	b427d55f-e672-49e6-b834-30c62645f4bb	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	4ccd9a83-45a0-4d41-8743-279df9de9c3c	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	0083d40b-de0d-4448-8ea5-c6023f393366	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	36b544a4-f50a-42fe-b36f-4c9aa1126f5f	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	efaf88a4-b32f-40b8-9652-bb0f19e11eee	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	01da3b3c-8022-4f2b-b0ce-080643af7e1e	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	2ec8863d-1ff1-4018-adf1-2ab1c618e0c5	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	aeae1ece-6b72-4e96-aff4-b4ea7bc994b1	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	6ee9db8e-6dbf-4892-b009-9d23efe410d8	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	1e8686a7-3fb4-446b-a266-bea3a5d66935	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	86ae6499-1a91-4336-aff9-f535b16241e8	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	9b551a7f-e222-47d6-94d5-d89047c50cf0	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	541b0257-de61-4e30-916e-f7d03f4e7541	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	d636e730-3a86-438d-aacd-06b8c94db9b3	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	8baa4517-76fd-42f6-b3d8-8359d804de82	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	bf43cd27-51cc-4ce4-85c6-a5e2b5682cb0	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	49483f8b-00fa-43eb-816d-a9ccb2ffad84	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	7929245b-f195-4ce6-a5a7-d244a12d3cfe	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	f7aa82b6-7313-4020-9cb8-25456d550634	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	1af4fa9d-c1e4-41e3-8d02-3c81bf97bd96	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	afb85844-0f71-4041-8914-db0700409691	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	0b286a7b-b307-44c1-ad35-d1f7feb699f5	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	ac61565d-02c0-494d-9c87-7bc317bc1351	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	1c5950c1-0307-47fa-861b-e2e0413b43f2	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	76f1034c-e8a3-4a9b-9aa7-ec6aab9ac28a	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	4daa2a00-a265-46a6-89bf-58bfb5586a59	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	e73d80d7-e6aa-4d90-a375-74198a915dab	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	431a08bd-b8f7-40b6-9f3a-5211caf6df35	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	53f731d2-b433-4f8f-85a8-bf435d35517b	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	8f708164-8b45-4b65-9d6c-96b8f3281b35	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	89b55114-cd36-4022-aebf-6858974e5e7e	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	6f885087-27ae-4bea-b039-284bc2c4485b	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	92ec0bbb-891a-4371-9e7a-d847e634f34e	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	f179c009-11fa-46df-9106-4723aba54e89	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	4afbdaa3-f760-4e41-a907-225a597b595a	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	58573c2b-75a9-4eb4-8306-d0f72cdd50d7	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	805d7f41-29ed-45b5-9d34-e53b7a102c11	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	9aebdf5c-dfab-4253-9022-e0b526360fc2	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	096016a4-fa6d-47d5-9ad6-a1c88470adf4	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	5c94fdce-7eb0-4527-ba02-21322ece115e	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	724b9ccb-0077-4c04-bafc-1bcf57b08497	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	131404e6-3cd1-4f34-ba23-2a35a131edda	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	db21141a-73d3-4333-88a9-e565c6f3daf9	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	e306e30f-0af9-4e4e-abb5-44f60b8f2914	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	cb4d42de-3790-43eb-a728-1707cf3d3be1	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	0b182b05-3319-4f43-8a85-8d6a4e26aec1	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	bb39c233-0cad-4b7a-bbc8-e947d9fae0f1	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	6e813294-a0d0-4900-a760-ddbd491ee71c	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	29049644-0de4-4e80-b381-a458f2d90c88	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	af7e3226-5c78-4b8f-a3e4-c5b98944ec08	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	02789f19-af19-41ec-b97e-ad446312e76a	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	b36d89c6-a2e8-41af-8df8-1fdae2200b60	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	12906eb5-a032-4700-abe3-aab5a179097a	\N	2026-02-10 05:21:23.823764+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	541b0257-de61-4e30-916e-f7d03f4e7541	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	58573c2b-75a9-4eb4-8306-d0f72cdd50d7	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	5c94fdce-7eb0-4527-ba02-21322ece115e	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	6f885087-27ae-4bea-b039-284bc2c4485b	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	724b9ccb-0077-4c04-bafc-1bcf57b08497	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	76f1034c-e8a3-4a9b-9aa7-ec6aab9ac28a	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	7929245b-f195-4ce6-a5a7-d244a12d3cfe	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	805d7f41-29ed-45b5-9d34-e53b7a102c11	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	86ae6499-1a91-4336-aff9-f535b16241e8	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	89b55114-cd36-4022-aebf-6858974e5e7e	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	8baa4517-76fd-42f6-b3d8-8359d804de82	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	8f708164-8b45-4b65-9d6c-96b8f3281b35	\N	2026-02-20 20:07:41.542104+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	957726fb-613f-4339-9977-025083bbb924	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	ccb21799-1581-431c-8156-bd00df1e9ffd	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	1b32b6d5-abd9-4c35-ace7-0028a1eda243	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	62f56f66-5ac6-4f08-9009-6063c0be2e50	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	384ef955-7a75-4352-a303-e0c562cddd34	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	c50d40f9-950d-4688-8bc6-25477ea34fcf	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	52bd01a5-c556-4469-94d0-dd8d132004a0	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	50408ef2-686f-469c-906e-2a3389b945f8	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	fa0133d6-0ad1-4e03-9a04-c8b1014c7a8c	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	9a620b94-7c29-4965-9949-900ad39b29b6	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	277e8d68-e5e0-4f80-8bdf-055d9437cbeb	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	95859a6f-e928-4cec-99be-595a593afc76	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	9fc9a646-1d8f-4b86-ab0f-a58ce4fa870c	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	d2bd6033-8796-4875-b337-772bd92ec0ec	\N	2026-02-10 05:21:23.823764+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	22260a49-7b09-49dc-b102-6d419dbdb769	\N	2026-02-10 05:21:23.823764+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	92ec0bbb-891a-4371-9e7a-d847e634f34e	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	9aebdf5c-dfab-4253-9022-e0b526360fc2	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	9b551a7f-e222-47d6-94d5-d89047c50cf0	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	ac61565d-02c0-494d-9c87-7bc317bc1351	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	afb85844-0f71-4041-8914-db0700409691	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	bf43cd27-51cc-4ce4-85c6-a5e2b5682cb0	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	d636e730-3a86-438d-aacd-06b8c94db9b3	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	e73d80d7-e6aa-4d90-a375-74198a915dab	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	f179c009-11fa-46df-9106-4723aba54e89	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	f7aa82b6-7313-4020-9cb8-25456d550634	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	131404e6-3cd1-4f34-ba23-2a35a131edda	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	db21141a-73d3-4333-88a9-e565c6f3daf9	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	e306e30f-0af9-4e4e-abb5-44f60b8f2914	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	cb4d42de-3790-43eb-a728-1707cf3d3be1	\N	2026-02-20 20:07:41.542104+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	0b182b05-3319-4f43-8a85-8d6a4e26aec1	\N	2026-02-20 20:07:41.542104+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	c43c2429-2131-4b34-8fba-af951d48fb75	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	46601e93-c28c-4488-b65c-252bdf9e92fc	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	21c5d345-00c5-4a98-ab21-fefc75f813c8	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	f2fd3178-a8bc-4be2-8385-03f511456730	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	b427d55f-e672-49e6-b834-30c62645f4bb	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	4ccd9a83-45a0-4d41-8743-279df9de9c3c	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	0083d40b-de0d-4448-8ea5-c6023f393366	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	36b544a4-f50a-42fe-b36f-4c9aa1126f5f	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	efaf88a4-b32f-40b8-9652-bb0f19e11eee	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	01da3b3c-8022-4f2b-b0ce-080643af7e1e	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	2ec8863d-1ff1-4018-adf1-2ab1c618e0c5	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	aeae1ece-6b72-4e96-aff4-b4ea7bc994b1	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	6ee9db8e-6dbf-4892-b009-9d23efe410d8	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	1e8686a7-3fb4-446b-a266-bea3a5d66935	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	86ae6499-1a91-4336-aff9-f535b16241e8	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	9b551a7f-e222-47d6-94d5-d89047c50cf0	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	541b0257-de61-4e30-916e-f7d03f4e7541	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	d636e730-3a86-438d-aacd-06b8c94db9b3	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	8baa4517-76fd-42f6-b3d8-8359d804de82	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	bf43cd27-51cc-4ce4-85c6-a5e2b5682cb0	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	49483f8b-00fa-43eb-816d-a9ccb2ffad84	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	7929245b-f195-4ce6-a5a7-d244a12d3cfe	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	f7aa82b6-7313-4020-9cb8-25456d550634	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	1af4fa9d-c1e4-41e3-8d02-3c81bf97bd96	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	afb85844-0f71-4041-8914-db0700409691	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	0b286a7b-b307-44c1-ad35-d1f7feb699f5	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	ac61565d-02c0-494d-9c87-7bc317bc1351	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	1c5950c1-0307-47fa-861b-e2e0413b43f2	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	76f1034c-e8a3-4a9b-9aa7-ec6aab9ac28a	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	4daa2a00-a265-46a6-89bf-58bfb5586a59	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	e73d80d7-e6aa-4d90-a375-74198a915dab	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	431a08bd-b8f7-40b6-9f3a-5211caf6df35	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	53f731d2-b433-4f8f-85a8-bf435d35517b	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	8f708164-8b45-4b65-9d6c-96b8f3281b35	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	89b55114-cd36-4022-aebf-6858974e5e7e	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	6f885087-27ae-4bea-b039-284bc2c4485b	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	92ec0bbb-891a-4371-9e7a-d847e634f34e	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	f179c009-11fa-46df-9106-4723aba54e89	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	4afbdaa3-f760-4e41-a907-225a597b595a	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	58573c2b-75a9-4eb4-8306-d0f72cdd50d7	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	805d7f41-29ed-45b5-9d34-e53b7a102c11	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	9aebdf5c-dfab-4253-9022-e0b526360fc2	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	096016a4-fa6d-47d5-9ad6-a1c88470adf4	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	5c94fdce-7eb0-4527-ba02-21322ece115e	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	724b9ccb-0077-4c04-bafc-1bcf57b08497	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	131404e6-3cd1-4f34-ba23-2a35a131edda	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	db21141a-73d3-4333-88a9-e565c6f3daf9	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	e306e30f-0af9-4e4e-abb5-44f60b8f2914	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	cb4d42de-3790-43eb-a728-1707cf3d3be1	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	0b182b05-3319-4f43-8a85-8d6a4e26aec1	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	bb39c233-0cad-4b7a-bbc8-e947d9fae0f1	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	6e813294-a0d0-4900-a760-ddbd491ee71c	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	29049644-0de4-4e80-b381-a458f2d90c88	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	af7e3226-5c78-4b8f-a3e4-c5b98944ec08	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	02789f19-af19-41ec-b97e-ad446312e76a	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	b36d89c6-a2e8-41af-8df8-1fdae2200b60	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	12906eb5-a032-4700-abe3-aab5a179097a	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	957726fb-613f-4339-9977-025083bbb924	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	ccb21799-1581-431c-8156-bd00df1e9ffd	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	1b32b6d5-abd9-4c35-ace7-0028a1eda243	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	62f56f66-5ac6-4f08-9009-6063c0be2e50	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	384ef955-7a75-4352-a303-e0c562cddd34	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	c50d40f9-950d-4688-8bc6-25477ea34fcf	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	52bd01a5-c556-4469-94d0-dd8d132004a0	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	50408ef2-686f-469c-906e-2a3389b945f8	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	fa0133d6-0ad1-4e03-9a04-c8b1014c7a8c	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	9a620b94-7c29-4965-9949-900ad39b29b6	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	277e8d68-e5e0-4f80-8bdf-055d9437cbeb	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	95859a6f-e928-4cec-99be-595a593afc76	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	22260a49-7b09-49dc-b102-6d419dbdb769	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	9fc9a646-1d8f-4b86-ab0f-a58ce4fa870c	\N	2026-02-12 21:53:06.912069+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	d2bd6033-8796-4875-b337-772bd92ec0ec	\N	2026-02-12 21:53:06.912069+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, member_id, code, title, description, is_system, is_active, created_at, updated_at) FROM stdin;
ad7d48a8-2ace-425d-a20c-23bee0d6aeef	dc66ad9a-8bc5-4556-9860-aeab96211fa3	super_admin	مدیر کل	\N	t	t	2026-02-07 19:28:27.746051+00	2026-02-07 19:28:27.746051+00
5035d4a3-9f13-4da9-9f14-10bccf98c06e	dc66ad9a-8bc5-4556-9860-aeab96211fa3	warehouse_manager	مدیر انبار	\N	t	t	2026-02-07 19:28:27.746051+00	2026-02-07 19:28:27.746051+00
fa92104c-690a-46c1-be6e-205af888d938	dc66ad9a-8bc5-4556-9860-aeab96211fa3	warehouse_operator	اپراتور انبار	\N	t	t	2026-02-07 19:28:27.746051+00	2026-02-07 19:28:27.746051+00
3a48e652-3f82-4dc9-b34a-6d5ef4a84d0c	dc66ad9a-8bc5-4556-9860-aeab96211fa3	finance_user	کاربر مالی	\N	t	t	2026-02-07 19:28:27.746051+00	2026-02-07 19:28:27.746051+00
26e75f4a-81d5-482c-8004-534ee887820d	dc66ad9a-8bc5-4556-9860-aeab96211fa3	readonly_auditor	ناظر فقط خواندنی	\N	t	t	2026-02-07 19:28:27.746051+00	2026-02-07 19:28:27.746051+00
7d30e79a-192e-4ef1-a036-c34029f7ab68	dc66ad9a-8bc5-4556-9860-aeab96211fa3	super-admin	مدیر کل سیستم	دسترسی کامل به تمام بخش‌ها	t	t	2026-02-09 09:39:38.411204+00	2026-02-09 09:51:04.244278+00
dc28392f-8a08-4df2-9df6-67d7c08e6826	dc66ad9a-8bc5-4556-9860-aeab96211fa3	warehouse-manager	مدیر انبار	مدیریت عملیات انبارداری	t	t	2026-02-09 09:39:38.411204+00	2026-02-09 09:51:04.244278+00
7cf59422-66bf-420e-b729-876e0046e974	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accountant	حسابدار	دسترسی به بخش حسابداری و گزارشات مالی	t	t	2026-02-09 09:39:38.411204+00	2026-02-09 09:51:04.244278+00
18089e5d-b737-4b44-b2fe-f7145ecdf0e5	dc66ad9a-8bc5-4556-9860-aeab96211fa3	operator	اپراتور	ثبت رسید و بارگیری	f	t	2026-02-09 09:39:38.411204+00	2026-02-09 09:51:04.244278+00
9ad73c84-e7cf-47d1-af1a-5000e8ca78fc	dc66ad9a-8bc5-4556-9860-aeab96211fa3	client	مشتری	دسترسی به پرتال مشتری	t	t	2026-02-09 09:39:38.411204+00	2026-02-09 09:51:04.244278+00
d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	dc66ad9a-8bc5-4556-9860-aeab96211fa3	owner	مدیر ارشد	دسترسی کامل به تمام سیستم	t	t	2026-02-10 05:21:23.823764+00	2026-02-10 05:21:23.823764+00
\.


--
-- Data for Name: sms_logs; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.sms_logs (id, member_id, recipients, recipient_names, message, send_type, category_filter, status_filter, total_count, success_count, fail_count, created_at) FROM stdin;
1	dc66ad9a-8bc5-4556-9860-aeab96211fa3	{09121137675}	{"تست انبار"}	سلام	single	\N	\N	1	1	0	2026-02-22 13:30:27.67806+00
\.


--
-- Data for Name: ticket_categories; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.ticket_categories (id, member_id, name, icon, color, sort_order, is_active, created_at) FROM stdin;
1e060e76-5178-4345-9a97-60bb7b6c4771	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مشکل فنی	bx-bug	#f46a6a	1	t	2026-02-20 17:41:30.923388+00
18ad680a-6615-440f-9858-d758a98202e0	dc66ad9a-8bc5-4556-9860-aeab96211fa3	درخواست ویژگی	bx-bulb	#f1b44c	2	t	2026-02-20 17:41:31.013575+00
0517290b-43ba-4afe-a873-1124cd277c53	dc66ad9a-8bc5-4556-9860-aeab96211fa3	سوال عمومی	bx-help-circle	#556ee6	3	t	2026-02-20 17:41:31.01968+00
0fe5bb13-931d-41da-8f1c-f7658295a6e0	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مالی و حسابداری	bx-calculator	#34c38f	4	t	2026-02-20 17:41:31.025033+00
fdce5148-612c-4674-b617-d4fceccca4e6	dc66ad9a-8bc5-4556-9860-aeab96211fa3	انبارداری	bx-package	#50a5f1	5	t	2026-02-20 17:41:31.028774+00
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.ticket_messages (id, ticket_id, sender_id, sender_name, sender_role, message, is_internal, attachments, created_at) FROM stdin;
0acff430-0526-4889-b978-f5bfbb3c13f7	40d7c2f5-905d-41e3-ba1b-19205edad2de	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	user	سلام جیگر	f	[]	2026-02-20 21:22:28.115907+00
fd2a4493-d517-4407-bc40-75a522163efd	40d7c2f5-905d-41e3-ba1b-19205edad2de	dc66ad9a-8bc5-4556-9860-aeab96211fa3	مدیر سیستم	admin	خوبی	f	[]	2026-02-20 21:26:15.345972+00
c8698eac-0ea7-4ad8-9996-584d3f6296cd	40d7c2f5-905d-41e3-ba1b-19205edad2de	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	user	📎 1 فایل پیوست شد	f	[{"url": "/uploads/media/f04fb725-d8b4-43f1-811d-8267e8761430/1771622791160-f86743082678f-logo.svg", "name": "logo.svg", "size": 3193, "type": "image/svg+xml"}]	2026-02-20 21:26:31.215286+00
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.tickets (id, member_id, ticket_no, category_id, subject, description, priority, status, created_by, created_by_name, assigned_to, assigned_to_name, closed_at, closed_by, rating, rating_comment, tags, created_at, updated_at) FROM stdin;
40d7c2f5-905d-41e3-ba1b-19205edad2de	f04fb725-d8b4-43f1-811d-8267e8761430	2	\N	خوشگله	سلام جیگر	high	in_progress	f04fb725-d8b4-43f1-811d-8267e8761430	تست انبار	\N	\N	\N	\N	\N	\N	\N	2026-02-20 21:22:28.115907+00	2026-02-20 21:26:31.220173+00
\.


--
-- Data for Name: treasury_banks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.treasury_banks (id, bank_name, branch_name, account_no, sheba_no, card_no, tafsili_id, created_at, member_id, owner_id, shaba_no, initial_balance, description, is_active) FROM stdin;
fa7fcd32-c5f2-b2ed-d466-184bd677dc32	صادرات	\N	878678	\N	\N	b4d28845-9115-a129-2235-aaf260bb2787	2026-01-30 20:56:34.077385+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	\N	0	\N	t
51a89a63-cd63-def6-48ed-c2126854233a	ملت	\N	76575675	\N	\N	5ee414e5-1c66-7ec8-2823-8015d622e1a6	2026-01-30 21:12:35.688326+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	\N	0	\N	t
7956e568-dcdd-1e29-1396-acf3f9dbbbc7	صادرات	\N	7656756	\N	\N	153810e3-6d65-d46f-f2f5-c775d5430aed	2026-01-30 21:25:23.512368+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	\N	0	\N	t
aca210e0-e628-37b1-a65f-ba14926bef53	تجارت	\N	64654564	\N	\N	005997f3-7a69-42ee-238d-02b92c147c9f	2026-02-07 18:39:02.294597+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	\N	0	\N	t
cb22769d-a989-3a07-6f13-3e490a7d1945	پاسارگاد	\N	67564564-98-899	\N	\N	db32264d-c759-1996-37f0-fd1800522a54	2026-02-07 18:55:28.070603+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	\N	0	\N	t
32faf08b-bfc3-b5ea-c940-56137e66d2f4	ملت	\N	882773663	\N	\N	e7033a0e-dbc0-e33e-21b9-93484e7a92a1	2026-02-21 08:32:20.279708+00	f04fb725-d8b4-43f1-811d-8267e8761430	\N	\N	0	\N	t
\.


--
-- Data for Name: treasury_cashes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.treasury_cashes (id, title, keeper_name, tafsili_id, created_at, member_id, initial_balance, description, is_active) FROM stdin;
acf66379-03b0-775c-74df-8297c50bd6fe	786	\N	ac3dc153-0995-6893-16b5-7e04baf7f559	2026-01-30 20:59:40.377225+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	0	\N	t
104c14e9-a833-1b7e-308f-00808f71e718	yugu	\N	4a50a421-071a-1824-70af-da7d7dbe41b0	2026-01-30 21:25:33.572088+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	0	\N	t
135c309d-e1cb-7ed3-b243-cac11d095158	صندوق انبار	\N	2cae6253-377a-0faf-b890-7c870d707ba0	2026-02-22 06:01:47.469782+00	f04fb725-d8b4-43f1-811d-8267e8761430	0	\N	t
\.


--
-- Data for Name: treasury_check_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.treasury_check_details (id, checkbook_id, serial_no, status, check_id, created_at, member_id) FROM stdin;
\.


--
-- Data for Name: treasury_checkbooks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.treasury_checkbooks (id, bank_id, serial_start, serial_end, current_serial, status, created_at, member_id, description) FROM stdin;
9c2dd394-0a1c-1bee-fe9d-b4a3cdc1a004	fa7fcd32-c5f2-b2ed-d466-184bd677dc32	12	25	12	active	2026-01-30 21:06:27.108912+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N
\.


--
-- Data for Name: treasury_checks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.treasury_checks (id, type, amount, cheque_no, bank_name, branch_name, due_date, status, owner_id, receiver_id, checkbook_id, created_at, sayadi_code, branch_code, account_no, account_holder, description, endorsement, target_bank_id, member_id, last_sms_reminder) FROM stdin;
5431fbb3-4e33-4967-864f-09f25d37e3e7	payable	60000000	12	صادرات	\N	\N	bounced	\N	\N	9c2dd394-0a1c-1bee-fe9d-b4a3cdc1a004	2026-02-19 06:47:29.771927+00	6564654535434533	\N	\N	\N	\N	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N
9a2b56d1-a932-4f3c-ba48-c7dc1337bc47	payable	30020000	12	صادرات	\N	\N	passed	\N	c0d34ee7-9211-bc5b-9f74-56569d751cee	9c2dd394-0a1c-1bee-fe9d-b4a3cdc1a004	2026-02-19 06:56:00.030543+00	9983876765646545	\N	\N	حامل	صدور به حسینی 666	\N	fa7fcd32-c5f2-b2ed-d466-184bd677dc32	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N
923721c1-670d-42e8-8849-0610ff5693e6	receivable	45000000	654646	ملی	\N	\N	spent	c0d34ee7-9211-bc5b-9f74-56569d751cee	e041f769-4ea6-4a91-b246-73f1d8574f9f	\N	2026-02-19 07:29:20.259807+00	5456764753543453	\N	\N	\N	خرج به محمدی	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N
\.


--
-- Data for Name: treasury_pos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.treasury_pos (id, title, bank_id, terminal_id, tafsili_id, created_at, member_id, description, is_active) FROM stdin;
ece1042f-a55b-a757-f376-dbc7e79f74ba	تندت	fa7fcd32-c5f2-b2ed-d466-184bd677dc32	\N	0ff31ab4-caa7-842d-acf4-6e6ec831c18e	2026-01-30 20:59:49.376298+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	t
ac04bade-f1d7-3e36-fa0c-f5dab52b4ee6	پوز پاسارگاد	cb22769d-a989-3a07-6f13-3e490a7d1945	\N	2ed159ac-23e0-aa64-7ae2-565069027ff3	2026-02-07 18:56:04.641674+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	t
82fb6891-93be-dd24-1786-b471757c5f06	hhh	cb22769d-a989-3a07-6f13-3e490a7d1945	\N	01f80c12-6740-42d1-0dd7-690e29d1606d	2026-02-16 11:33:51.886382+00	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	t
5d47c395-68a7-7617-aab2-cce31f46aeaa	ملت	32faf08b-bfc3-b5ea-c940-56137e66d2f4	\N	f7a0ac06-bb1c-866e-0eba-0b592a64d543	2026-02-22 06:01:59.839512+00	f04fb725-d8b4-43f1-811d-8267e8761430	\N	t
\.


--
-- Data for Name: ui_form_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ui_form_permissions (id, form_id, permission_id, required_for) FROM stdin;
52519385-edc1-4800-b942-58716459a85b	6d5052ad-eb66-4792-b714-569101b2f0d0	c43c2429-2131-4b34-8fba-af951d48fb75	view
cce24a52-14e9-485a-9d0c-4f4e14698c26	743424ee-e9de-4d99-857f-bc1a8d7d7ba0	805d7f41-29ed-45b5-9d34-e53b7a102c11	view
6c03d452-9b96-41da-b213-68d03623fbd1	eaed5ddc-0423-4c78-a932-53903ef7e82e	21c5d345-00c5-4a98-ab21-fefc75f813c8	view
1fb7d606-3a1d-4cac-9955-64913381d24c	03c3c822-2dc6-4e9f-b7b0-81fa7afb247f	bf43cd27-51cc-4ce4-85c6-a5e2b5682cb0	view
a196a102-7dd7-4fd5-9520-5143dd8c1a62	db671cc3-08a8-4a7f-9727-a41e368b4e0c	36b544a4-f50a-42fe-b36f-4c9aa1126f5f	view
4e13ab6d-c8a8-4205-9a8f-03616a08076e	8192e9c2-3196-46fc-ad63-c88fca2417ac	afb85844-0f71-4041-8914-db0700409691	view
05583248-d970-4a8b-94c8-921fd8c4c997	4762233e-0862-4a50-87eb-e47c7e78c454	0b286a7b-b307-44c1-ad35-d1f7feb699f5	view
d0be61bb-32e0-4826-a2bf-b7ef9cf3c6b2	935e2157-df38-4aa1-aec5-2fcff13fc6e4	9aebdf5c-dfab-4253-9022-e0b526360fc2	view
45871f7e-4d08-4c97-b941-fea088022e42	86c2ea81-4687-4ee6-8772-8d4c222dda32	afb85844-0f71-4041-8914-db0700409691	view
94d57ec3-e960-4781-8bd1-2e25199e4b54	a63d2b80-06f8-41fd-891d-aca5c0c669bc	805d7f41-29ed-45b5-9d34-e53b7a102c11	view
a5730cfd-3e05-485a-b5df-1b94d73d712a	63f81d55-b562-4f5c-afbc-84eabf89ffc2	21c5d345-00c5-4a98-ab21-fefc75f813c8	view
f32e58c1-bb75-4cbc-a446-5ef51214a084	80df6fd7-9252-4963-966a-2f57f814dbf3	36b544a4-f50a-42fe-b36f-4c9aa1126f5f	view
\.


--
-- Data for Name: ui_forms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ui_forms (id, member_id, form_code, title, route, module, icon, parent_id, menu_order, is_menu_item, is_active, created_at, updated_at, path, permission_code) FROM stdin;
8b193544-e27d-4a9f-8187-7c395fa82b93	dc66ad9a-8bc5-4556-9860-aeab96211fa3	receipt-form	ثبت رسید جدید	/receipt/form	receipt	\N	\N	2	t	t	2026-02-09 09:39:26.242006+00	2026-02-20 19:39:31.226704+00	\N	\N
86c2ea81-4687-4ee6-8772-8d4c222dda32	dc66ad9a-8bc5-4556-9860-aeab96211fa3	receipts.group	رسیدها	#	receipt	bx-receipt	\N	20	t	t	2026-02-09 08:42:52.980497+00	2026-02-09 08:42:52.980497+00	\N	\N
a63d2b80-06f8-41fd-891d-aca5c0c669bc	dc66ad9a-8bc5-4556-9860-aeab96211fa3	clearances.group	حواله‌ها	#	clearance	bx-transfer	\N	30	t	t	2026-02-09 08:42:52.980497+00	2026-02-09 08:42:52.980497+00	\N	\N
63f81d55-b562-4f5c-afbc-84eabf89ffc2	dc66ad9a-8bc5-4556-9860-aeab96211fa3	products.group	کالا و انبار	#	product	bx-box	\N	40	t	t	2026-02-09 08:42:52.980497+00	2026-02-09 08:42:52.980497+00	\N	\N
80df6fd7-9252-4963-966a-2f57f814dbf3	dc66ad9a-8bc5-4556-9860-aeab96211fa3	financial.group	مالی	#	financial	bx-file	\N	60	t	t	2026-02-09 08:42:52.980497+00	2026-02-09 08:42:52.980497+00	\N	\N
8192e9c2-3196-46fc-ad63-c88fca2417ac	dc66ad9a-8bc5-4556-9860-aeab96211fa3	receipts.list	لیست رسیدها	/receipts	receipt	bx-receipt	86c2ea81-4687-4ee6-8772-8d4c222dda32	20	t	t	2026-02-07 19:28:53.849749+00	2026-02-09 08:42:52.988929+00	\N	\N
4762233e-0862-4a50-87eb-e47c7e78c454	dc66ad9a-8bc5-4556-9860-aeab96211fa3	receipts.create	ثبت رسید	/receipts/new	receipt	bx-plus-circle	86c2ea81-4687-4ee6-8772-8d4c222dda32	21	t	t	2026-02-07 19:28:53.849749+00	2026-02-09 08:42:52.988929+00	\N	\N
743424ee-e9de-4d99-857f-bc1a8d7d7ba0	dc66ad9a-8bc5-4556-9860-aeab96211fa3	clearances.list	لیست حواله‌ها	/clearances	clearance	bx-transfer	a63d2b80-06f8-41fd-891d-aca5c0c669bc	30	t	t	2026-02-07 19:28:53.849749+00	2026-02-09 08:42:52.988929+00	\N	\N
935e2157-df38-4aa1-aec5-2fcff13fc6e4	dc66ad9a-8bc5-4556-9860-aeab96211fa3	clearances.create	ثبت حواله خروج	/clearances/new	clearance	bx-export	a63d2b80-06f8-41fd-891d-aca5c0c669bc	31	t	t	2026-02-07 19:28:53.849749+00	2026-02-09 08:42:52.988929+00	\N	\N
eaed5ddc-0423-4c78-a932-53903ef7e82e	dc66ad9a-8bc5-4556-9860-aeab96211fa3	products.list	کالاها	/products	product	bx-box	63f81d55-b562-4f5c-afbc-84eabf89ffc2	40	t	t	2026-02-07 19:28:53.849749+00	2026-02-09 08:42:52.988929+00	\N	\N
03c3c822-2dc6-4e9f-b7b0-81fa7afb247f	dc66ad9a-8bc5-4556-9860-aeab96211fa3	inventory.stock	موجودی انبار	/inventory/stock	inventory	bx-archive	63f81d55-b562-4f5c-afbc-84eabf89ffc2	50	t	t	2026-02-07 19:28:53.849749+00	2026-02-09 08:42:52.988929+00	\N	\N
db671cc3-08a8-4a7f-9727-a41e368b4e0c	dc66ad9a-8bc5-4556-9860-aeab96211fa3	financial_docs.list	اسناد مالی	/financial-docs	financial	bx-file	80df6fd7-9252-4963-966a-2f57f814dbf3	60	t	t	2026-02-07 19:28:53.849749+00	2026-02-09 08:42:52.988929+00	\N	\N
5444a808-25cf-4e56-b3f6-855f1a7b68b3	dc66ad9a-8bc5-4556-9860-aeab96211fa3	members-add	افزودن عضو	/members/add	member	\N	\N	2	t	t	2026-02-09 09:39:26.242006+00	2026-02-20 19:39:31.241067+00	\N	\N
f846bcaa-f537-4fde-9b98-dfc66fe35afc	dc66ad9a-8bc5-4556-9860-aeab96211fa3	members.list	لیست اعضا	/members/list	member	bx bx-user-plus	\N	7	t	t	2026-02-09 09:39:26.242006+00	2026-02-20 19:39:31.241067+00	/members/list	member.view
f31843e6-8f18-43a3-96ae-3c6cb17254dd	dc66ad9a-8bc5-4556-9860-aeab96211fa3	system-users	مدیریت پرسنل من	/system-users	member	bx bx-user-plus	\N	9	t	t	2026-02-09 09:39:26.242006+00	2026-02-20 19:39:42.428714+00	/system-users	member.manage
e9df5f5e-ceb0-4fba-8c90-bc1f271c7ad2	dc66ad9a-8bc5-4556-9860-aeab96211fa3	customers-list	لیست مشتریان	/customers/list	customer	\N	b0100007-9036-4ce6-9b71-2c9f1c4252b8	1	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
4ea85382-b205-4a0d-b85a-3783384603bf	dc66ad9a-8bc5-4556-9860-aeab96211fa3	customers-add	افزودن مشتری	/customers/add	customer	\N	b0100007-9036-4ce6-9b71-2c9f1c4252b8	2	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
b7d11ab5-ed4f-4e58-b0ef-8e61391a65ec	dc66ad9a-8bc5-4556-9860-aeab96211fa3	products-list	لیست کالاها	/inventory/product-list	inventory	\N	cbddab10-c54d-40c2-9b22-fe3679bdc1cd	1	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
978bb9a1-7c2e-474b-a3f9-f912628b3fb7	dc66ad9a-8bc5-4556-9860-aeab96211fa3	products-add	افزودن کالا	/inventory/add-product	inventory	\N	cbddab10-c54d-40c2-9b22-fe3679bdc1cd	2	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
1931de10-d80e-4bdb-b050-bfb5b6839aba	dc66ad9a-8bc5-4556-9860-aeab96211fa3	categories-list	دسته‌بندی‌ها	/inventory/category-list	inventory	\N	cbddab10-c54d-40c2-9b22-fe3679bdc1cd	3	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
7809ec23-64ff-4af0-bc03-067f644c203d	dc66ad9a-8bc5-4556-9860-aeab96211fa3	units-list	واحدها	/inventory/unit-list	inventory	\N	cbddab10-c54d-40c2-9b22-fe3679bdc1cd	4	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
1db3b93a-9a63-4b10-b060-8c073043e7f3	dc66ad9a-8bc5-4556-9860-aeab96211fa3	loading-list	لیست بارگیری	/loading/list	loading	\N	148fba9a-a70b-4e27-9a3b-9a85dc278799	1	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
5b8588eb-f459-49c7-9a7a-b5fd0c5572a1	dc66ad9a-8bc5-4556-9860-aeab96211fa3	loading-create	ثبت بارگیری	/loading/create	loading	\N	148fba9a-a70b-4e27-9a3b-9a85dc278799	2	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
6044279c-30cf-4979-b953-73658712a7f2	dc66ad9a-8bc5-4556-9860-aeab96211fa3	exit-list	لیست خروج نهایی	/exit/list	exit	\N	148fba9a-a70b-4e27-9a3b-9a85dc278799	3	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
ec139ff7-51c5-4f75-9d5a-b746a9b35343	dc66ad9a-8bc5-4556-9860-aeab96211fa3	exit-create	ثبت خروج	/exit/create	exit	\N	148fba9a-a70b-4e27-9a3b-9a85dc278799	4	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
a7ad3613-8fe8-4f7f-9981-ff6b0da908ed	dc66ad9a-8bc5-4556-9860-aeab96211fa3	clearance-report	گزارش ترخیص	/clearances/report	clearance	\N	87549392-872e-4ffc-9b5f-466feb698480	2	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
2de58e73-0407-4a7a-a01f-262843832235	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting-documents	دفتر اسناد	/accounting/documents	accounting	\N	e4a348d8-62dc-4fd6-a661-ce54870c5987	1	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
3c6ac164-a824-472f-b7dc-b34feea04e82	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting-new	ثبت سند جدید	/accounting/new	accounting	\N	e4a348d8-62dc-4fd6-a661-ce54870c5987	2	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
b0100007-9036-4ce6-9b71-2c9f1c4252b8	dc66ad9a-8bc5-4556-9860-aeab96211fa3	customers	مشتریان	#	customer	bx bx-group	\N	3	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:51:04.244278+00	\N	\N
cbddab10-c54d-40c2-9b22-fe3679bdc1cd	dc66ad9a-8bc5-4556-9860-aeab96211fa3	inventory	مدیریت کالا	#	inventory	bx bx-cube	\N	4	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:51:04.244278+00	\N	\N
148fba9a-a70b-4e27-9a3b-9a85dc278799	dc66ad9a-8bc5-4556-9860-aeab96211fa3	loading-exit	بارگیری و خروج	#	loading	bx bx-truck	\N	6	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:51:04.244278+00	\N	\N
87549392-872e-4ffc-9b5f-466feb698480	dc66ad9a-8bc5-4556-9860-aeab96211fa3	clearance	ترخیص کالا	#	clearance	bx bx-check-shield	\N	7	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:51:04.244278+00	\N	\N
e4a348d8-62dc-4fd6-a661-ce54870c5987	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting	حسابداری	#	accounting	bx bx-money	\N	8	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:51:04.244278+00	\N	\N
6d5052ad-eb66-4792-b714-569101b2f0d0	dc66ad9a-8bc5-4556-9860-aeab96211fa3	dashboard.main	داشبورد	/dashboard	dashboard	bx-home-circle	\N	1	t	t	2026-02-07 19:28:53.849749+00	2026-02-20 19:32:12.413062+00	/dashboard	\N
ae3e5a64-d3ac-4081-8a95-3c90f069634b	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting-coding	کدینگ حسابداری	/accounting/coding	accounting	\N	e4a348d8-62dc-4fd6-a661-ce54870c5987	3	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
89975037-898f-4db0-8633-08deca7ec00f	dc66ad9a-8bc5-4556-9860-aeab96211fa3	reports-journal	دفتر روزنامه	/accounting/reports/journal	accounting	\N	9847209e-5a08-4773-ab92-3afa9698d3c2	1	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
5b57b314-d5ea-43db-91cf-61f654e1c4a0	dc66ad9a-8bc5-4556-9860-aeab96211fa3	reports-customers	مانده مشتریان	/accounting/reports/customers	accounting	\N	9847209e-5a08-4773-ab92-3afa9698d3c2	2	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
c078e621-bf22-495f-90bc-822dd48ff986	dc66ad9a-8bc5-4556-9860-aeab96211fa3	reports-ledger	دفتر معین	/accounting/reports/ledger	accounting	\N	9847209e-5a08-4773-ab92-3afa9698d3c2	3	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
5b3d9002-75e9-43a9-8d4b-c9f42e4710a9	dc66ad9a-8bc5-4556-9860-aeab96211fa3	reports-comprehensive	گزارش جامع	/accounting/reports/comprehensive	accounting	\N	9847209e-5a08-4773-ab92-3afa9698d3c2	4	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
1c0bdc43-6bd5-42c1-a760-c317e3f7c966	dc66ad9a-8bc5-4556-9860-aeab96211fa3	treasury-list	لیست اسناد	/accounting/list	accounting	\N	177a4f71-496d-4b32-8771-c3161c609b51	1	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
c8340617-368f-4971-98a9-f8e240dee932	dc66ad9a-8bc5-4556-9860-aeab96211fa3	treasury-checks	عملیات چک	/accounting/check-operations	accounting	\N	177a4f71-496d-4b32-8771-c3161c609b51	2	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
25faa690-3999-48b7-8e0d-334d4198f708	dc66ad9a-8bc5-4556-9860-aeab96211fa3	treasury-definitions	تعاریف خزانه‌داری	/accounting/definitions	accounting	\N	177a4f71-496d-4b32-8771-c3161c609b51	3	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
5303c35f-8e5f-485a-b151-1446f6e51702	dc66ad9a-8bc5-4556-9860-aeab96211fa3	rent-list	لیست قراردادها	/rent/list	rent	\N	3c4f334f-a5f2-4806-93e5-31107e96b535	1	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
31b6a692-ff13-4e99-9e18-999705ac2f11	dc66ad9a-8bc5-4556-9860-aeab96211fa3	rent-create	ثبت قرارداد جدید	/rent/create	rent	\N	3c4f334f-a5f2-4806-93e5-31107e96b535	2	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:39:26.242006+00	\N	\N
9847209e-5a08-4773-ab92-3afa9698d3c2	dc66ad9a-8bc5-4556-9860-aeab96211fa3	reports	گزارشات مالی	#	accounting	bx bx-stats	\N	9	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:51:04.244278+00	\N	\N
177a4f71-496d-4b32-8771-c3161c609b51	dc66ad9a-8bc5-4556-9860-aeab96211fa3	treasury	خزانه‌داری	#	accounting	bx bx-wallet	\N	10	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:51:04.244278+00	\N	\N
3c4f334f-a5f2-4806-93e5-31107e96b535	dc66ad9a-8bc5-4556-9860-aeab96211fa3	rent	اجاره انبار	#	rent	bx bx-building-house	\N	11	t	t	2026-02-09 09:39:26.242006+00	2026-02-09 09:51:04.244278+00	\N	\N
f0574eae-238e-46a9-8fc4-c8b453107f82	dc66ad9a-8bc5-4556-9860-aeab96211fa3	customers.list	لیست مشتریان	/customers/list	customer	bx bx-group	\N	5	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/customers/list	customer.view
16492646-b0e0-409e-ab51-5491dcd88c93	dc66ad9a-8bc5-4556-9860-aeab96211fa3	customers.add	افزودن مشتری	/customers/add	customer	bx bx-group	\N	6	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/customers/add	customer.create
32763ed2-6a95-49e0-b41d-75b5623f5fb7	dc66ad9a-8bc5-4556-9860-aeab96211fa3	members.add	افزودن عضو	/members/add	member	bx bx-user-plus	\N	8	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/members/add	member.create
247b328f-a1fa-44c9-868d-45fc082efaef	dc66ad9a-8bc5-4556-9860-aeab96211fa3	receipts-list	لیست رسیدها	/receipts	receipt	bx bx-log-in-circle	\N	15	t	t	2026-02-09 09:39:26.242006+00	2026-02-20 19:39:42.416625+00	/receipts	receipt.view
3766f435-10d3-4eba-8355-27e15de53faf	dc66ad9a-8bc5-4556-9860-aeab96211fa3	inventory.product-list	لیست کالاها	/inventory/product-list	inventory	bx bx-cube	\N	10	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/inventory/product-list	inventory.view
d1437021-393b-4598-83d8-82e8d40f9969	dc66ad9a-8bc5-4556-9860-aeab96211fa3	inventory.add-product	افزودن کالا	/inventory/add-product	inventory	bx bx-cube	\N	11	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/inventory/add-product	inventory.create
5131c0cf-04c4-4fd7-a4b2-f6860ccf954e	dc66ad9a-8bc5-4556-9860-aeab96211fa3	inventory.category-list	دسته‌بندی‌ها	/inventory/category-list	inventory	bx bx-cube	\N	12	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/inventory/category-list	inventory.view
2fbea727-248b-4b35-ae99-dd0aeb75762e	dc66ad9a-8bc5-4556-9860-aeab96211fa3	inventory.unit-list	واحدها	/inventory/unit-list	inventory	bx bx-cube	\N	13	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/inventory/unit-list	inventory.view
74ace642-3733-489b-a914-6608867bea9b	dc66ad9a-8bc5-4556-9860-aeab96211fa3	receipt.form	ثبت رسید جدید	/receipt/form	receipt	bx bx-log-in-circle	\N	16	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/receipt/form	receipt.create
3304e287-6e01-43be-90ba-f9cd6e63e088	dc66ad9a-8bc5-4556-9860-aeab96211fa3	clearances.report	گزارش ترخیص	/clearances/report	clearance	bx bx-check-shield	\N	18	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/clearances/report	clearance.view
0c64460e-ed00-46e6-ab9c-264f1336980c	dc66ad9a-8bc5-4556-9860-aeab96211fa3	clearances.form	ثبت ترخیص	/clearances/form	clearance	bx bx-check-shield	\N	19	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/clearances/form	clearance.create
208606b6-380a-43a1-a831-8a80ab81257b	dc66ad9a-8bc5-4556-9860-aeab96211fa3	loading.list	لیست بارگیری	/loading/list	loading	bx bx-truck	\N	20	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/loading/list	loading.view
cbfb71aa-99f6-4f36-ae09-a253f24ecd61	dc66ad9a-8bc5-4556-9860-aeab96211fa3	calendar	تقویم عملیات	/calendar	calendar	bx bx-calendar	\N	2	t	t	2026-02-20 19:32:12.413062+00	2026-02-20 19:32:12.413062+00	/calendar	calendar.view
635a1468-a513-43a8-82c3-2c02a8d23380	dc66ad9a-8bc5-4556-9860-aeab96211fa3	loading.create	ثبت بارگیری	/loading/create	loading	bx bx-truck	\N	21	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/loading/create	loading.create
0e35c37a-2699-4108-9d45-8f38ea422dca	dc66ad9a-8bc5-4556-9860-aeab96211fa3	exit.list	لیست خروج نهایی	/exit/list	exit	bx bx-truck	\N	22	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/exit/list	exit.view
11a59a16-b1db-411c-8fa9-457282522f31	dc66ad9a-8bc5-4556-9860-aeab96211fa3	exit.create	ثبت خروج	/exit/create	exit	bx bx-truck	\N	23	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/exit/create	exit.create
b6ad121a-1cec-4007-9d94-68a826d42700	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.documents	دفتر اسناد	/accounting/documents	accounting	bx bx-money	\N	25	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/accounting/documents	accounting.view
505b128f-1396-45cd-b4b9-01532309296a	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.new	ثبت سند جدید	/accounting/new	accounting	bx bx-money	\N	26	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/accounting/new	accounting.create
be301a9a-a5b6-4434-8934-58166c9d2311	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.coding	کدینگ حسابداری	/accounting/coding	accounting	bx bx-money	\N	27	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/accounting/coding	accounting.create
0c63eb5a-4414-4ab9-a46d-b303b932e8a8	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.treasury-form	دریافت / پرداخت	/accounting/treasury-form	accounting	bx bx-wallet	\N	28	t	t	2026-02-20 19:32:12.413062+00	2026-02-20 19:32:12.413062+00	/accounting/treasury-form	accounting.treasury
af909c30-f568-4a6b-a5ce-98c66f8786f5	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.list	لیست اسناد	/accounting/list	accounting	bx bx-wallet	\N	29	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/accounting/list	accounting.treasury
625f45f4-572e-4e01-a0bf-8d5071910aba	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.check-operations	عملیات چک	/accounting/check-operations	accounting	bx bx-wallet	\N	31	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/accounting/check-operations	accounting.treasury
b695ae1c-acb0-4bb6-a9a1-f23a33116f5c	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.definitions	تعاریف خزانه‌داری	/accounting/definitions	accounting	bx bx-wallet	\N	32	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/accounting/definitions	accounting.treasury
2c5684f6-1be4-4093-9a02-b886dbbff907	dc66ad9a-8bc5-4556-9860-aeab96211fa3	rent.list	لیست قراردادها	/rent/list	rent	bx bx-building-house	\N	35	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/rent/list	rent.list
a22655e3-77a3-4a77-80a0-c50abf139ad7	dc66ad9a-8bc5-4556-9860-aeab96211fa3	rent.create	ثبت قرارداد جدید	/rent/create	rent	bx bx-building-house	\N	36	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/rent/create	rent.create
8b489e3c-992d-4a9a-b8d8-f5b7b65b5406	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.reports.treasury	موجودی خزانه	/accounting/reports/treasury	accounting	bx bx-line-chart	\N	40	t	t	2026-02-20 19:32:12.413062+00	2026-02-20 19:32:12.413062+00	/accounting/reports/treasury	accounting.reports
ab58153e-0642-4df0-8ee0-b66df218f8f8	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.reports.customers	مانده مشتریان	/accounting/reports/customers	accounting	bx bx-stats	\N	41	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/accounting/reports/customers	accounting.reports
2e6e4389-e0e8-4068-a3bf-ae67d087a700	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.reports.ledger	دفتر معین	/accounting/reports/ledger	accounting	bx bx-stats	\N	42	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/accounting/reports/ledger	accounting.reports
61a8c829-3d74-4130-bf3d-780d7c18a4a4	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.reports.comprehensive	گزارش جامع	/accounting/reports/comprehensive	accounting	bx bx-stats	\N	43	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/accounting/reports/comprehensive	accounting.reports
b12cdddd-5f50-4f28-9a45-08b5762c9e91	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.reports.journal	دفتر روزنامه	/accounting/reports/journal	accounting	bx bx-stats	\N	44	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/accounting/reports/journal	accounting.reports
7c2a30fe-cb85-4081-bb5a-54a49a9e2cce	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.reports.kardex	کاردکس کالا	/accounting/reports/kardex	accounting	bx bx-package	\N	45	t	t	2026-02-20 19:32:12.413062+00	2026-02-20 19:32:12.413062+00	/accounting/reports/kardex	accounting.reports
f44d678d-d33d-4a55-bce8-ebd8ed20bb9b	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.reports.stock	موجودی انبار	/accounting/reports/stock	accounting	bx bx-package	\N	46	t	t	2026-02-20 19:32:12.413062+00	2026-02-20 19:32:12.413062+00	/accounting/reports/stock	accounting.reports
8a4f32b9-829d-4d1a-b46e-17c9bcb0af23	dc66ad9a-8bc5-4556-9860-aeab96211fa3	accounting.reports.analytics	گزارش نموداری	/accounting/reports/analytics	accounting	bx bx-bar-chart-alt-2	\N	47	t	t	2026-02-20 19:32:12.413062+00	2026-02-20 19:32:12.413062+00	/accounting/reports/analytics	accounting.reports
62278e9b-6321-40b7-b0dd-9a7bea8f7148	dc66ad9a-8bc5-4556-9860-aeab96211fa3	settings.warehouse	تنظیمات انبار	/settings/warehouse	settings	bx bx-buildings	\N	50	t	t	2026-02-20 19:32:12.413062+00	2026-02-20 19:32:12.413062+00	/settings/warehouse	settings.warehouse
8c446a4a-e40e-4fd0-bea6-69e968cc72e4	dc66ad9a-8bc5-4556-9860-aeab96211fa3	settings.forms	تنظیمات فرم‌ها	/settings/forms	settings	bx bx-customize	\N	51	t	t	2026-02-20 19:32:12.413062+00	2026-02-20 19:32:12.413062+00	/settings/forms	settings.warehouse
c3977c0d-85d5-472b-bfab-bed81751b1bb	dc66ad9a-8bc5-4556-9860-aeab96211fa3	settings.roles	نقش‌ها	/settings/roles	settings	bx bx-cog	\N	52	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/settings/roles	settings.roles.view
d4ceeacf-20a7-49a1-b9e3-57c12f3bbdaf	dc66ad9a-8bc5-4556-9860-aeab96211fa3	settings.user-roles	تخصیص نقش کاربران	/settings/user-roles	settings	bx bx-cog	\N	53	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/settings/user-roles	settings.user-roles.view
1d8ea876-a8bb-4205-96f9-7e33d43d65bd	dc66ad9a-8bc5-4556-9860-aeab96211fa3	settings.ui-forms	مدیریت منوها	/settings/ui-forms	settings	bx bx-cog	\N	54	t	t	2026-02-13 08:49:12.170249+00	2026-02-20 19:32:12.413062+00	/settings/ui-forms	settings.ui-forms.view
4ef851d6-c9a2-4949-8f20-cf7271af9e29	dc66ad9a-8bc5-4556-9860-aeab96211fa3	settings.activity-logs	گزارش فعالیت‌ها	/settings/activity-logs	settings	bx bx-history	\N	55	t	t	2026-02-20 19:32:12.413062+00	2026-02-20 19:32:12.413062+00	/settings/activity-logs	settings.roles.view
90c04a71-b4aa-44d7-84ae-c08ac4e60815	dc66ad9a-8bc5-4556-9860-aeab96211fa3	support.list	لیست تیکت‌ها	/support	support	bx bx-support	\N	60	t	t	2026-02-20 19:32:12.413062+00	2026-02-20 19:32:12.413062+00	/support	support.view
79ff7558-8f45-48ee-a0b8-a81d4fb7a0ab	dc66ad9a-8bc5-4556-9860-aeab96211fa3	support.new	ثبت تیکت جدید	/support/new	support	bx bx-support	\N	61	t	t	2026-02-20 19:32:12.413062+00	2026-02-20 19:32:12.413062+00	/support/new	support.create
c657a7f4-eff2-4e16-ad8b-1946cdf68530	dc66ad9a-8bc5-4556-9860-aeab96211fa3	my-contracts	قراردادهای من	/my-contracts	client	bx bx-file-blank	\N	70	t	t	2026-02-09 09:39:26.242006+00	2026-02-20 19:32:12.413062+00	/my-contracts	client.portal
819b50e3-e65d-4ef6-b069-18716cf6cea4	dc66ad9a-8bc5-4556-9860-aeab96211fa3	my-inventory	موجودی کالای من	/my-inventory	client	bx bx-box	\N	71	t	t	2026-02-09 09:39:26.242006+00	2026-02-20 19:32:12.413062+00	/my-inventory	client.portal
83d90fac-f9cb-4b89-83ce-9751e88d0f34	dc66ad9a-8bc5-4556-9860-aeab96211fa3	my-invoices	صورتحساب‌های من	/my-invoices	client	bx bx-receipt	\N	72	t	t	2026-02-09 09:39:26.242006+00	2026-02-20 19:32:12.413062+00	/my-invoices	client.portal
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (id, member_id, user_id, role_id, is_active, valid_from, valid_to, created_at) FROM stdin;
7254985b-8815-4a8a-82eb-322b0640afc3	dc66ad9a-8bc5-4556-9860-aeab96211fa3	296d96ed-280c-4fd3-b4cf-062c0771d34a	ad7d48a8-2ace-425d-a20c-23bee0d6aeef	t	2026-02-07 19:34:28.538846+00	\N	2026-02-07 19:34:28.538846+00
909c5572-1e92-4e60-a5fb-9a519d297d19	dc66ad9a-8bc5-4556-9860-aeab96211fa3	296d96ed-280c-4fd3-b4cf-062c0771d34a	7d30e79a-192e-4ef1-a036-c34029f7ab68	t	2026-02-09 10:45:20.025759+00	\N	2026-02-09 10:45:20.025759+00
8ad6723f-4a2f-42bd-9934-d9975e5a382a	dc66ad9a-8bc5-4556-9860-aeab96211fa3	296d96ed-280c-4fd3-b4cf-062c0771d34a	d4f79e56-5370-4cd0-8fa9-5ad16a0550ec	t	2026-02-10 05:21:23.823764+00	\N	2026-02-10 05:21:23.823764+00
64782389-4639-4fd6-8418-87c67cdce486	dc66ad9a-8bc5-4556-9860-aeab96211fa3	dc66ad9a-8bc5-4556-9860-aeab96211fa3	7cf59422-66bf-420e-b729-876e0046e974	t	2026-02-10 00:00:00+00	\N	2026-02-10 07:51:22.115603+00
31ea6d85-e2a9-4543-9601-fbce6c11b39c	f04fb725-d8b4-43f1-811d-8267e8761430	f04fb725-d8b4-43f1-811d-8267e8761430	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-20 18:44:15.262+00	\N	2026-02-20 18:44:15.264052+00
6171faf1-91e0-49ed-885d-580cd7f580c4	154dd939-db03-477b-9cbb-64fc7f3ab632	154dd939-db03-477b-9cbb-64fc7f3ab632	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-22 10:22:45.904+00	\N	2026-02-22 10:22:45.90603+00
be964612-d172-4c74-8f0c-5c79de680b49	59887725-ed67-4e9d-a9ef-a58643927dba	59887725-ed67-4e9d-a9ef-a58643927dba	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-22 10:24:27.473+00	\N	2026-02-22 10:24:27.473793+00
417b8f47-a86a-478b-8592-81a2ea53dc26	8aac9fa5-23f9-42a8-a993-1c6d3a13e9e3	8aac9fa5-23f9-42a8-a993-1c6d3a13e9e3	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-22 10:27:54.396+00	\N	2026-02-22 10:27:54.397171+00
5bade896-d10e-466b-8305-16ec93e27254	73edc288-9fc5-4533-9a44-573d8885ee54	73edc288-9fc5-4533-9a44-573d8885ee54	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-22 10:30:26.467+00	\N	2026-02-22 10:30:26.468133+00
99a8e333-cd38-4647-b926-38dc542f3d5f	b4a5c9e2-9ef2-4157-a512-7bb2f082ee6c	b4a5c9e2-9ef2-4157-a512-7bb2f082ee6c	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-22 10:31:36.838+00	\N	2026-02-22 10:31:36.83947+00
ed03d3c8-6f3e-47a7-a31e-30163c7772a7	9959c0fe-fa21-477b-a2cf-8c88480e2594	9959c0fe-fa21-477b-a2cf-8c88480e2594	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-22 10:48:08.293+00	\N	2026-02-22 10:48:08.294282+00
aa6dbef2-6a26-4627-a5ea-4f8f1643e63c	062577bc-23b6-4c0f-9641-0b5d1e7d4cbe	062577bc-23b6-4c0f-9641-0b5d1e7d4cbe	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-22 14:46:20.237+00	\N	2026-02-22 14:46:20.238217+00
1537ca1b-caab-4ad4-b1e8-f0c8b1482724	4a8e5835-42cc-4d7c-b1f7-37e9ca76867d	4a8e5835-42cc-4d7c-b1f7-37e9ca76867d	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-22 14:47:22.335+00	\N	2026-02-22 14:47:22.336165+00
e064574c-fb3e-42b8-9565-d8bd1515271d	b5021974-30e8-41d3-acec-126d65f18aef	b5021974-30e8-41d3-acec-126d65f18aef	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-22 14:57:38.554+00	\N	2026-02-22 14:57:38.554991+00
929b13a6-77c5-40ae-8975-071dcda7b67f	0eea2ebb-1509-4c6c-bf5c-700059af00ee	0eea2ebb-1509-4c6c-bf5c-700059af00ee	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-22 15:15:14.061+00	\N	2026-02-22 15:15:14.06253+00
2bf549c7-9c15-4766-b407-0763053c0c2e	6db94b4c-c2ba-4b1f-a0b5-cbcab397fb0b	6db94b4c-c2ba-4b1f-a0b5-cbcab397fb0b	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-22 17:11:00.942+00	\N	2026-02-22 17:11:00.943622+00
d96b73f1-14b1-40f9-b9de-a5f10abc752f	e29c3318-c198-46ef-9d9c-1d163b90f05e	e29c3318-c198-46ef-9d9c-1d163b90f05e	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-23 18:49:07.936+00	\N	2026-02-23 18:49:07.938119+00
09accf8b-ee10-4fbc-90a1-744046c0ea0a	656ecd50-d476-489c-936c-3b36f501fc84	656ecd50-d476-489c-936c-3b36f501fc84	dc28392f-8a08-4df2-9df6-67d7c08e6826	t	2026-02-23 19:01:49.022+00	\N	2026-02-23 19:01:49.022715+00
\.


--
-- Data for Name: warehouse_exit_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_exit_items (id, warehouse_exit_id, loading_item_id, weight_full, weight_empty, weight_net, fee_type, fee_price, final_fee, created_at, loading_fee, qty) FROM stdin;
23f8871e-6891-4ee1-978a-af45f442a84d	14029359-20ee-46ad-a00a-1eba4f4befad	88a266e8-5369-4c9a-b11b-9d045237f307	4350	1600	2750	weight	2000	5500000	2026-02-16 11:48:20.750589	9625000	2
ef26ea6d-c6d2-458b-b909-fe23500b0935	f3fa56ae-e458-4ad5-8e50-616776caf769	819695e9-9286-4944-af1d-b0e21fa43900	5650	3570	2080	weight	2000	4160000	2026-02-22 06:00:38.630915	7280000	1
\.


--
-- Data for Name: warehouse_exits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_exits (id, exit_no, loading_order_id, exit_date, total_fee, description, status, created_at, reference_no, total_loading_fee, weighbridge_fee, extra_fee, extra_description, vat_fee, driver_national_code, payment_method, account_id, is_sent_to_tax, owner_id, driver_name, plate_number, financial_account_id, accounting_doc_id, member_id, nwms_id, nwms_status) FROM stdin;
14029359-20ee-46ad-a00a-1eba4f4befad	9001	9d51a432-69d9-4d6b-bde4-d44b34990743	2026-02-16 00:00:00	5500000	ثبت نهایی	final	2026-02-16 11:48:20.750589		9625000	7800000	0		2292500	675675675	credit	\N	f	d300ce05-8008-4bb0-95f1-2eb231fb4346	راننده	88-999-پ-66	\N	a47bc809-ea9b-4f76-a025-21135394c0e3	dc66ad9a-8bc5-4556-9860-aeab96211fa3	\N	not_sent
f3fa56ae-e458-4ad5-8e50-616776caf769	9001	0276dcb6-9304-447b-b70c-dcfe4c4691c9	2026-02-22 00:00:00	4160000	ثبت نهایی	final	2026-02-22 06:00:38.630915		7280000	4000000	0		1544000	564564564	credit	\N	f	2db3438c-0865-4cf1-955e-d9197e63061f	حسینی	88-999-ب-11	\N	c927574d-7476-4494-a301-1d2e3ee7f8b0	f04fb725-d8b4-43f1-811d-8267e8761430	\N	not_sent
\.


--
-- Data for Name: warehouse_rentals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouse_rentals (id, customer_id, start_date, monthly_rent, location_name, rental_type, rental_details, description, billing_cycle, verification_code, contract_file_url, status, created_at, notification_config, last_invoiced_at, end_date, member_id) FROM stdin;
dfbe71ba-96e5-4eed-a599-20e95aa7df31	c0d34ee7-9211-bc5b-9f74-56569d751cee	2026-02-19	23000000	سوله a1	shed	{"metrage": "1000", "containerSize": ""}	\N	monthly	\N	\N	active	2026-02-19 09:16:39.3778+00	[]	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
eb816d4d-0c8e-41b7-b1d8-7377adfe7baa	c0d34ee7-9211-bc5b-9f74-56569d751cee	2026-02-19	1200000	\N	shed	{"metrage": "50", "containerSize": ""}	\N	monthly	\N	\N	active	2026-02-19 11:14:58.917624+00	["monthly"]	\N	\N	dc66ad9a-8bc5-4556-9860-aeab96211fa3
d57b181c-ecd9-4819-8c6e-da239da0d179	96f5f3e7-3dcf-ff73-7c68-ee54dca70d33	2026-02-22	20000000	سوله 1	shed	{"metrage": "1000", "containerSize": ""}	\N	monthly	\N	\N	active	2026-02-22 06:22:11.695169+00	["monthly"]	\N	\N	f04fb725-d8b4-43f1-811d-8267e8761430
\.


--
-- Data for Name: warehouse_settings; Type: TABLE DATA; Schema: public; Owner: union_api
--

COPY public.warehouse_settings (id, member_id, warehouse_name, warehouse_name_en, phone, fax, mobile, email, website, address, postal_code, economic_code, national_id, registration_no, logo_url, stamp_url, header_text, footer_text, province, city, manager_name, manager_phone, description, created_at, updated_at, form_settings) FROM stdin;
c6f39177-eba0-42ac-847e-5b84b5cac59e	dc66ad9a-8bc5-4556-9860-aeab96211fa3	ایران	anbar iran	660000998										/uploads/media/dc66ad9a-8bc5-4556-9860-aeab96211fa3/1771497725148-24551b62345f2-default-logo.png	/uploads/media/dc66ad9a-8bc5-4556-9860-aeab96211fa3/1771497730199-3730a53e45aa-logo.png					حسین زاده			2026-02-19 10:42:28.42554+00	2026-02-20 10:19:27.373907+00	{"exit": {"enableQR": true, "notifyOwner": false, "printFooter": "اقلام فوق طبق درخواست صاحب کالا تحویل داده شد.", "notifyCustomer": false, "ownerSmsTemplate": "حواله خروج شماره {exitNo} توسط {customerName} در تاریخ {date} ثبت شد.", "customerSmsTemplate": "مشتری گرامی {customerName}، حواله خروج شماره {exitNo} در تاریخ {date} برای شما ثبت گردید."}, "receipt": {"enableQR": true, "notifyOwner": false, "printFooter": "اقلام فوق سالم و بدون نقص ظاهری (مگر موارد ذکر شده) تحویل انبار گردید.", "maxWeightDiff": 200, "notifyCustomer": false, "ownerSmsTemplate": "رسید شماره {receiptNo} توسط {customerName} در تاریخ {date} ثبت شد.", "customerSmsTemplate": "مشتری گرامی {customerName}، رسید شماره {receiptNo} در تاریخ {date} برای شما ثبت گردید.", "enforceUniqueParentRow": true}, "integration": {"autoSync": false, "jameApiUrl": "", "jamePassword": "Hadi1984", "jameUsername": "hadi.keshavarzi@gmail.com"}}
4265ded9-9a93-4475-8593-e051875bdfdb	f04fb725-d8b4-43f1-811d-8267e8761430	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-02-22 13:54:40.19099+00	2026-02-22 13:54:40.19099+00	{"exit": {"enableQR": false, "notifyOwner": false, "printFooter": "اقلام فوق طبق درخواست صاحب کالا تحویل داده شد.", "notifyCustomer": true, "ownerSmsTemplate": "خروجی شماره {exitNo} برای {customerName} در تاریخ {date} ثبت شد.", "customerSmsTemplate": "مشتری گرامی {customerName}\\nخروجی کالا با مشخصات زیر ثبت شد:\\n{itemDetails}\\n\\n{warehouseName}"}, "rental": {"notifyCustomer": true, "customerSmsTemplate": "مشتری گرامی {customerName}\\nقرارداد اجاره انبار با مشخصات زیر ثبت شد:\\nمحل: {locationName}\\nمبلغ اجاره: {monthlyRent} ریال\\nتاریخ شروع: {startDate}\\n\\n{warehouseName}"}, "receipt": {"enableQR": false, "notifyOwner": false, "printFooter": "اقلام فوق سالم و بدون نقص ظاهری (مگر موارد ذکر شده) تحویل انبار گردید.", "maxWeightDiff": 0, "notifyCustomer": true, "ownerSmsTemplate": "رسید شماره {receiptNo} برای {customerName} در تاریخ {date} ثبت شد.", "customerSmsTemplate": "مشتری گرامی {customerName}\\nرسید کالا با مشخصات زیر ثبت شد:\\n{itemDetails}\\n\\n{warehouseName}", "enforceUniqueParentRow": true}, "clearance": {"notifyCustomer": true, "customerSmsTemplate": "مشتری گرامی {customerName}\\nکالا با مشخصات زیر ترخیص میشود:\\n{itemDetails}\\n{receiverInfo}\\nکد تایید: {otp}\\nبه منزله اطلاع کامل از ترخیص کالا میباشد.\\n\\n{warehouseName}"}, "integration": {"autoSync": false, "jameApiUrl": "", "jamePassword": "", "jameUsername": ""}}
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: postgres
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-12-08 07:37:21
20211116045059	2025-12-08 07:37:23
20211116050929	2025-12-08 07:37:25
20211116051442	2025-12-08 07:37:27
20211116212300	2025-12-08 07:37:29
20211116213355	2025-12-08 07:37:30
20211116213934	2025-12-08 07:37:32
20211116214523	2025-12-08 07:37:34
20211122062447	2025-12-08 07:37:36
20211124070109	2025-12-08 07:37:37
20211202204204	2025-12-08 07:37:39
20211202204605	2025-12-08 07:37:41
20211210212804	2025-12-08 07:37:46
20211228014915	2025-12-08 07:37:47
20220107221237	2025-12-08 07:37:49
20220228202821	2025-12-08 07:37:51
20220312004840	2025-12-08 07:37:52
20220603231003	2025-12-08 07:37:55
20220603232444	2025-12-08 07:37:57
20220615214548	2025-12-08 07:37:58
20220712093339	2025-12-08 07:38:00
20220908172859	2025-12-08 07:38:02
20220916233421	2025-12-08 07:38:03
20230119133233	2025-12-08 07:38:05
20230128025114	2025-12-08 07:38:07
20230128025212	2025-12-08 07:38:09
20230227211149	2025-12-08 07:38:11
20230228184745	2025-12-08 07:38:12
20230308225145	2025-12-08 07:38:14
20230328144023	2025-12-08 07:38:15
20231018144023	2025-12-08 07:38:17
20231204144023	2025-12-08 07:38:20
20231204144024	2025-12-08 07:38:22
20231204144025	2025-12-08 07:38:23
20240108234812	2025-12-08 07:38:25
20240109165339	2025-12-08 07:38:26
20240227174441	2025-12-08 07:38:29
20240311171622	2025-12-08 07:38:32
20240321100241	2025-12-08 07:38:35
20240401105812	2025-12-08 07:38:40
20240418121054	2025-12-08 07:38:42
20240523004032	2025-12-08 07:38:48
20240618124746	2025-12-08 07:38:50
20240801235015	2025-12-08 07:38:51
20240805133720	2025-12-08 07:38:53
20240827160934	2025-12-08 07:38:54
20240919163303	2025-12-08 07:38:57
20240919163305	2025-12-08 07:38:58
20241019105805	2025-12-08 07:39:00
20241030150047	2025-12-08 07:39:06
20241108114728	2025-12-08 07:39:08
20241121104152	2025-12-08 07:39:10
20241130184212	2025-12-08 07:39:12
20241220035512	2025-12-08 07:39:14
20241220123912	2025-12-08 07:39:15
20241224161212	2025-12-08 07:39:17
20250107150512	2025-12-08 07:39:18
20250110162412	2025-12-08 07:39:20
20250123174212	2025-12-08 07:39:22
20250128220012	2025-12-08 07:39:23
20250506224012	2025-12-08 07:39:25
20250523164012	2025-12-08 07:39:26
20250714121412	2025-12-08 07:39:28
20250905041441	2025-12-08 07:39:30
20251103001201	2025-12-08 07:39:31
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: postgres
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: postgres
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
clearance_attachments	clearance_attachments	\N	2025-12-16 19:10:49.328587+00	2025-12-16 19:10:49.328587+00	t	f	\N	\N	\N	STANDARD
media	media	\N	2025-12-20 13:08:24.789757+00	2025-12-20 13:08:24.789757+00	t	f	\N	\N	\N	STANDARD
documents	documents	\N	2025-12-29 21:21:42.683286+00	2025-12-29 21:21:42.683286+00	t	f	\N	\N	\N	STANDARD
member-files	member-files	\N	2025-12-31 10:03:27.63193+00	2025-12-31 10:03:27.63193+00	t	f	\N	\N	\N	STANDARD
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: postgres
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: postgres
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: postgres
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-12-08 07:35:59.002818
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-12-08 07:35:59.036893
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-12-08 07:35:59.050494
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-12-08 07:35:59.112835
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-12-08 07:35:59.217923
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-12-08 07:35:59.228232
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-12-08 07:35:59.239962
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-12-08 07:35:59.249857
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-12-08 07:35:59.260663
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-12-08 07:35:59.271083
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-12-08 07:35:59.282538
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-12-08 07:35:59.294145
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-12-08 07:35:59.310354
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-12-08 07:35:59.324272
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-12-08 07:35:59.33685
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-12-08 07:35:59.375538
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-12-08 07:35:59.38543
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-12-08 07:35:59.394963
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-12-08 07:35:59.406576
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-12-08 07:35:59.417336
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-12-08 07:35:59.426999
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-12-08 07:35:59.439215
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-12-08 07:35:59.465803
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-12-08 07:35:59.485415
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-12-08 07:35:59.495155
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-12-08 07:35:59.504929
26	objects-prefixes	ef3f7871121cdc47a65308e6702519e853422ae2	2025-12-08 07:35:59.515083
27	search-v2	33b8f2a7ae53105f028e13e9fcda9dc4f356b4a2	2025-12-08 07:35:59.536062
28	object-bucket-name-sorting	ba85ec41b62c6a30a3f136788227ee47f311c436	2025-12-08 07:36:00.40651
29	create-prefixes	a7b1a22c0dc3ab630e3055bfec7ce7d2045c5b7b	2025-12-08 07:36:00.416165
30	update-object-levels	6c6f6cc9430d570f26284a24cf7b210599032db7	2025-12-08 07:36:00.42509
31	objects-level-index	33f1fef7ec7fea08bb892222f4f0f5d79bab5eb8	2025-12-08 07:36:00.434331
32	backward-compatible-index-on-objects	2d51eeb437a96868b36fcdfb1ddefdf13bef1647	2025-12-08 07:36:00.443534
33	backward-compatible-index-on-prefixes	fe473390e1b8c407434c0e470655945b110507bf	2025-12-08 07:36:00.454074
34	optimize-search-function-v1	82b0e469a00e8ebce495e29bfa70a0797f7ebd2c	2025-12-08 07:36:00.457184
35	add-insert-trigger-prefixes	63bb9fd05deb3dc5e9fa66c83e82b152f0caf589	2025-12-08 07:36:00.468169
36	optimise-existing-functions	81cf92eb0c36612865a18016a38496c530443899	2025-12-08 07:36:00.478953
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2025-12-08 07:36:00.490804
38	iceberg-catalog-flag-on-buckets	19a8bd89d5dfa69af7f222a46c726b7c41e462c5	2025-12-08 07:36:00.500729
39	add-search-v2-sort-support	39cf7d1e6bf515f4b02e41237aba845a7b492853	2025-12-08 07:36:00.518261
40	fix-prefix-race-conditions-optimized	fd02297e1c67df25a9fc110bf8c8a9af7fb06d1f	2025-12-08 07:36:00.528558
41	add-object-level-update-trigger	44c22478bf01744b2129efc480cd2edc9a7d60e9	2025-12-08 07:36:00.542249
42	rollback-prefix-triggers	f2ab4f526ab7f979541082992593938c05ee4b47	2025-12-08 07:36:00.554188
43	fix-object-level	ab837ad8f1c7d00cc0b7310e989a23388ff29fc6	2025-12-08 07:36:00.565897
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2025-12-08 07:36:00.576111
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2025-12-08 07:36:00.586037
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2025-12-08 07:36:00.601046
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2025-12-08 07:36:00.612008
48	iceberg-catalog-ids	2666dff93346e5d04e0a878416be1d5fec345d6f	2025-12-08 07:36:00.621256
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2025-12-20 12:56:36.117563
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: postgres
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, level) FROM stdin;
cbcffe5d-19d8-4568-8c6e-e0bb0a12bf86	clearance_attachments	1765912673013_r439k0gr26.png	\N	2025-12-16 19:17:54.710167+00	2025-12-16 19:17:54.710167+00	2025-12-16 19:17:54.710167+00	{"eTag": "\\"f2293888889bdcc11e05ce7aeb5fe089\\"", "size": 288140, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2025-12-16T19:17:55.000Z", "contentLength": 288140, "httpStatusCode": 200}	14ae2435-a7e7-411f-8fa4-c8148f4668f5	\N	{}	1
9f970c76-d654-4408-b23c-0485bf4909bd	media	treasury-documents/treasury_1766236741293.png	\N	2025-12-20 13:19:02.301281+00	2025-12-20 13:19:02.301281+00	2025-12-20 13:19:02.301281+00	{"eTag": "\\"052aa70223b436250dd1494b9e8fcca7\\"", "size": 340426, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2025-12-20T13:19:03.000Z", "contentLength": 340426, "httpStatusCode": 200}	2909df5e-4cdc-49a6-92d3-a79e0d20b39b	\N	{}	2
7e26d4f1-8c84-4708-a1cc-e9ba49d8a82e	media	treasury-documents/treasury_1766237055492.png	\N	2025-12-20 13:24:16.408623+00	2025-12-20 13:24:16.408623+00	2025-12-20 13:24:16.408623+00	{"eTag": "\\"052aa70223b436250dd1494b9e8fcca7\\"", "size": 340426, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2025-12-20T13:24:17.000Z", "contentLength": 340426, "httpStatusCode": 200}	4229d61d-edc5-4da3-835a-465ee2c2f008	\N	{}	2
09b9e6bf-c7a2-4722-8655-03e3a9462e07	media	treasury-documents/treasury_1766237389342.png	\N	2025-12-20 13:29:50.782737+00	2025-12-20 13:29:50.782737+00	2025-12-20 13:29:50.782737+00	{"eTag": "\\"90f68761bb9e1910daf9ad5fc9867374\\"", "size": 278835, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2025-12-20T13:29:51.000Z", "contentLength": 278835, "httpStatusCode": 200}	c1bddaf4-dc9b-47e8-9a29-6604177050ad	\N	{}	2
8dfd7767-99fc-4cab-80bb-06763dcd0c9f	documents	contracts/1767044149440_2m23xj4.pdf	\N	2025-12-29 21:35:50.557015+00	2025-12-29 21:35:50.557015+00	2025-12-29 21:35:50.557015+00	{"eTag": "\\"8643fd7dff68c3d4a573eb49594e8209\\"", "size": 1247, "mimetype": "application/pdf", "cacheControl": "max-age=3600", "lastModified": "2025-12-29T21:35:51.000Z", "contentLength": 1247, "httpStatusCode": 200}	6f4d5a35-450d-4fba-9bbf-300e8b46baad	\N	{}	2
d008b1c6-8c1e-4f2d-94ee-ef0cb78e7c20	documents	contracts/1767124488946_vl6sfcq.pdf	\N	2025-12-30 19:54:50.032802+00	2025-12-30 19:54:50.032802+00	2025-12-30 19:54:50.032802+00	{"eTag": "\\"3b3553adfd5c8e0ee49251b324f89074\\"", "size": 114570, "mimetype": "application/pdf", "cacheControl": "max-age=3600", "lastModified": "2025-12-30T19:54:50.000Z", "contentLength": 114570, "httpStatusCode": 200}	ae09ce24-6f77-4110-b25b-076b49b24229	\N	{}	2
85766fc4-de5a-49f7-8e5d-4bae2bee28ed	documents	contracts/1767124629644_pmbv3j8.png	\N	2025-12-30 19:57:10.592994+00	2025-12-30 19:57:10.592994+00	2025-12-30 19:57:10.592994+00	{"eTag": "\\"cda4b87105e3e8a7f64c1c5aa39cc625\\"", "size": 95602, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2025-12-30T19:57:11.000Z", "contentLength": 95602, "httpStatusCode": 200}	ee7a6572-f783-449f-9528-f185b684b26c	\N	{}	2
3c164d9a-9bd7-4383-95ee-d57fd9b01d96	documents	contracts/1767125153121_qbiso93.png	\N	2025-12-30 20:05:54.171772+00	2025-12-30 20:05:54.171772+00	2025-12-30 20:05:54.171772+00	{"eTag": "\\"5f39ffac6f153180e3145ef5b70af0c8\\"", "size": 140615, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2025-12-30T20:05:55.000Z", "contentLength": 140615, "httpStatusCode": 200}	2402d0cf-1704-4412-a8ec-313cab9576d2	\N	{}	2
b6f71226-a7e5-470b-b2b4-48176b831783	member-files	member_image/1767175603436_5t1q3mjhw.png	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-31 10:06:44.425799+00	2025-12-31 10:06:44.425799+00	2025-12-31 10:06:44.425799+00	{"eTag": "\\"bfbe1565dd2cb4c9d736e538a11be690\\"", "size": 38901, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2025-12-31T10:06:45.000Z", "contentLength": 38901, "httpStatusCode": 200}	e6ffbf86-ea96-4290-b63f-8ae1d3bc5072	07f10513-f029-4ae5-9333-7350bfc9ed86	{}	2
1db7562d-c1eb-4858-a82d-e84a8b7d5330	member-files	national_card_image/1767175607094_ub1u345e1.jpg	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-31 10:06:47.874432+00	2025-12-31 10:06:47.874432+00	2025-12-31 10:06:47.874432+00	{"eTag": "\\"7239211c1078bbff5ace4474fa5b26ba\\"", "size": 12917, "mimetype": "image/jpeg", "cacheControl": "max-age=3600", "lastModified": "2025-12-31T10:06:48.000Z", "contentLength": 12917, "httpStatusCode": 200}	d8057d6d-0720-475e-a37c-1b3c6b04a42f	07f10513-f029-4ae5-9333-7350bfc9ed86	{}	2
6329784f-e88e-4dd6-9096-4ab2c6fdc6b6	member-files	member_image/1767175955409_64lausteh.png	07f10513-f029-4ae5-9333-7350bfc9ed86	2025-12-31 10:12:36.700793+00	2025-12-31 10:12:36.700793+00	2025-12-31 10:12:36.700793+00	{"eTag": "\\"cda4b87105e3e8a7f64c1c5aa39cc625\\"", "size": 95602, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2025-12-31T10:12:37.000Z", "contentLength": 95602, "httpStatusCode": 200}	b94d9353-470a-48ba-86e0-708b4844d465	07f10513-f029-4ae5-9333-7350bfc9ed86	{}	2
\.


--
-- Data for Name: prefixes; Type: TABLE DATA; Schema: storage; Owner: postgres
--

COPY storage.prefixes (bucket_id, name, created_at, updated_at) FROM stdin;
media	treasury-documents	2025-12-20 13:19:02.301281+00	2025-12-20 13:19:02.301281+00
documents	contracts	2025-12-29 21:35:50.557015+00	2025-12-29 21:35:50.557015+00
member-files	member_image	2025-12-31 10:06:44.425799+00	2025-12-31 10:06:44.425799+00
member-files	national_card_image	2025-12-31 10:06:47.874432+00	2025-12-31 10:06:47.874432+00
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: postgres
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: postgres
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: postgres
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: postgres
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 133, true);


--
-- Name: access_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.access_audit_logs_id_seq', 1, false);


--
-- Name: accounting_gl_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounting_gl_id_seq', 15, true);


--
-- Name: accounting_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounting_groups_id_seq', 8, true);


--
-- Name: accounting_moein_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounting_moein_id_seq', 20, true);


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: union_api
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 22, true);


--
-- Name: base_banks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.base_banks_id_seq', 22, true);


--
-- Name: doc_no_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.doc_no_seq', 53, true);


--
-- Name: financial_documents_doc_no_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.financial_documents_doc_no_seq', 31, true);


--
-- Name: receipt_no_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.receipt_no_seq', 1010, true);


--
-- Name: sms_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: union_api
--

SELECT pg_catalog.setval('public.sms_logs_id_seq', 1, true);


--
-- Name: tickets_ticket_no_seq; Type: SEQUENCE SET; Schema: public; Owner: union_api
--

SELECT pg_catalog.setval('public.tickets_ticket_no_seq', 2, true);


--
-- Name: warehouse_exits_exit_no_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.warehouse_exits_exit_no_seq', 57, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: postgres
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: access_audit_logs access_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_audit_logs
    ADD CONSTRAINT access_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: accounting_gl accounting_gl_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_gl
    ADD CONSTRAINT accounting_gl_code_key UNIQUE (code);


--
-- Name: accounting_gl accounting_gl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_gl
    ADD CONSTRAINT accounting_gl_pkey PRIMARY KEY (id);


--
-- Name: accounting_groups accounting_groups_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_groups
    ADD CONSTRAINT accounting_groups_code_key UNIQUE (code);


--
-- Name: accounting_groups accounting_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_groups
    ADD CONSTRAINT accounting_groups_pkey PRIMARY KEY (id);


--
-- Name: accounting_moein accounting_moein_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_moein
    ADD CONSTRAINT accounting_moein_code_key UNIQUE (code);


--
-- Name: accounting_moein accounting_moein_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_moein
    ADD CONSTRAINT accounting_moein_pkey PRIMARY KEY (id);


--
-- Name: accounting_tafsili accounting_tafsili_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_tafsili
    ADD CONSTRAINT accounting_tafsili_pkey PRIMARY KEY (id);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: base_banks base_banks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.base_banks
    ADD CONSTRAINT base_banks_pkey PRIMARY KEY (id);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: clearance_items clearance_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clearance_items
    ADD CONSTRAINT clearance_items_pkey PRIMARY KEY (id);


--
-- Name: clearances clearances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clearances
    ADD CONSTRAINT clearances_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: document_types document_types_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_code_key UNIQUE (code);


--
-- Name: document_types document_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_pkey PRIMARY KEY (id);


--
-- Name: financial_documents financial_documents_doc_no_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_documents
    ADD CONSTRAINT financial_documents_doc_no_key UNIQUE (doc_no);


--
-- Name: financial_documents financial_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_documents
    ADD CONSTRAINT financial_documents_pkey PRIMARY KEY (id);


--
-- Name: financial_entries financial_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.financial_entries
    ADD CONSTRAINT financial_entries_pkey PRIMARY KEY (id);


--
-- Name: inventory_transactions inventory_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_pkey PRIMARY KEY (id);


--
-- Name: loading_order_items loading_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loading_order_items
    ADD CONSTRAINT loading_order_items_pkey PRIMARY KEY (id);


--
-- Name: loading_orders loading_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.loading_orders
    ADD CONSTRAINT loading_orders_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: members members_member_code_key; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_member_code_key UNIQUE (member_code);


--
-- Name: members members_mobile_key; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_mobile_key UNIQUE (mobile);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: opening_balance_banks opening_balance_banks_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.opening_balance_banks
    ADD CONSTRAINT opening_balance_banks_pkey PRIMARY KEY (id);


--
-- Name: opening_balance_cashes opening_balance_cashes_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.opening_balance_cashes
    ADD CONSTRAINT opening_balance_cashes_pkey PRIMARY KEY (id);


--
-- Name: opening_balance_customers opening_balance_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.opening_balance_customers
    ADD CONSTRAINT opening_balance_customers_pkey PRIMARY KEY (id);


--
-- Name: opening_balance_items opening_balance_items_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.opening_balance_items
    ADD CONSTRAINT opening_balance_items_pkey PRIMARY KEY (id);


--
-- Name: opening_balances opening_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.opening_balances
    ADD CONSTRAINT opening_balances_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_code_key UNIQUE (code);


--
-- Name: permissions permissions_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_code_unique UNIQUE (code);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_slug_key UNIQUE (slug);


--
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (id);


--
-- Name: product_units product_units_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_units
    ADD CONSTRAINT product_units_code_key UNIQUE (code);


--
-- Name: product_units product_units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_units
    ADD CONSTRAINT product_units_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_sku_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sku_key UNIQUE (sku);


--
-- Name: receipt_items receipt_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipt_items
    ADD CONSTRAINT receipt_items_pkey PRIMARY KEY (id);


--
-- Name: receipts receipts_member_receipt_no_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_member_receipt_no_unique UNIQUE (member_id, receipt_no);


--
-- Name: receipts receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receipts
    ADD CONSTRAINT receipts_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_code_unique UNIQUE (code);


--
-- Name: roles roles_member_id_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_member_id_code_key UNIQUE (member_id, code);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sms_logs sms_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.sms_logs
    ADD CONSTRAINT sms_logs_pkey PRIMARY KEY (id);


--
-- Name: ticket_categories ticket_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.ticket_categories
    ADD CONSTRAINT ticket_categories_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: treasury_banks treasury_banks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_banks
    ADD CONSTRAINT treasury_banks_pkey PRIMARY KEY (id);


--
-- Name: treasury_cashes treasury_cashes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_cashes
    ADD CONSTRAINT treasury_cashes_pkey PRIMARY KEY (id);


--
-- Name: treasury_check_details treasury_check_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_check_details
    ADD CONSTRAINT treasury_check_details_pkey PRIMARY KEY (id);


--
-- Name: treasury_checkbooks treasury_checkbooks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_checkbooks
    ADD CONSTRAINT treasury_checkbooks_pkey PRIMARY KEY (id);


--
-- Name: treasury_checks treasury_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_checks
    ADD CONSTRAINT treasury_checks_pkey PRIMARY KEY (id);


--
-- Name: treasury_pos treasury_pos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_pos
    ADD CONSTRAINT treasury_pos_pkey PRIMARY KEY (id);


--
-- Name: ui_form_permissions ui_form_permissions_form_id_permission_id_required_for_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ui_form_permissions
    ADD CONSTRAINT ui_form_permissions_form_id_permission_id_required_for_key UNIQUE (form_id, permission_id, required_for);


--
-- Name: ui_form_permissions ui_form_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ui_form_permissions
    ADD CONSTRAINT ui_form_permissions_pkey PRIMARY KEY (id);


--
-- Name: ui_forms ui_forms_member_id_form_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ui_forms
    ADD CONSTRAINT ui_forms_member_id_form_code_key UNIQUE (member_id, form_code);


--
-- Name: ui_forms ui_forms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ui_forms
    ADD CONSTRAINT ui_forms_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_member_id_user_id_role_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_member_id_user_id_role_id_key UNIQUE (member_id, user_id, role_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: warehouse_exit_items warehouse_exit_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_exit_items
    ADD CONSTRAINT warehouse_exit_items_pkey PRIMARY KEY (id);


--
-- Name: warehouse_exits warehouse_exits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_exits
    ADD CONSTRAINT warehouse_exits_pkey PRIMARY KEY (id);


--
-- Name: warehouse_rentals warehouse_rentals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouse_rentals
    ADD CONSTRAINT warehouse_rentals_pkey PRIMARY KEY (id);


--
-- Name: warehouse_settings warehouse_settings_member_id_key; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.warehouse_settings
    ADD CONSTRAINT warehouse_settings_member_id_key UNIQUE (member_id);


--
-- Name: warehouse_settings warehouse_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.warehouse_settings
    ADD CONSTRAINT warehouse_settings_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: postgres
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: postgres
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: postgres
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: prefixes prefixes_pkey; Type: CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT prefixes_pkey PRIMARY KEY (bucket_id, level, name);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: postgres
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: postgres
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: clearances_no_member_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX clearances_no_member_unique ON public.clearances USING btree (clearance_no, member_id);


--
-- Name: idx_accounting_tafsili_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_accounting_tafsili_member_id ON public.accounting_tafsili USING btree (member_id);


--
-- Name: idx_activity_logs_action; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX idx_activity_logs_action ON public.activity_logs USING btree (action);


--
-- Name: idx_activity_logs_created; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX idx_activity_logs_created ON public.activity_logs USING btree (created_at DESC);


--
-- Name: idx_activity_logs_member; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX idx_activity_logs_member ON public.activity_logs USING btree (member_id);


--
-- Name: idx_calendar_events_date; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX idx_calendar_events_date ON public.calendar_events USING btree (event_date);


--
-- Name: idx_calendar_events_member; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX idx_calendar_events_member ON public.calendar_events USING btree (member_id);


--
-- Name: idx_calendar_events_type; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX idx_calendar_events_type ON public.calendar_events USING btree (event_type);


--
-- Name: idx_check_details_checkbook; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_check_details_checkbook ON public.treasury_check_details USING btree (checkbook_id);


--
-- Name: idx_clearance_items_clearance; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clearance_items_clearance ON public.clearance_items USING btree (clearance_id);


--
-- Name: idx_clearances_customer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clearances_customer ON public.clearances USING btree (customer_id);


--
-- Name: idx_clearances_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clearances_date ON public.clearances USING btree (clearance_date);


--
-- Name: idx_clearances_member; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clearances_member ON public.clearances USING btree (member_id);


--
-- Name: idx_clearances_no; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clearances_no ON public.clearances USING btree (clearance_no);


--
-- Name: idx_clearances_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clearances_status ON public.clearances USING btree (status);


--
-- Name: idx_customers_mobile; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_mobile ON public.customers USING btree (mobile);


--
-- Name: idx_customers_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_name ON public.customers USING btree (name);


--
-- Name: idx_customers_national_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_national_id ON public.customers USING btree (national_id);


--
-- Name: idx_customers_otp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_otp ON public.customers USING btree (mobile, otp_code) WHERE (otp_code IS NOT NULL);


--
-- Name: idx_customers_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_customers_type ON public.customers USING btree (customer_type);


--
-- Name: idx_fin_doc_ref; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fin_doc_ref ON public.financial_documents USING btree (reference_id, reference_type);


--
-- Name: idx_financial_documents_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_financial_documents_member_id ON public.financial_documents USING btree (member_id);


--
-- Name: idx_financial_entries_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_financial_entries_member_id ON public.financial_entries USING btree (member_id);


--
-- Name: idx_media_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_media_member_id ON public.media USING btree (member_id);


--
-- Name: idx_media_related; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_media_related ON public.media USING btree (related_table, related_id);


--
-- Name: idx_product_categories_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_categories_active ON public.product_categories USING btree (is_active);


--
-- Name: idx_product_categories_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_categories_parent ON public.product_categories USING btree (parent_id);


--
-- Name: idx_product_categories_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_categories_slug ON public.product_categories USING btree (slug);


--
-- Name: idx_product_categories_sort; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_categories_sort ON public.product_categories USING btree (sort_order);


--
-- Name: idx_product_units_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_units_name ON public.product_units USING btree (name);


--
-- Name: idx_product_units_symbol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_units_symbol ON public.product_units USING btree (symbol);


--
-- Name: idx_products_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_active ON public.products USING btree (is_active);


--
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_category ON public.products USING btree (category_id);


--
-- Name: idx_products_member; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_member ON public.products USING btree (member_id);


--
-- Name: idx_products_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_member_id ON public.products USING btree (member_id);


--
-- Name: idx_products_sku; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_sku ON public.products USING btree (sku);


--
-- Name: idx_products_unit; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_unit ON public.products USING btree (unit_id);


--
-- Name: idx_receipt_items_owner; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipt_items_owner ON public.receipt_items USING btree (owner_id);


--
-- Name: idx_receipt_items_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipt_items_parent ON public.receipt_items USING btree (parent_id);


--
-- Name: idx_receipt_items_product; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipt_items_product ON public.receipt_items USING btree (product_id);


--
-- Name: idx_receipt_items_receipt; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipt_items_receipt ON public.receipt_items USING btree (receipt_id);


--
-- Name: idx_receipt_items_row; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipt_items_row ON public.receipt_items USING btree (row_code);


--
-- Name: idx_receipts_doc_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipts_doc_date ON public.receipts USING btree (doc_date);


--
-- Name: idx_receipts_doc_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipts_doc_type ON public.receipts USING btree (doc_type_id);


--
-- Name: idx_receipts_member; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipts_member ON public.receipts USING btree (member_id);


--
-- Name: idx_receipts_owner; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipts_owner ON public.receipts USING btree (owner_id);


--
-- Name: idx_receipts_receipt_no; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipts_receipt_no ON public.receipts USING btree (receipt_no);


--
-- Name: idx_receipts_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipts_status ON public.receipts USING btree (status);


--
-- Name: idx_receipts_tracking_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_receipts_tracking_code ON public.receipts USING btree (tracking_code);


--
-- Name: idx_role_permissions_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_role_permissions_role ON public.role_permissions USING btree (role_id);


--
-- Name: idx_ticket_messages_ticket; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX idx_ticket_messages_ticket ON public.ticket_messages USING btree (ticket_id);


--
-- Name: idx_tickets_created_by; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX idx_tickets_created_by ON public.tickets USING btree (created_by);


--
-- Name: idx_tickets_member; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX idx_tickets_member ON public.tickets USING btree (member_id);


--
-- Name: idx_tickets_status; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX idx_tickets_status ON public.tickets USING btree (status);


--
-- Name: idx_treasury_banks_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_treasury_banks_member_id ON public.treasury_banks USING btree (member_id);


--
-- Name: idx_treasury_cashes_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_treasury_cashes_member_id ON public.treasury_cashes USING btree (member_id);


--
-- Name: idx_treasury_checkbooks_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_treasury_checkbooks_member_id ON public.treasury_checkbooks USING btree (member_id);


--
-- Name: idx_treasury_checks_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_treasury_checks_member_id ON public.treasury_checks USING btree (member_id);


--
-- Name: idx_treasury_pos_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_treasury_pos_member_id ON public.treasury_pos USING btree (member_id);


--
-- Name: idx_ui_form_permissions_form; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ui_form_permissions_form ON public.ui_form_permissions USING btree (form_id);


--
-- Name: idx_ui_forms_member_active_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ui_forms_member_active_order ON public.ui_forms USING btree (member_id, is_active, menu_order);


--
-- Name: idx_unique_mobile_per_member; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_unique_mobile_per_member ON public.customers USING btree (mobile, member_id);


--
-- Name: idx_unique_national_id_per_member; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_unique_national_id_per_member ON public.customers USING btree (national_id, member_id) WHERE ((national_id IS NOT NULL) AND (national_id <> ''::text));


--
-- Name: idx_user_roles_member_user_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_roles_member_user_active ON public.user_roles USING btree (member_id, user_id, is_active);


--
-- Name: members_member_code_idx; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX members_member_code_idx ON public.members USING btree (member_code);


--
-- Name: members_mobile_idx; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX members_mobile_idx ON public.members USING btree (mobile);


--
-- Name: members_role_idx; Type: INDEX; Schema: public; Owner: union_api
--

CREATE INDEX members_role_idx ON public.members USING btree (role);


--
-- Name: opening_balances_member_section_unique; Type: INDEX; Schema: public; Owner: union_api
--

CREATE UNIQUE INDEX opening_balances_member_section_unique ON public.opening_balances USING btree (member_id, section);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: postgres
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: postgres
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: postgres
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: postgres
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: postgres
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: postgres
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: postgres
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_name_bucket_level_unique; Type: INDEX; Schema: storage; Owner: postgres
--

CREATE UNIQUE INDEX idx_name_bucket_level_unique ON storage.objects USING btree (name COLLATE "C", bucket_id, level);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: postgres
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_lower_name; Type: INDEX; Schema: storage; Owner: postgres
--

CREATE INDEX idx_objects_lower_name ON storage.objects USING btree ((path_tokens[level]), lower(name) text_pattern_ops, bucket_id, level);


--
-- Name: idx_prefixes_lower_name; Type: INDEX; Schema: storage; Owner: postgres
--

CREATE INDEX idx_prefixes_lower_name ON storage.prefixes USING btree (bucket_id, level, ((string_to_array(name, '/'::text))[level]), lower(name) text_pattern_ops);


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: postgres
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: objects_bucket_id_level_idx; Type: INDEX; Schema: storage; Owner: postgres
--

CREATE UNIQUE INDEX objects_bucket_id_level_idx ON storage.objects USING btree (bucket_id, level, name COLLATE "C");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: postgres
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: view_receipt_summary _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.view_receipt_summary AS
 SELECT r.id,
    r.receipt_no,
    r.doc_date,
    r.status,
    r.driver_name,
    ((((((r.plate_left2 || ' '::text) || r.plate_letter) || ' '::text) || r.plate_mid3) || ' ایران '::text) || r.plate_iran_right) AS full_plate,
    r.payment_amount,
    count(ri.id) AS total_items,
    sum(ri.count) AS total_quantity,
    sum(ri.weights_net) AS total_net_weight,
    r.created_at
   FROM (public.receipts r
     LEFT JOIN public.receipt_items ri ON ((r.id = ri.receipt_id)))
  GROUP BY r.id;


--
-- Name: users on_auth_user_created; Type: TRIGGER; Schema: auth; Owner: postgres
--

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.link_user_to_customer();


--
-- Name: clearances trg_auto_sync_clearance; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_auto_sync_clearance AFTER INSERT OR UPDATE ON public.clearances FOR EACH ROW EXECUTE FUNCTION public.fn_trigger_sync_clearance();


--
-- Name: members trg_members_updated_at; Type: TRIGGER; Schema: public; Owner: union_api
--

CREATE TRIGGER trg_members_updated_at BEFORE UPDATE ON public.members FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: roles trg_roles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_roles_updated_at BEFORE UPDATE ON public.roles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: accounting_tafsili trg_sync_tafsili; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_sync_tafsili AFTER INSERT ON public.accounting_tafsili FOR EACH ROW EXECUTE FUNCTION public.sync_tafsili_to_entities();


--
-- Name: ui_forms trg_ui_forms_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_ui_forms_updated_at BEFORE UPDATE ON public.ui_forms FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: warehouse_exit_items trigger_update_inventory_exit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_update_inventory_exit AFTER INSERT ON public.warehouse_exit_items FOR EACH ROW EXECUTE FUNCTION public.update_inventory_on_exit();


--
-- Name: accounting_tafsili update_accounting_tafsili_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_accounting_tafsili_timestamp BEFORE UPDATE ON public.accounting_tafsili FOR EACH ROW EXECUTE FUNCTION public.moddatetime('updated_at');


--
-- Name: clearances update_clearances_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_clearances_timestamp BEFORE UPDATE ON public.clearances FOR EACH ROW EXECUTE FUNCTION public.moddatetime('updated_at');


--
-- Name: customers update_customers_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_customers_timestamp BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.moddatetime('updated_at');


--
-- Name: document_types update_document_types_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_document_types_timestamp BEFORE UPDATE ON public.document_types FOR EACH ROW EXECUTE FUNCTION public.moddatetime('updated_at');


--
-- Name: media update_media_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_media_timestamp BEFORE UPDATE ON public.media FOR EACH ROW EXECUTE FUNCTION public.moddatetime('updated_at');


--
-- Name: product_categories update_product_categories_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_product_categories_timestamp BEFORE UPDATE ON public.product_categories FOR EACH ROW EXECUTE FUNCTION public.moddatetime('updated_at');


--
-- Name: product_units update_product_units_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_product_units_timestamp BEFORE UPDATE ON public.product_units FOR EACH ROW EXECUTE FUNCTION public.moddatetime('updated_at');


--
-- Name: products update_products_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_products_timestamp BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.moddatetime('updated_at');


--
-- Name: receipt_items update_receipt_items_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_receipt_items_timestamp BEFORE UPDATE ON public.receipt_items FOR EACH ROW EXECUTE FUNCTION public.moddatetime('updated_at');


--
-- Name: receipts update_receipts_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_receipts_timestamp BEFORE UPDATE ON public.receipts FOR EACH ROW EXECUTE FUNCTION public.moddatetime('updated_at');


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: postgres
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: postgres
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: objects objects_delete_delete_prefix; Type: TRIGGER; Schema: storage; Owner: postgres
--

CREATE TRIGGER objects_delete_delete_prefix AFTER DELETE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- Name: objects objects_insert_create_prefix; Type: TRIGGER; Schema: storage; Owner: postgres
--

CREATE TRIGGER objects_insert_create_prefix BEFORE INSERT ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.objects_insert_prefix_trigger();


--
-- Name: objects objects_update_create_prefix; Type: TRIGGER; Schema: storage; Owner: postgres
--

CREATE TRIGGER objects_update_create_prefix BEFORE UPDATE ON storage.objects FOR EACH ROW WHEN (((new.name <> old.name) OR (new.bucket_id <> old.bucket_id))) EXECUTE FUNCTION storage.objects_update_prefix_trigger();


--
-- Name: prefixes prefixes_create_hierarchy; Type: TRIGGER; Schema: storage; Owner: postgres
--

CREATE TRIGGER prefixes_create_hierarchy BEFORE INSERT ON storage.prefixes FOR EACH ROW WHEN ((pg_trigger_depth() < 1)) EXECUTE FUNCTION storage.prefixes_insert_trigger();


--
-- Name: prefixes prefixes_delete_hierarchy; Type: TRIGGER; Schema: storage; Owner: postgres
--

CREATE TRIGGER prefixes_delete_hierarchy AFTER DELETE ON storage.prefixes FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: postgres
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: postgres
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: access_audit_logs access_audit_logs_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access_audit_logs
    ADD CONSTRAINT access_audit_logs_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: customers customers_auth_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_auth_user_id_fkey FOREIGN KEY (auth_user_id) REFERENCES auth.users(id);


--
-- Name: treasury_banks fk_banks_member; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treasury_banks
    ADD CONSTRAINT fk_banks_member FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: customers fk_customers_member; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT fk_customers_member FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: members fk_members_owner; Type: FK CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT fk_members_owner FOREIGN KEY (owner_id) REFERENCES public.members(id);


--
-- Name: accounting_tafsili fk_tafsili_member; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounting_tafsili
    ADD CONSTRAINT fk_tafsili_member FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: inventory_transactions inventory_transactions_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: inventory_transactions inventory_transactions_ref_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_ref_receipt_id_fkey FOREIGN KEY (ref_receipt_id) REFERENCES public.receipts(id) ON DELETE CASCADE;


--
-- Name: members members_auth_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_auth_user_id_fkey FOREIGN KEY (auth_user_id) REFERENCES auth.users(id);


--
-- Name: opening_balance_banks opening_balance_banks_opening_balance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.opening_balance_banks
    ADD CONSTRAINT opening_balance_banks_opening_balance_id_fkey FOREIGN KEY (opening_balance_id) REFERENCES public.opening_balances(id) ON DELETE CASCADE;


--
-- Name: opening_balance_cashes opening_balance_cashes_opening_balance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.opening_balance_cashes
    ADD CONSTRAINT opening_balance_cashes_opening_balance_id_fkey FOREIGN KEY (opening_balance_id) REFERENCES public.opening_balances(id) ON DELETE CASCADE;


--
-- Name: opening_balance_customers opening_balance_customers_opening_balance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.opening_balance_customers
    ADD CONSTRAINT opening_balance_customers_opening_balance_id_fkey FOREIGN KEY (opening_balance_id) REFERENCES public.opening_balances(id) ON DELETE CASCADE;


--
-- Name: opening_balance_items opening_balance_items_opening_balance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.opening_balance_items
    ADD CONSTRAINT opening_balance_items_opening_balance_id_fkey FOREIGN KEY (opening_balance_id) REFERENCES public.opening_balances(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: roles roles_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: ticket_messages ticket_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: tickets tickets_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: union_api
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.ticket_categories(id);


--
-- Name: ui_form_permissions ui_form_permissions_form_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ui_form_permissions
    ADD CONSTRAINT ui_form_permissions_form_id_fkey FOREIGN KEY (form_id) REFERENCES public.ui_forms(id) ON DELETE CASCADE;


--
-- Name: ui_form_permissions ui_form_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ui_form_permissions
    ADD CONSTRAINT ui_form_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: ui_forms ui_forms_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ui_forms
    ADD CONSTRAINT ui_forms_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: ui_forms ui_forms_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ui_forms
    ADD CONSTRAINT ui_forms_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.ui_forms(id) ON DELETE SET NULL;


--
-- Name: user_roles user_roles_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: prefixes prefixes_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT "prefixes_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: postgres
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: postgres
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: financial_documents Allow all access to documents; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow all access to documents" ON public.financial_documents USING (true);


--
-- Name: financial_entries Allow all access to entries; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow all access to entries" ON public.financial_entries USING (true);


--
-- Name: accounting_gl Anyone can view GL; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Anyone can view GL" ON public.accounting_gl FOR SELECT USING (true);


--
-- Name: accounting_groups Anyone can view accounting groups; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Anyone can view accounting groups" ON public.accounting_groups FOR SELECT USING (true);


--
-- Name: base_banks Anyone can view banks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Anyone can view banks" ON public.base_banks FOR SELECT USING (true);


--
-- Name: product_categories Anyone can view categories; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Anyone can view categories" ON public.product_categories FOR SELECT USING (true);


--
-- Name: document_types Anyone can view doc types; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Anyone can view doc types" ON public.document_types FOR SELECT USING (true);


--
-- Name: accounting_moein Anyone can view moein; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Anyone can view moein" ON public.accounting_moein FOR SELECT USING (true);


--
-- Name: product_units Anyone can view units; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Anyone can view units" ON public.product_units FOR SELECT USING (true);


--
-- Name: financial_documents Enable all for documents; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Enable all for documents" ON public.financial_documents USING (true);


--
-- Name: financial_entries Enable all for entries; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Enable all for entries" ON public.financial_entries USING (true);


--
-- Name: members Read Own Profile; Type: POLICY; Schema: public; Owner: union_api
--

CREATE POLICY "Read Own Profile" ON public.members FOR SELECT USING ((auth_user_id = auth.uid()));


--
-- Name: members Super Admin Access; Type: POLICY; Schema: public; Owner: union_api
--

CREATE POLICY "Super Admin Access" ON public.members USING ((public.is_admin() = true));


--
-- Name: accounting_tafsili Users can insert their own tafsili; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can insert their own tafsili" ON public.accounting_tafsili FOR INSERT TO authenticated WITH CHECK ((auth.uid() = member_id));


--
-- Name: accounting_tafsili Users can view their own tafsili; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view their own tafsili" ON public.accounting_tafsili FOR SELECT TO authenticated USING ((auth.uid() = member_id));


--
-- Name: accounting_gl; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.accounting_gl ENABLE ROW LEVEL SECURITY;

--
-- Name: accounting_groups; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.accounting_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: accounting_moein; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.accounting_moein ENABLE ROW LEVEL SECURITY;

--
-- Name: product_categories admin_write_categories; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_write_categories ON public.product_categories USING ((auth.role() = 'admin'::text));


--
-- Name: product_units admin_write_units; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_write_units ON public.product_units USING ((auth.role() = 'admin'::text));


--
-- Name: members allow_insert_members; Type: POLICY; Schema: public; Owner: union_api
--

CREATE POLICY allow_insert_members ON public.members FOR INSERT WITH CHECK (true);


--
-- Name: receipts backend_full_access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY backend_full_access ON public.receipts USING ((auth.role() = 'service_role'::text));


--
-- Name: customers backend_write_customers; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY backend_write_customers ON public.customers USING ((auth.role() = 'service_role'::text));


--
-- Name: products backend_write_products; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY backend_write_products ON public.products USING ((auth.role() = 'service_role'::text));


--
-- Name: base_banks; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.base_banks ENABLE ROW LEVEL SECURITY;

--
-- Name: clearance_items; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.clearance_items ENABLE ROW LEVEL SECURITY;

--
-- Name: clearances; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.clearances ENABLE ROW LEVEL SECURITY;

--
-- Name: document_types; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.document_types ENABLE ROW LEVEL SECURITY;

--
-- Name: financial_entries; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.financial_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: product_categories; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.product_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: product_units; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.product_units ENABLE ROW LEVEL SECURITY;

--
-- Name: product_categories public_read_categories; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY public_read_categories ON public.product_categories FOR SELECT USING (true);


--
-- Name: customers public_read_customers; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY public_read_customers ON public.customers FOR SELECT USING (true);


--
-- Name: products public_read_products; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY public_read_products ON public.products FOR SELECT USING (true);


--
-- Name: product_units public_read_units; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY public_read_units ON public.product_units FOR SELECT USING (true);


--
-- Name: warehouse_rentals; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.warehouse_rentals ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: postgres
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: objects Allow deletes for documents; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "Allow deletes for documents" ON storage.objects FOR DELETE USING ((bucket_id = 'documents'::text));


--
-- Name: objects Allow downloads for documents; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "Allow downloads for documents" ON storage.objects FOR SELECT USING ((bucket_id = 'documents'::text));


--
-- Name: objects Allow public read from media; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "Allow public read from media" ON storage.objects FOR SELECT USING ((bucket_id = 'media'::text));


--
-- Name: objects Allow updates for documents; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "Allow updates for documents" ON storage.objects FOR UPDATE USING ((bucket_id = 'documents'::text));


--
-- Name: objects Allow uploads for documents; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "Allow uploads for documents" ON storage.objects FOR INSERT WITH CHECK ((bucket_id = 'documents'::text));


--
-- Name: objects Allow uploads to media; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "Allow uploads to media" ON storage.objects FOR INSERT WITH CHECK ((bucket_id = 'media'::text));


--
-- Name: objects Public Access ojkhl9_0; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "Public Access ojkhl9_0" ON storage.objects FOR SELECT USING ((bucket_id = 'clearance_attachments'::text));


--
-- Name: objects Public Access ojkhl9_1; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "Public Access ojkhl9_1" ON storage.objects FOR UPDATE USING ((bucket_id = 'clearance_attachments'::text));


--
-- Name: objects Public Access ojkhl9_2; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "Public Access ojkhl9_2" ON storage.objects FOR INSERT WITH CHECK ((bucket_id = 'clearance_attachments'::text));


--
-- Name: objects Public Access ojkhl9_3; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "Public Access ojkhl9_3" ON storage.objects FOR DELETE USING ((bucket_id = 'clearance_attachments'::text));


--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: postgres
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: postgres
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: postgres
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: objects member-files 1af28as_0; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "member-files 1af28as_0" ON storage.objects FOR SELECT USING ((bucket_id = 'member-files'::text));


--
-- Name: objects member-files 1af28as_1; Type: POLICY; Schema: storage; Owner: postgres
--

CREATE POLICY "member-files 1af28as_1" ON storage.objects FOR INSERT WITH CHECK ((bucket_id = 'member-files'::text));


--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: postgres
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: postgres
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: prefixes; Type: ROW SECURITY; Schema: storage; Owner: postgres
--

ALTER TABLE storage.prefixes ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: postgres
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: postgres
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: postgres
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION supabase_realtime OWNER TO postgres;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO unionapp;
GRANT USAGE ON SCHEMA public TO union_api;
GRANT USAGE ON SCHEMA public TO authenticated;


--
-- Name: TABLE products; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.products TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.products TO union_api;
GRANT ALL ON TABLE public.products TO authenticated;


--
-- Name: TABLE clearance_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.clearance_items TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.clearance_items TO union_api;
GRANT ALL ON TABLE public.clearance_items TO authenticated;


--
-- Name: TABLE access_audit_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.access_audit_logs TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.access_audit_logs TO union_api;


--
-- Name: SEQUENCE access_audit_logs_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.access_audit_logs_id_seq TO unionapp;


--
-- Name: TABLE accounting_gl; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.accounting_gl TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.accounting_gl TO union_api;
GRANT ALL ON TABLE public.accounting_gl TO authenticated;


--
-- Name: SEQUENCE accounting_gl_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.accounting_gl_id_seq TO unionapp;
GRANT ALL ON SEQUENCE public.accounting_gl_id_seq TO authenticated;


--
-- Name: TABLE accounting_groups; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.accounting_groups TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.accounting_groups TO union_api;
GRANT ALL ON TABLE public.accounting_groups TO authenticated;


--
-- Name: SEQUENCE accounting_groups_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.accounting_groups_id_seq TO unionapp;
GRANT ALL ON SEQUENCE public.accounting_groups_id_seq TO authenticated;


--
-- Name: TABLE accounting_moein; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.accounting_moein TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.accounting_moein TO union_api;
GRANT ALL ON TABLE public.accounting_moein TO authenticated;


--
-- Name: SEQUENCE accounting_moein_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.accounting_moein_id_seq TO unionapp;
GRANT ALL ON SEQUENCE public.accounting_moein_id_seq TO authenticated;


--
-- Name: TABLE accounting_tafsili; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.accounting_tafsili TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.accounting_tafsili TO union_api;
GRANT ALL ON TABLE public.accounting_tafsili TO authenticated;


--
-- Name: TABLE base_banks; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.base_banks TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.base_banks TO union_api;
GRANT ALL ON TABLE public.base_banks TO authenticated;


--
-- Name: SEQUENCE base_banks_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.base_banks_id_seq TO unionapp;
GRANT ALL ON SEQUENCE public.base_banks_id_seq TO authenticated;


--
-- Name: TABLE clearances; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.clearances TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.clearances TO union_api;
GRANT ALL ON TABLE public.clearances TO authenticated;


--
-- Name: TABLE customers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customers TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.customers TO union_api;
GRANT ALL ON TABLE public.customers TO authenticated;


--
-- Name: SEQUENCE doc_no_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.doc_no_seq TO unionapp;
GRANT ALL ON SEQUENCE public.doc_no_seq TO authenticated;


--
-- Name: TABLE document_types; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.document_types TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.document_types TO union_api;
GRANT ALL ON TABLE public.document_types TO authenticated;


--
-- Name: TABLE financial_documents; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.financial_documents TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.financial_documents TO union_api;
GRANT ALL ON TABLE public.financial_documents TO authenticated;


--
-- Name: SEQUENCE financial_documents_doc_no_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.financial_documents_doc_no_seq TO unionapp;
GRANT ALL ON SEQUENCE public.financial_documents_doc_no_seq TO authenticated;


--
-- Name: TABLE financial_entries; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.financial_entries TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.financial_entries TO union_api;
GRANT ALL ON TABLE public.financial_entries TO authenticated;


--
-- Name: TABLE inventory_transactions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.inventory_transactions TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.inventory_transactions TO union_api;


--
-- Name: TABLE inventory_stock; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.inventory_stock TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.inventory_stock TO union_api;


--
-- Name: TABLE loading_order_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.loading_order_items TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.loading_order_items TO union_api;
GRANT ALL ON TABLE public.loading_order_items TO authenticated;


--
-- Name: TABLE loading_orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.loading_orders TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.loading_orders TO union_api;
GRANT ALL ON TABLE public.loading_orders TO authenticated;


--
-- Name: TABLE media; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.media TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.media TO union_api;
GRANT ALL ON TABLE public.media TO authenticated;


--
-- Name: TABLE members; Type: ACL; Schema: public; Owner: union_api
--

GRANT ALL ON TABLE public.members TO unionapp;
GRANT ALL ON TABLE public.members TO authenticated;


--
-- Name: TABLE permissions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.permissions TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.permissions TO union_api;


--
-- Name: TABLE product_categories; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_categories TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.product_categories TO union_api;
GRANT ALL ON TABLE public.product_categories TO authenticated;


--
-- Name: TABLE product_images; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_images TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.product_images TO union_api;
GRANT ALL ON TABLE public.product_images TO authenticated;


--
-- Name: TABLE product_units; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_units TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.product_units TO union_api;
GRANT ALL ON TABLE public.product_units TO authenticated;


--
-- Name: TABLE receipt_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.receipt_items TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.receipt_items TO union_api;
GRANT ALL ON TABLE public.receipt_items TO authenticated;


--
-- Name: TABLE receipts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.receipts TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.receipts TO union_api;
GRANT ALL ON TABLE public.receipts TO authenticated;


--
-- Name: SEQUENCE receipt_no_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.receipt_no_seq TO unionapp;
GRANT ALL ON SEQUENCE public.receipt_no_seq TO authenticated;


--
-- Name: TABLE role_permissions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.role_permissions TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.role_permissions TO union_api;


--
-- Name: TABLE roles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.roles TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.roles TO union_api;


--
-- Name: TABLE treasury_banks; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.treasury_banks TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.treasury_banks TO union_api;
GRANT ALL ON TABLE public.treasury_banks TO authenticated;


--
-- Name: TABLE treasury_cashes; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.treasury_cashes TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.treasury_cashes TO union_api;
GRANT ALL ON TABLE public.treasury_cashes TO authenticated;


--
-- Name: TABLE treasury_check_details; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.treasury_check_details TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.treasury_check_details TO union_api;
GRANT ALL ON TABLE public.treasury_check_details TO authenticated;


--
-- Name: TABLE treasury_checkbooks; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.treasury_checkbooks TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.treasury_checkbooks TO union_api;
GRANT ALL ON TABLE public.treasury_checkbooks TO authenticated;


--
-- Name: TABLE treasury_checks; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.treasury_checks TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.treasury_checks TO union_api;
GRANT ALL ON TABLE public.treasury_checks TO authenticated;


--
-- Name: TABLE treasury_pos; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.treasury_pos TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.treasury_pos TO union_api;
GRANT ALL ON TABLE public.treasury_pos TO authenticated;


--
-- Name: TABLE ui_form_permissions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ui_form_permissions TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ui_form_permissions TO union_api;


--
-- Name: TABLE ui_forms; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ui_forms TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ui_forms TO union_api;


--
-- Name: TABLE user_roles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_roles TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.user_roles TO union_api;


--
-- Name: TABLE view_receipt_summary; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.view_receipt_summary TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.view_receipt_summary TO union_api;


--
-- Name: TABLE warehouse_exit_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.warehouse_exit_items TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.warehouse_exit_items TO union_api;
GRANT ALL ON TABLE public.warehouse_exit_items TO authenticated;


--
-- Name: TABLE warehouse_exits; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.warehouse_exits TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.warehouse_exits TO union_api;
GRANT ALL ON TABLE public.warehouse_exits TO authenticated;


--
-- Name: SEQUENCE warehouse_exits_exit_no_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.warehouse_exits_exit_no_seq TO unionapp;
GRANT ALL ON SEQUENCE public.warehouse_exits_exit_no_seq TO authenticated;


--
-- Name: TABLE warehouse_rentals; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.warehouse_rentals TO unionapp;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.warehouse_rentals TO union_api;
GRANT ALL ON TABLE public.warehouse_rentals TO authenticated;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO unionapp;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO unionapp;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO union_api;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


ALTER EVENT TRIGGER issue_graphql_placeholder OWNER TO postgres;

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


ALTER EVENT TRIGGER issue_pg_cron_access OWNER TO postgres;

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


ALTER EVENT TRIGGER issue_pg_graphql_access OWNER TO postgres;

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


ALTER EVENT TRIGGER issue_pg_net_access OWNER TO postgres;

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


ALTER EVENT TRIGGER pgrst_ddl_watch OWNER TO postgres;

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


ALTER EVENT TRIGGER pgrst_drop_watch OWNER TO postgres;

--
-- PostgreSQL database dump complete
--

\unrestrict waqntksljm8fl2si84Fn31LAmT2ad29ASjcrxeIfMyfYhUFezZK02eZDMgdkyFF

